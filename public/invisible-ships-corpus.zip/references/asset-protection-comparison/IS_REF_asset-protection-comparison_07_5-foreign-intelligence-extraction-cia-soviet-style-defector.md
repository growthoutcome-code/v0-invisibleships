---
id: IS-REF-ASSET-PROTECTION-COMPARISON-07
title: "IS - Asset Protection Program Comparison Report v01 — 5. Foreign Intelligence Extraction (CIA / \"Soviet-Style\" Defector)"
collection: reference
doc_type: section
source_doc_title: IS - Asset Protection Program Comparison Report v01
source_doc_id: 1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU
source_url: "https://docs.google.com/document/d/1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU/edit"
categories: [analysis, analysis]
word_count: 194
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### 5. Foreign Intelligence Extraction (CIA / "Soviet-Style" Defector)

*Clandestine extraction for high-value intelligence assets.*

  - **Managed By:** CIA (National Resettlement Operations Center) or Russian SVR (Directorate S).
  - **Process Steps:**
      
      - **The Signal:** Asset signals desire to defect (e.g., chalk mark on a mailbox, specific email draft).
      - **Exfiltration:** Hidden in a car trunk, disguised, or walked across a border ("The Run").
      - **Debriefing:** Months in a safe house (e.g., "The Farm" or secure facility).
      - **PL-110:** Public Law 110 (US) grants citizenship and stipend.
  - **Approach Method:**
      
      - *Bump:* An officer "accidentally" runs into you (coffee shop, park).
      - *Digital:* Encrypted channels.
  - **Officer Appearance:**
      
      - *Ops:* Disguised (wigs, glasses, worker uniforms) or completely nondescript.
      - *Debriefers:* Business casual, often empathetic "psychologist" types.
  - **Danger Level:** **Extreme.** During extraction, risk of death is high. Post-extraction, risk of "active measures" (assassination, e.g., Skripal poisoning) remains for life.
  - **Family Impact:**
      
      - *Cold Reality:* If the family cannot be extracted *simultaneously* (very hard with a child/ex-wife), they are left behind. In "Soviet" scenarios, family is often used as hostages/leverage to force the author's return.
  - **Estimated Budget:**
      
      - *Program Cost:* Classified. Includes lifetime pension, housing, and medical care (Millions over a lifetime).
