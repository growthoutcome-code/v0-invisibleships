---
id: IS-REF-ASSET-PROTECTION-COMPARISON-09
title: IS - Asset Protection Program Comparison Report v01 — Interesting Findings
collection: reference
doc_type: section
source_doc_title: IS - Asset Protection Program Comparison Report v01
source_doc_id: 1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU
source_url: "https://docs.google.com/document/d/1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU/edit"
categories: [analysis, analysis]
glossary_refs: [telepathic, terrorism]
word_count: 135
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### Interesting Findings

- **The "Grey Man" Strategy:** Private and Intelligence programs prioritize *blending in* over armor. For an author fearing "Telepathic Terrorism," the visibility of uniformed police (Denver/WITSEC transport) might increase psychological stress, whereas the "Grey Man" approach of private security might be less triggering.
  - **The "Telepathic" Factor:** None of these programs officially recognize "Telepathic Terrorism" as a threat category. However, the CIA’s "Defector" program and Private Executive Protection (Gavin de Becker) heavily utilize **psychological profiling** (MOSAIC) and would likely be the most equipped to handle the *author's perception* of the threat without immediate dismissal.
  - **Family Leverage:** In the "Soviet/Intel" model, the family (specifically the 6-year-old child) would be viewed as a primary vulnerability. Intelligence agencies historically expect adversaries to target family members to flush the asset out of hiding.
