---
id: IS-REF-ASSET-PROTECTION-COMPARISON-10
title: IS - Asset Protection Program Comparison Report v01 — Sources
collection: reference
doc_type: section
source_doc_title: IS - Asset Protection Program Comparison Report v01
source_doc_id: 1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU
source_url: "https://docs.google.com/document/d/1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU/edit"
categories: [analysis, analysis]
word_count: 91
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### Sources

- [US Marshals Witness Security Program](https://www.usmarshals.gov/what-we-do/witness-security)
  - [Denver DA Witness Assistance](https://www.denverda.org/witness-assistance/)
  - [ICC Witness Protection Protocol](https://www.icc-cpi.int/sites/default/files/NR/rdonlyres/08767415-4F1D-46BA-B408-5B447B3AFC8D/0/ProtectionseminarSUMMARY.pdf)
  - [CIA National Resettlement Operations Center (Defector Programs)](https://intelnews.org/tag/cia-national-resettlement-operations-center/)
  - [Gavin de Becker & Associates (Private Threat Assessment)](https://gdba.com/how-we-protect-our-clients)
  - [Cost of Executive Protection (Zuckerberg/Meta)](https://www.worldprotectiongroup.com/ceo-security-pandemic/)
