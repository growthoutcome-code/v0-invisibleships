---
id: IS-REF-ASSET-PROTECTION-COMPARISON-06
title: IS - Asset Protection Program Comparison Report v01 — 4. International Criminal Court (ICC) Protection
collection: reference
doc_type: section
source_doc_title: IS - Asset Protection Program Comparison Report v01
source_doc_id: 1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU
source_url: "https://docs.google.com/document/d/1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU/edit"
categories: [analysis, analysis]
word_count: 131
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### 4. International Criminal Court (ICC) Protection

*Bureaucratic protection for witnesses of war crimes.*

  - **Managed By:** ICC Victims and Witnesses Unit (VWU).
  - **Process Steps:**
      
      - **Application:** Prosecutor applies for protection.
      - **Vulnerability Assessment:** Psychological and physical evaluation.
      - **Resettlement:** The ICC negotiates with a "State Party" (another country) to accept the witness.
  - **Approach Method:** ICC investigators (diverse nationalities) approach in person, often in neutral territory.
  - **Officer Appearance:** Formal business wear or UN-style identifiers (blue vests) in conflict zones; plain clothes in safe zones.
  - **Danger Level:** **Moderate.** The ICC relies on local police in the host country, who may be corrupt or inefficient.
  - **Family Impact:** Families are kept together, but the relocation process is slow and bureaucratically exhausting.
  - **Estimated Budget:**
      
      - *Cost:* Covered by the Court/State Parties.
      - *Scale:* Highly resource-constrained compared to US WITSEC.
