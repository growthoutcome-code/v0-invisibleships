---
id: IS-REF-ASSET-PROTECTION-COMPARISON-03
title: IS - Asset Protection Program Comparison Report v01 — 1. U.S. Federal Witness Security Program (WITSEC)
collection: reference
doc_type: section
source_doc_title: IS - Asset Protection Program Comparison Report v01
source_doc_id: 1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU
source_url: "https://docs.google.com/document/d/1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU/edit"
categories: [analysis, analysis]
word_count: 234
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### 1. U.S. Federal Witness Security Program (WITSEC)

*The "Gold Standard" for high-risk witnesses.*

  - **Managed By:** U.S. Marshals Service (USMS) / Department of Justice (OEO).
  - **Process Steps:**
      
      - **Sponsorship:** A state or federal prosecutor must sponsor the author.
      - **Threat Assessment:** The USMS evaluates the credibility of the threat.
      - **MOU:** The author signs a Memorandum of Understanding (strict rules).
      - **Relocation:** Immediate transport to a "Safe Site" (Orientation Center).
      - **Identity Change:** Legal name changes for author and family; new social security numbers.
  - **Approach Method:** You would be approached by a federal prosecutor or US Marshal, likely in a secure government building or via a trusted attorney. They do not "cold call."
  - **Officer Appearance:**
      
      - *Initial Contact:* Business suits or plain clothes.
      - *Transport:* Tactical gear (heavy vests, weapons) or plain clothes depending on threat level.
  - **Danger Level:** **Low.** No witness who followed the program's rules has ever been killed. The danger lies in *breaking* the rules (contacting old friends/family).
  - **Family Impact:**
      
      - **Drastic Measures:** Family members (child, ex-wife) must either join the program (permanently cutting ties with their own lives) or be left behind forever.
      - *Benefit:* If they join, they receive 100% physical safety and new identities. If they stay, they are at risk of being used as leverage.
  - **Estimated Budget:** Federally funded (Taxpayer).
      
      - *Cost to Author:* $0.
      - *Program Cost:* Approx. $60,000 - $100,000 per person/year for subsistence + administrative costs (Total program budget ~$50M+).
