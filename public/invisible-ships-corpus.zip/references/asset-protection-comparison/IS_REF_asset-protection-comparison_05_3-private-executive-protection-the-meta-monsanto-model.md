---
id: IS-REF-ASSET-PROTECTION-COMPARISON-05
title: "IS - Asset Protection Program Comparison Report v01 — 3. Private Executive Protection (The \"Meta/Monsanto\" Model)"
collection: reference
doc_type: section
source_doc_title: IS - Asset Protection Program Comparison Report v01
source_doc_id: 1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU
source_url: "https://docs.google.com/document/d/1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU/edit"
categories: [analysis, analysis]
glossary_refs: [telepathic]
word_count: 189
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### 3. Private Executive Protection (The "Meta/Monsanto" Model)

*High-end corporate security for High Net Worth Individuals (HNWI).*

  - **Managed By:** Private firms (e.g., Gavin de Becker & Associates, Pinkerton, Control Risks).
  - **Process Steps:**
      
      - **Consultation:** Author contracts the firm.
      - **MOSAIC Assessment:** Deep psychological and physical threat analysis.
      - **The Bubble:** Establishment of 24/7 "Close Protection" details and residential security.
      - **Screening:** All mail, food, and visitors are screened.
  - **Approach Method:** *You* approach *them*. If hired by a third party (e.g., a publisher), a security director would contact you by phone or secure email to arrange a meeting.
  - **Officer Appearance:**
      
      - *The "Grey Man":* Officers dress to blend in (polo shirts/khakis in public, suits in business settings). They avoid looking like "guards" to prevent drawing attention.
  - **Danger Level:** **Variable.** Effective against physical intrusion. Less effective against state-level actors or non-physical "telepathic" phenomena, though they offer psychological reassurance.
  - **Family Impact:** **High Benefit.** The family can stay together without changing names. The child (age 6) would have a bodyguard ("nanny-guard") for school.
  - **Estimated Budget:**
      
      - *Cost:* **$2 Million – $23 Million per year.** (Based on public filings for Meta/Zuckerberg security costs).
