---
id: IS-REF-ASSET-PROTECTION-COMPARISON-01
title: IS - Asset Protection Program Comparison Report v01 — Overview
collection: reference
doc_type: section
source_doc_title: IS - Asset Protection Program Comparison Report v01
source_doc_id: 1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU
source_url: "https://docs.google.com/document/d/1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU/edit"
categories: [analysis, analysis]
glossary_refs: [telepathic, terrorism]
word_count: 30
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Overview

The following report compares witness and asset protection programs ranging from local law enforcement to international intelligence operations, tailored for the author of *Invisible Ships, The Discovery of Telepathic Terrorism*.
