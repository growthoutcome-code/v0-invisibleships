---
id: IS-REF-ASSET-PROTECTION-COMPARISON-08
title: IS - Asset Protection Program Comparison Report v01 — Summary Comparison Table
collection: reference
doc_type: section
source_doc_title: IS - Asset Protection Program Comparison Report v01
source_doc_id: 1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU
source_url: "https://docs.google.com/document/d/1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU/edit"
categories: [analysis, analysis]
word_count: 83
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### Summary Comparison Table

|  |  |  |  |  |  |
| :-: | :-: | :-: | :-: | :-: | :-: |
| **Program** | **Best For...** | **Approach** | **Uniform/Look** | **Danger** | **Family Safety** |
| **US WITSEC** | Organized Crime Witnesses | Prosecutor/Marshal | Tactical / Suit | Low | High (if they join) |
| **Denver DA** | Local Crime Victims | Victim Advocate | Plain Clothes | Medium | Low (Temporary) |
| **Private Corp** | High Net Worth / Execs | Client Initiated | "Grey Man" (Blend in) | Low | High (Lifestyle maintained) |
| **ICC / Int'l** | War Crimes Witnesses | Int'l Investigator | Business / UN Vest | Medium | Medium (Bureaucratic) |
| **Intel / Defector** | Spies / State Secrets | Clandestine "Bump" | Disguised / Casual | Extreme | Very Low (Hostage risk) |
