---
id: IS-REF-ASSET-PROTECTION-COMPARISON-04
title: IS - Asset Protection Program Comparison Report v01 — 2. Local Denver District Attorney Witness Protection
collection: reference
doc_type: section
source_doc_title: IS - Asset Protection Program Comparison Report v01
source_doc_id: 1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU
source_url: "https://docs.google.com/document/d/1HdOVp1rCNKS31bOPgzpG-h-ZFON8K36C9nCqMndlOQU/edit"
categories: [analysis, analysis]
glossary_refs: [telepathic]
word_count: 172
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### 2. Local Denver District Attorney Witness Protection

*Short-term stabilization for immediate local threats.*

  - **Managed By:** Denver DA’s Office / Victim Services Network.
  - **Process Steps:**
      
      - **Referral:** Law enforcement identifies an immediate threat related to a specific case.
      - **Intake:** Meeting with a Victim Advocate to assess needs.
      - **Assistance:** Provision of temporary funds (hotel vouchers, first month's rent in new apartment).
      - **Maintenance:** Phone check-ins until trial concludes.
  - **Approach Method:** In-person by a Victim Advocate or Detective at the author's residence or a police station.
  - **Officer Appearance:**
      
      - *Detectives:* Plain clothes (jeans/jacket) with badges visible.
      - *Advocates:* Business casual civilian attire.
  - **Danger Level:** **Moderate to High.** This is *not* a new identity program. It relies on moving you to a nearby unknown address. It does not protect against sophisticated surveillance or "telepathic" tracking methods.
  - **Family Impact:** Minimal disruption but minimal protection. Family stays in their current schools/jobs, merely moving residence.
  - **Estimated Budget:**
      
      - *Cost to Author:* $0.
      - *Program Cost:* Low. Grants usually cover $1,000–$5,000 in immediate aid per case.
