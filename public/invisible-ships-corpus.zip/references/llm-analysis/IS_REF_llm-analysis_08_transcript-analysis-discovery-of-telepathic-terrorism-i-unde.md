---
id: IS-REF-LLM-ANALYSIS-08
title: "IS - LLM Analysis of External Statements — Transcript Analysis: Discovery of Telepathic Terrorism — I. Understanding the Transcript Format"
collection: reference
doc_type: section
source_doc_title: IS - LLM Analysis of External Statements
source_doc_id: 1VNEL5FEU5tZTocNbY-OM8CiO6P5IuJ2mPmtQ2tFAzUU
source_url: "https://docs.google.com/document/d/1VNEL5FEU5tZTocNbY-OM8CiO6P5IuJ2mPmtQ2tFAzUU/edit"
categories: [analysis, analysis]
word_count: 83
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
disclaimer: meta/IS_META_terms.md
---

### I. Understanding the Transcript Format

The author uses a clear annotation system to distinguish between types of statements:

  

|  |  |
| :-: | :-: |
| Prefix | Meaning |
| "From the distance" | External statements from unknown communicators (bound by the Critical Disclaimer) |
| "From the author" | Sean Harris's own responses, questions, or speculation |
| "Paraphrasing" | Author's approximation of what was suggested when exact capture wasn't possible |

  

Methodology: The author captures transcripts by repeating external suggestions aloud while recording with an Android voice recorder. Transcriptions are then generated using Google AI Studio.

---

## Critical Disclaimer on Transcripts and Accusations

Transcripts and statements recorded in this archive are external communications and do NOT represent the author's beliefs, views, or intent. Nothing here accuses, blames, or alleges malfeasance by any named person, company, or government body, and all of this information requires independent verification.

The full Critical Disclaimer, copyright and terms are in meta/IS_META_terms.md, and at https://www.invisibleships.com/disclaimer.
