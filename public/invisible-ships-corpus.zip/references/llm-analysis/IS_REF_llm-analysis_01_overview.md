---
id: IS-REF-LLM-ANALYSIS-01
title: IS - LLM Analysis of External Statements — Overview
collection: reference
doc_type: section
source_doc_title: IS - LLM Analysis of External Statements
source_doc_id: 1VNEL5FEU5tZTocNbY-OM8CiO6P5IuJ2mPmtQ2tFAzUU
source_url: "https://docs.google.com/document/d/1VNEL5FEU5tZTocNbY-OM8CiO6P5IuJ2mPmtQ2tFAzUU/edit"
categories: [analysis, analysis]
glossary_refs: [telepathic, terrorism]
word_count: 110
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Overview

IN PROGRESS  
  

# **Invisible Ships**

# The Discovery of Telepathic Terrorism  
A.I. Analysis of so-called “Citizen Tech” External Statements

*By Sean C. Harris, Denver, Colorado 2024-2026*

  
  
  
  
  
  

Are the people of Denver, CO. suffering silently from unethical technology experimentation? Has an unacknowledged terrorist attack happened on American soil?

I’m Sean C. Harris, a homeless father, tech worker and a martial arts black belt. My personal exposure to this threatening phenomena began in the fall of 2024 and continues through to today. This “in-progress” request for life saving assistance contains a tech worker’s daily perspective on the telepathic phenomena   including manually captured transcripts and technical analysis (2800+ pages).
