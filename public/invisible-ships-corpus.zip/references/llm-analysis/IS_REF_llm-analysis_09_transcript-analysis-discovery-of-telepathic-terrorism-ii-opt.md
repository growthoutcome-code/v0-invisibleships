---
id: IS-REF-LLM-ANALYSIS-09
title: "IS - LLM Analysis of External Statements — Transcript Analysis: Discovery of Telepathic Terrorism — II. Options for Segmenting External Statements"
collection: reference
doc_type: section
source_doc_title: IS - LLM Analysis of External Statements
source_doc_id: 1VNEL5FEU5tZTocNbY-OM8CiO6P5IuJ2mPmtQ2tFAzUU
source_url: "https://docs.google.com/document/d/1VNEL5FEU5tZTocNbY-OM8CiO6P5IuJ2mPmtQ2tFAzUU/edit"
categories: [analysis, analysis]
word_count: 325
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### II. Options for Segmenting External Statements

Based on my analysis, here are several ways to categorize the "from the distance" external statements:

#### Option A: By Motivation/Intent

|  |  |  |
| :-: | :-: | :-: |
| Category | Description | Example Pattern |
| Coercive/Threatening | Direct pressure to accept euthanization or harm self | "You're tired, Sean, just accept euthanasia" |
| Incriminating | Statements designed to implicate organizations or individuals | "I'm applying pressure to law enforcement, Sean" |
| Supportive/Sympathetic | Statements expressing guilt, apology, or assistance | "What we're doing to you is unconscionable" |
| Informational | Sharing details about alleged technology, processes, or actors | "The criminal underworld is using this method of communication" |
| Derailing/Disruptive | Hijacking conversations, inserting hostility | "Go fuck yourself, Sean Christopher Harris" |
| Contradictory/Confusing | Conflicting statements from multiple sources | Rapid shifts between supportive and threatening voices |

#### Option B: By Alleged Source/Role

|  |  |
| :-: | :-: |
| Category | Description |
| Law Enforcement Claims | Statements claiming to be from police, FBI, Homeland Security, DEA |
| Military Claims | Statements claiming military connection or orders |
| Intelligence Community | NSA, international agencies |
| Corporate/Technology | References to Google, Microsoft, Neuralink, Moderna |
| International Actors | Saudi Arabia, Iran, China, North Korea, India |
| "Euthanization Specialists" | Those claiming to facilitate the alleged execution process |
| Anonymous "Citizens" | General population caught in the communication |

#### Option C: By Communication Pattern/Tactic

|  |  |
| :-: | :-: |
| Pattern | Description |
| Voice Mimicry | External voices hijacking/imitating other speakers |
| Voice Filtering | Use of 8-10 voice filters to disguise identity |
| Real-time Override | Attempts to change words mid-statement |
| Character Defamation | Spreading false information about the author |
| Financial Suppression | "Do not support this person" statements at intersections |
| Luring Tactics | False intimacy, relationship suggestions, drug access offers |
| POV (Point of View) Manipulation | Visual information presenting false imagery/avatars |

#### Option D: By Temporal/Situational Context

|  |  |
| :-: | :-: |
| Context | Description |
| Shelter Communications | Statements occurring at Denver Rescue Mission 48th St. |
| Intersection ("Battle") Communications | Statements broadcast to vehicles at street intersections |
| Night/Sleep Disruption | Communications targeting rest periods |
| Device Interference | Communications accompanying equipment malfunctions |

#### Option E: By Emotional Tone

  - Hostile/Violent
  - Apologetic/Remorseful
  - Manipulative/Seductive
  - Commanding/Authoritative
  - Confused/Contradictory
  - Supportive/Encouraging
