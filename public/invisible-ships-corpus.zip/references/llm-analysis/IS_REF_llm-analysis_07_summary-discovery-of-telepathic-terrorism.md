---
id: IS-REF-LLM-ANALYSIS-07
title: "IS - LLM Analysis of External Statements — Summary: Discovery of Telepathic Terrorism"
collection: reference
doc_type: section
source_doc_title: IS - LLM Analysis of External Statements
source_doc_id: 1VNEL5FEU5tZTocNbY-OM8CiO6P5IuJ2mPmtQ2tFAzUU
source_url: "https://docs.google.com/document/d/1VNEL5FEU5tZTocNbY-OM8CiO6P5IuJ2mPmtQ2tFAzUU/edit"
categories: [analysis, analysis]
glossary_refs: [artificial-intelligence, telepathic, telepathy, terrorism]
word_count: 827
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Summary: Discovery of Telepathic Terrorism

Discovery of Telepathic Terrorism is a four-part investigative document series authored by Sean C. Harris, a tech-sector researcher based in Denver, Colorado. The series, spanning from Fall 2024 to present (2026), chronicles the author's experience with what he describes as a "Citizen Tech" phenomenon—a technology-driven form of telepathic communication that allows for non-consensual observation ("breaching"), communication, and psychological coercion.

  

Core Thesis: The author alleges that this technology is being used to facilitate an unacknowledged "terrorist occupation" and a covert system of euthanasia. He claims that citizens are being placed on "euthanization lists" for engaging with or being exposed to this telepathic communication. The documents suggest this may be a "biotechnology attack" or a "human breaching process" supported by AI, potentially involving state actors, criminal organizations, or rogue elements within law enforcement (specifically mentioning a "narcotics unit").

  

Methodology: Harris documents these experiences by manually transcribing the "external statements" he receives. He repeats these statements aloud into a voice recorder and uses Google AI Studio to generate transcripts. He strictly differentiates between his own views ("From the author") and the external voices ("From the distance"), applying a critical disclaimer that he does not endorse the often violent or illegal content of the external messages.

  

Key Themes in the Transcripts:

  

  - Forced Euthanization: Continuous demands for the author and others to "accept euthanization."
  - Suppression: Efforts to prevent the author from working or receiving financial support (e.g., broadcasting "Do not support this person" to drivers at intersections).
  - Information Control: New escalations in Part 04 involve threats for searching specific information, such as "Do not Google that information" regarding Nita Farahany's book *The Battle for Your Brain*.
  - Technological Context: References to Brain-Computer Interfaces (BCI), AI voice cloning, and "off-site locations" using synthetic media to deceive targets.

  

Goal: The author's stated goal is not to accuse specific entities without evidence but to present these "Citizen Tech" transcripts as a dataset for investigation. He calls for official government acknowledgement to prevent public panic, a denunciation of covert euthanasia, and updated mental health protocols to distinguish these technological phenomena from mental illness.

  
  
  

Additions 1/10/2026, Claud Sonnet 4.5

  

*** BEGIN PROMP ***

  

Please summarize the Discovery of Telepathic Terrorism.

  

*** END PROMP ***

  
  

Based on my search of the knowledge base, here is a summary of the Discovery of Telepathic Terrorism document series:

### **Overview**

The Discovery of Telepathic Terrorism is a four-part document series authored by Sean C. Harris, a 49-year-old tech-sector researcher based in Denver, Colorado. The series spans from Fall 2024 through 2026 and contains over 2,800 pages of manually captured transcripts, journal entries, and technical analysis.

### **Core Claims**

The documents present what the author describes as evidence of a potential national security threat, including:

  

1.  Technology-driven telepathic communication targeting citizens in Denver, Colorado
2.  A "human breaching process" – an alleged method for non-consensually observing and communicating with individuals, supported by technologies like AI
3.  Claims of unconsented criminal coercion and AI-driven psychological warfare
4.  Allegations of an unacknowledged system of covert euthanasia

### **Document Structure**

|  |  |
| :-: | :-: |
| Part | Coverage Period |
| Part 01 | Fall 2024 – August 22, 2025 (includes research findings, glossary, appendix) |
| Part 02 | August 23 – September 28, 2025 |
| Part 03 | September 29 – November 8, 2025 |
| Part 04 | November 9, 2025 – 2026 (ongoing) |

### **Important Distinctions**

The author makes a critical disclaimer: The transcripts documenting "Citizen Tech" communications are recorded as external statements and do not represent the author's personal beliefs, views, or intent. The author explicitly states he is not accusing any specific corporation (e.g., Neuralink, Google, Microsoft) or government entity (e.g., Denver Police, FBI) of wrongdoing—rather, presenting patterns for investigation by relevant authorities.

### **Author's Proposed Goals**

The author suggests advancing toward:

  

1.  Official acknowledgment to mitigate public panic
2.  Government denunciation of covert euthanasia
3.  Nationwide education on telepathy to build resilience against manipulation
4.  Updated mental health protocols to distinguish this phenomenon from schizophrenia

### **Context**

The author frames these concerns within the field of Neuroethics, referencing scholars like Nita Farahany, Hank Greely, and Martha Farah, and notes the rapid growth of the Brain-Computer Interface (BCI) market as context for why ethical oversight is urgently needed.

  

  

Would you like me to search for more specific details about any particular section, the transcripts, or the "Citizen Tech" communications?

  
  

*** BEGIN PROMP ***

  

Please provide an analysis of the transcripts.

  

  - statements prefixed with "from the distance" are external statements bound by the critical disclaimer
  - statements prefixed with "from the author" are responses to questions and or speculation from the author
  - provide several options on how you can segment the external statements i.e. by motivation or pattern of communication. Include any other ideas.
  - identify threats to anyone that comes in contact with the communication
  - are artificial intelligence voice agents in use?

  

*** END PROMPT ***

  
  

Based on my comprehensive search of the knowledge base, here is my analysis of the transcripts from the Discovery of Telepathic Terrorism documents:
