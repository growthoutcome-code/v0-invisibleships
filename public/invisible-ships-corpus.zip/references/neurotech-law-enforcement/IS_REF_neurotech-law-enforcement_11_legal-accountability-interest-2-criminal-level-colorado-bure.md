---
id: IS-REF-NEUROTECH-LAW-ENFORCEMENT-11
title: "IS - Neuro-tech in Law Enforcement & Zersetzung — Legal Accountability & Interest — 2. Criminal Level: Colorado Bureau of Investigation (CBI)"
collection: reference
doc_type: section
source_doc_title: "IS - Neuro-tech in Law Enforcement & Zersetzung"
source_doc_id: 1lEFuRTRZLYrzJV3ZRkVvn1viVSVxZoB6Yg0PidbcMYg
source_url: "https://docs.google.com/document/d/1lEFuRTRZLYrzJV3ZRkVvn1viVSVxZoB6Yg0PidbcMYg/edit"
categories: [legal, analysis]
word_count: 91
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### 2. Criminal Level: Colorado Bureau of Investigation (CBI)

If the tactics involve harassment, stalking, or physical/mental harm—essentially a modern version of the eBay stalking case—the CBI is the specialized state agency equipped for high-tech crimes.

  

**Role:** The CBI handles "complex cases," including cyber crimes and organized criminal activity that local police may not have the technical resources to investigate.

  

**Accountability:** They investigate violations of state stalking and harassment statutes (18-3-602, C.R.S.), which cover "credible threats" and "repeated acts" intended to cause emotional distress.
