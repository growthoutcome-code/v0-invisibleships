---
id: IS-REF-NEUROTECH-LAW-ENFORCEMENT-05
title: "IS - Neuro-tech in Law Enforcement & Zersetzung — Crimes in Question — Zersetzung Tactics"
collection: reference
doc_type: section
source_doc_title: "IS - Neuro-tech in Law Enforcement & Zersetzung"
source_doc_id: 1lEFuRTRZLYrzJV3ZRkVvn1viVSVxZoB6Yg0PidbcMYg
source_url: "https://docs.google.com/document/d/1lEFuRTRZLYrzJV3ZRkVvn1viVSVxZoB6Yg0PidbcMYg/edit"
categories: [reference, analysis]
word_count: 354
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### Zersetzung Tactics

In a psychological and political context, Zersetzung (literally "decomposition" or "disintegration") refers to a sophisticated and terrifying set of psychological warfare techniques used by the East German secret police, the Stasi, to neutralize perceived enemies of the state.  

Rather than making arrests—which would draw international condemnation—the Stasi aimed to destroy a person's life from the inside out.

  

#### The Core Tactics

The goal was to "switch off" individuals by shattering their self-confidence, reputation, and social ties. 

 

**Gaslighting & Intrusions:** Agents would secretly enter a target’s home and move furniture, change the time on clocks, or remove a single item (like a specific key) and return it days later. The goal was to make the victim doubt their own sanity.

  

**Character Assassination:** Spreading false rumors about a target’s sexual orientation, financial honesty, or loyalty to their friends.

Social Isolation: Sending anonymous letters or making phone calls to employers and spouses to create friction, eventually leading to job loss or divorce.

  

**Career Sabotage:** Using state influence to ensure the target failed exams or was demoted without a clear reason.

  

#### The eBay Stalking Case

A modern, corporate example of these tactics occurred between 2019 and 2020, involving high-level executives at eBay. They targeted Ina and David Steiner, a couple who ran a newsletter (EcommerceBytes) that was often critical of eBay.  

The harassment campaign mirrored Stasi-style Zersetzung through:

  

**Disturbing Deliveries:** Sending a bloody pig mask, a funeral wreath, and live insects to the couple's home.  

  

**Physical Surveillance:** Driving past their home in black vans and planning to break into their garage to install a GPS tracker.

  

**Cyber-Harassment:** Creating fake Craigslist ads inviting "alternative" encounters at the couple's address.

  

**Legal Outcome:** Several former eBay employees, including the former Senior Director of Safety and Security, were sentenced to prison. In early 2024, eBay entered into a deferred prosecution agreement and paid a $3 million fine.  

  

Further Reading:

eBay Inc. to Pay $3 Million in Connection with Corporate Cyberstalking Campaign Targeting Massachusetts Couple

<https://www.justice.gov/usao-ma/pr/ebay-inc-pay-3-million-connection-corporate-cyberstalking-campaign-targeting>
