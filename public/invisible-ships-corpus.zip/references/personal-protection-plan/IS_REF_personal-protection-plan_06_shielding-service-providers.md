---
id: IS-REF-PERSONAL-PROTECTION-PLAN-06
title: IS - Personal Protection Plan — Shielding Service Providers
collection: reference
doc_type: section
source_doc_title: IS - Personal Protection Plan
source_doc_id: 1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8
source_url: "https://docs.google.com/document/d/1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8/edit"
categories: [protection, analysis]
word_count: 762
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Shielding Service Providers

Protecting a dwelling from Long Range Acoustic Devices (LRAD) and Directed EMF requires a multi-layered approach that combines physical shielding (blocking), decoupling (isolation), and signal management. In 2026, these services are increasingly categorized under TSCM (Technical Surveillance Counter-Measures) and Physical Cyber-Security.

  

​Here is a comprehensive list of approaches for residences, apartments, and businesses:

  

### **​1. High-Performance Window Shielding (Acoustic and EMF)**

​Windows are the primary entry point for both directional sound beams and microwave-frequency EMF. Laminated solutions provide a "transparent Faraday cage" effect.

  

#### ​DIY Options: 

  

**EMF:** Apply high-attenuation conductive window films. Brands like SignalProtect or Gila offer DIY kits that block up to 99% of RF/EMF.

  

**​Sound:** Install heavy-duty 1/4 inch thick polycarbonate "storm window" inserts over existing glass to create an air gap that reflects LRAD energy.

  

#### ​Service Providers:

  

**Safe Living Technologies:** Specialized in EMF shielding consultations and products.

  

**​Indow Windows:** Provides "Acoustic Grade" window inserts designed to dampen exterior high-decibel noise.

  

#### ​Contact Information:

  

**​Safe Living Technologies:** https://safelivingtechnologies.com | Phone: 1-888-811-1511 | Email: support@safelivingtechnologies.com

  

**​Indow Windows:** https://indowwindows.com | Phone: 1-503-284-2260

  

#### ​Pricing Tiers and Effectiveness:

  

**​Tier 1 ($200 - $800):** DIY Film/Polycarbonate inserts. Blocks up to 25dB of sound and 90% of EMF.

  

**​Tier 2 ($1,500 - $5,000):** Professional Indow inserts or double-layered shielding. Blocks up to 35dB and 98% of EMF.

  

**​Tier 3 ($10,000+):** Full replacement with Laminated Acoustic/EMF glass. Blocks 50dB+ and 99.99% of signals.

  

### **​2. Wall and Ceiling Reinforcement (The Interior Shell)**

  

​This is critical for apartments and businesses where the roof or shared walls are targeted.

  

​DIY Options:

  

**​Sound:** Hang Mass Loaded Vinyl (MLV) curtains or staple MLV rolls directly to the ceiling joists in the attic.

  

**​EMF:** Use YSHIELD® conductive paint. It applies like standard primer and grounds out incoming microwave and radio frequencies.

  

#### ​Service Providers:

  

**​Acoustical Surfaces:** Industrial-grade soundproofing for warehouses and businesses.

  

**​EMF Shielding Solutions:** Nationwide service for applying conductive paints and fabrics to residential interiors.

  

#### ​Contact Information:

  

**​Acoustical Surfaces:** https://www.acousticalsurfaces.com | Phone: 1-800-448-0121

  

**​EMF Shielding Solutions:** https://emfshieldingsolutions.com | Email: info@emfshieldingsolutions.com

​

#### Pricing Tiers and Effectiveness:

  

**​Tier 1 ($500 - $1,200):** DIY MLV and 1-2 coats of EMF paint. Effective against low-power harassment.

  

**​Tier 2 ($3,000 - $8,000):** Professional application of 3 coats of paint + mineral wool insulation in ceilings. High effectiveness against sustained LRAD.

  

**​Tier 3 ($15,000+):** Installation of a "Room within a Room" (Decoupling). Stops 99.9% of all vibration and signal penetration.

  

### **​3. Roof and Attic Hardening (Targeted Defense)**

​Specifically for protecting against high-mast LRAD or EMF emitters placed on adjacent tall buildings.

  

#### ​DIY Options:

  

**​Shielding Blankets:** Lay EMF-shielding fabrics (silver or copper mesh) across the attic floor.

  

**​Rockwool Insulation:** Replace fiberglass with dense stone wool to add acoustic mass to the roof structure.

  

#### ​Service Providers:

  

**​LessEMF:** The leading supplier of high-end shielding textiles and roof-grade conductive meshes.

  

**​Shielded Healing:** Provides site-specific audits to determine roof vulnerabilities.

  

#### ​Contact Information:

  

**​LessEMF:** https://lessemf.com | Phone: 1-518-608-6479 | Email: help@lessemf.com

​Shielded Healing: <https://shieldedhealing.com>

  

#### ​Pricing Tiers and Effectiveness:

  

**​Tier 1 ($400 - $1,000):** DIY fabric laying. Good for preventing "unconsented visualizations" induced via roof-level EMF.

  

**​Tier 2 ($2,500 - $6,000):** Full attic insulation overhaul with acoustic mineral wool and radiant barrier EMF foil.

  

**​Tier 3 ($12,000+):** Installation of G-Iron or heavy-duty Mu-Metal plating on the roof sub-structure. Ultimate protection against military-grade LRAD/EMF.

  

### **​4. Active Signal Neutralization (BCI & Cyber Defense)**

  

​For businesses and high-risk residences needing to protect digital and neural privacy from "Gray Zone" hacking.

  

​DIY Options:

  

**​Faraday Sleeves: K**eep all BCI hardware and phones in GoDark or Mission Darkness bags when not in use.

  

**​White Noise Generators:** Use high-fidelity masking systems to disrupt "eavesdropping" beams.

  

#### ​Service Providers:

  

**​Mission Darkness (Faraday Defense):** Provides forensic-grade signal blocking enclosures.

  

**​ComSec LLC:** World-class TSCM investigators who perform "Neural Audits" and install active signal countermeasures.

  

#### ​Contact Information:

  

**​Mission Darkness:** https://mosequipment.com | Phone: 1-805-316-1006

  

**​ComSec LLC:** https://comsecllc.com | Phone: 1-800-615-0392

  

#### ​Pricing Tiers and Effectiveness:

  

**​Tier 1 ($50 - $300):** Faraday bags and basic white noise machines. Protects devices but not the human user.

  

**​Tier 2 ($1,000 - $4,000):** Professional TSCM sweep and installation of active signal jammers (where legal) or signal-masking arrays.

  

**​Tier 3 ($20,000+):** Full SCIF (Sensitive Compartmented Information Facility) construction. Complete blackout of all external neural/electronic influence.
