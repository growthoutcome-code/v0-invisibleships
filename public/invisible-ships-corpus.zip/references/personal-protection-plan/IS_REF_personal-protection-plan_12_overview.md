---
id: IS-REF-PERSONAL-PROTECTION-PLAN-12
title: IS - Personal Protection Plan — Overview
collection: reference
doc_type: section
source_doc_title: IS - Personal Protection Plan
source_doc_id: 1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8
source_url: "https://docs.google.com/document/d/1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8/edit"
categories: [protection, analysis]
word_count: 411
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### **Estimated Expenses**

The cost of a forensic investigation depends on the **scope** (how much area and time is covered) and the **level of legal documentation** required.

Based on industry standards and published rates for firms like **Elexana**, **Envista Forensics**, and other high-level investigators, here is a breakdown of what someone would likely pay for this specific type of investigation.

### **Forensic RF Signal Audit (The "Site Survey")**

This is the core cost to bring an engineer and professional-grade spectrum analyzers (up to 60GHz) to a home.

  - **Basic Survey (1-2,000 sq. ft.):** **$800 – $3,000**
  - **Detailed Forensic Audit (with Legal Report):** **$5,000 – $15,000**
  - **Expert Witness Add-on:** Firms often charge an additional **$1,000 – $3,000** specifically to write a report that is certified for use in court.
  - **Hourly Rates:** If billed by the hour, senior forensic engineers typically range from **$300 to $600 per hour**.

### **TSCM "Bug Sweep" (Technical Surveillance)**

If you hire a counter-surveillance specialist to find hidden devices rather than just mapping ambient signals:

  - **Standard Residential Sweep:** **$1,500 – $6,000**
  - **Flat-Rate Minimum (High-End):** Firms like Howe Law Firm (Denver) often have a minimum around **$4,000** which covers up to 2,000 sq. ft. and includes legal preservation of evidence.

### **Legal & Litigation Costs (The "Strike")**

Once you have the data, you need to use it in court.

  - **Initial Attorney Retainer:** **$3,000 – $10,000** (Common for civil rights or high-stakes litigation).
  - **Expert Testimony:** If the engineer has to appear in court or a deposition, they typically charge **$400 – $750 per hour** with a half-day or full-day minimum.

  

### **Strategies to Reduce Costs**

1.  **Phase the Work:** Start with a **"Consultation/Basic Sweep" ($1,000)**. If the engineer finds the signal immediately, you then pay for the **"Forensic Report" ($3,000)**. Don't pay for the full legal report until you know there is a signal to report.
2.  **Organize Your Logs First:** Use the **Google Sheets Tab 2 (Discovery Log)** we created. If you show the engineer a list of exactly when the spikes occur, they spend less time (and less of your money) "hunting" for the signal.
3.  **Use a Flat-Fee Firm:** Companies like **Howe Law Firm** (Denver) offer flat-fee packages for residential sweeps. This prevents "billable hour creep."

**Note on "Retainers":** Most forensic firms (like Envista) will require an upfront retainer (often $2,000–$5,000) before they send a technician to your house.
