---
id: IS-REF-PERSONAL-PROTECTION-PLAN-07
title: IS - Personal Protection Plan — Key Advocates
collection: reference
doc_type: section
source_doc_title: IS - Personal Protection Plan
source_doc_id: 1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8
source_url: "https://docs.google.com/document/d/1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8/edit"
categories: [protection, analysis]
glossary_refs: [cognitive-liberty]
word_count: 625
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Key Advocates

Several prominent medical and mental health professionals have been at the forefront of advocating for and defending Neuro-Rights and the Colorado Privacy Act (HB24-1058).   

In the medical community, the movement has been led by neurologists and psychiatrists who argue that "mental privacy" is the new frontier of patient safety.

  

### **1. The Key Advocates in Colorado**

  

**Dr. Sean Pauzauskie (Neurologist):** As the Medical Director of the Neurorights Foundation, Dr. Pauzauskie was arguably the most instrumental medical professional in the passage of HB24-1058. He testified before the Colorado General Assembly, arguing that neural data is "the most intimate data a human can produce" and requires the same protections as a medical record.

  

Phone: 970-495-7000

  

Neuro-rights Foundation Contact Info:

  

General Inquiry: contact@neurorightsfoundation.org  

 

Jared Genser (General Counsel): jgenser@perseus-strategies.com

  

Note: Jared Genser is a renowned human rights lawyer who handles the legal framework for neural protections.

 

**Dr. Lynn Parry (Neurologist):** A private practice neurologist in Littleton, CO, and a member of the Colorado Delegation to the AMA. She successfully brought a resolution to the American Medical Association to adopt Colorado's neural data protections as a national medical standard. 

  

Phone: 303-993-6579 

  

### **2. National Figures & Organizations**

  

**Dr. Rafael Yuste (Neuroscientist):** While primarily a researcher at Columbia University, he is the co-founder of the Neurorights Foundation and has worked closely with Colorado legislators. He advocates for the "Five Neuro-Rights," including the right to mental identity and free will, which are often compromised in "decomposition" or gray zone attacks. 

  

Dr. Rafael Yuste (Chair): rmy5@columbia.edu

  

**Dr. Nita Farahany (Legal Scholar & Ethicist):** Though her background is in law and philosophy, she is a leading voice in the medical-ethics community. Her book, The Battle for Your Brain, is the primary text used by mental health professionals to understand Cognitive Liberty—the right to self-determination over our brains.  

  

**The American Medical Association (AMA):** In 2025, the AMA officially adopted Resolution 503, which mirrors Colorado’s law. This move was supported by thousands of psychiatrists and neurologists nationwide who believe that neuro-tech must be "safe-guarded from misuse or abuse."  

  

### **3. Why Mental Health Professionals Support These Laws**

For psychologists and psychiatrists, these laws provide a legal "shield" for their patients. Without these protections:

  

The "Haldol" Effect: Victims of acoustic or EMF harassment are often misdiagnosed with psychotic disorders. Neuro-rights laws allow doctors to consider "external technological interference" as a legitimate clinical possibility.

Therapeutic Integrity: Psychotherapists are concerned that BCIs could "detect emotions" or "mental states" without a clinician’s oversight, leading to the HB26-1195 restrictions currently being debated in Colorado to prevent AI from diagnosing mental health without a human professional.  

  

<membership@cms.org>

  

Ask for the "Bio-Ethics or Legislative Committee" regarding neuro-data protections.

  

### **Tips for "High-Impact" Outreach**

  

Because these individuals receive many inquiries, use the following "subject line" strategy to ensure your email is flagged as a priority for their legal or medical teams:

  

**Subject:** CASE REFERRAL: Documented Neural Trespass / Violation of HB24-1058 (Colorado)

  

**In the body of your email, briefly mention:**

  

That you are seeking a clinical referral for a "Neuro-Forensic Evaluation."

  

That you are documenting unconsented mental visualizations or acoustic harassment in the Denver/Seattle area.

  

That you are aware of the Zersetzung (decomposition) tactics being used and are seeking an expert who can distinguish these from traditional neurological symptoms.

  

As of 2026, the markets for EMF shielding and acoustic defense have shifted from niche industrial applications to high-growth sectors within the Consumer Electronics, Defense, and Real Estate industries. Driven by neuro-rights legislation like Colorado HB24-1058 and increasing awareness of "Gray Zone" threats, these technologies are seeing a surge in institutional and retail investment.
