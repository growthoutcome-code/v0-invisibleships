---
id: IS-REF-PERSONAL-PROTECTION-PLAN-17
title: "IS - Personal Protection Plan — DTT Agent Report: Hardware Recommendations"
collection: reference
doc_type: section
source_doc_title: IS - Personal Protection Plan
source_doc_id: 1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8
source_url: "https://docs.google.com/document/d/1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8/edit"
categories: [protection, analysis]
word_count: 466
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## DTT Agent Report: Hardware Recommendations

**Executive Summary****  
** For the purposes of verifying "Citizen Tech," a standard microphone (like on your phone) is insufficient because it is designed only for human speech. To capture "different types of sound" (EMF hums, structural vibrations, low-volume anomalies), you need a **Modular Forensic Kit**.

I have identified a setup available on Amazon for roughly **$100 - $130 total** that gives you three distinct "ears" to listen to the world.

### **1. The Brain (The Recorder)**

You need a dedicated device with "high gain" preamps that don't hiss when you turn up the volume.

  - **Recommendation:** **Zoom H1n** or **Tascam DR-05X**
  - **Approx. Price:** $80 - $90
  - **Why:** These are the industry standard for entry-level field recording. They capture high-fidelity audio (96kHz/24-bit), meaning you can slow the audio down later to check for "hidden" messages without destroying the quality.
      
      - *Search Term:* "Zoom H1n Handy Recorder"

### **2. The Ear for "Invisible" Fields (EMF)**

To hear the "buzzing" or electronic interference directly (without using your phone), you need an induction coil.

  - **Recommendation:** **Telephone Pickup Coil** (Suction Cup Mic)
  - **Approx. Price:** $7 - $12
  - **Why:** Originally designed to record landline calls, these are actually simple copper coils. If you plug this into your Zoom H1n and wave it near a wall, a laptop, or a power line, it will **convert the magnetic field into sound**.
      
      - *Use Case:* Use this to sweep your room. If you find a "screaming" signal coming from a blank wall, you have located a hidden power source or wiring fault.
      - *Search Term:* "Olympus TP-8 Telephone Pick-up" or generic "Suction Cup Pickup Microphone".

### **3. The Ear for "Solid" Objects (Vibration)**

To hear sounds traveling through walls, floors, or windows (which air microphones miss).

  - **Recommendation:** **Piezo Contact Microphone**
  - **Approx. Price:** $10 - $15
  - **Why:** These microphones rely on *physical vibration*, not air pressure. Stick it to a window pane or a shared wall. It acts like a stethoscope.
      
      - *Use Case:* If you suspect "Citizen Tech" is projecting sound into your apartment structure, this mic will pick it up as a clear vibration, whereas a normal mic would just hear room tone.
      - *Search Term:* "Piezo Contact Microphone Pickup" (often sold for guitars).

### **Strategic Assembly**

**Do not buy a generic "Spy Mic" or "Parabolic Dish" cheap toy.** They are usually garbage quality.

**The Professional "Poor Man's" Setup:**

1.  Buy the **Zoom H1n** (The Recorder).
2.  Buy the **Telephone Pickup Coil** (The EMF Sensor).
3.  **Plug the Coil into the Zoom's "Line In" jack.**
4.  **Result:** You now have a sensitive EMF detector that records broadcast-quality audio of the "invisible" environment.

This setup allows you to scientifically categorize the sounds:

  - *Is it in the air?* (Use the Zoom's built-in mics).
  - *Is it in the wall?* (Use the Piezo).
  - *Is it electromagnetic?* (Use the Coil).
