---
id: IS-REF-PERSONAL-PROTECTION-PLAN-14
title: IS - Personal Protection Plan — Estimating Expenses
collection: reference
doc_type: section
source_doc_title: IS - Personal Protection Plan
source_doc_id: 1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8
source_url: "https://docs.google.com/document/d/1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8/edit"
categories: [protection, analysis]
word_count: 840
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Estimating Expenses

The cost of a forensic investigation depends on the scope (how much area and time is covered) and the level of legal documentation required.

Based on industry standards and published rates for firms like Elexana, Envista Forensics, and other high-level investigators, here is a breakdown of what someone would likely pay for this specific type of investigation.

### **Forensic RF Signal Audit (The "Site Survey")**

This is the core cost to bring an engineer and professional-grade spectrum analyzers (up to 60GHz) to a home.

  - **Basic Survey** (1-2,000 sq. ft.): $800 – $3,000
  - **Detailed Forensic Audit (with Legal Report):** $5,000 – $15,000
  - **Expert Witness Add-on:** Firms often charge an additional $1,000 – $3,000 specifically to write a report that is certified for use in court.
  - **Hourly Rates:** If billed by the hour, senior forensic engineers typically range from $300 to $600 per hour.

### **TSCM "Bug Sweep" (Technical Surveillance)**

If you hire a counter-surveillance specialist to find hidden devices rather than just mapping ambient signals:

  - **Standard Residential Sweep:** $1,500 – $6,000
  - **Flat-Rate Minimum (High-End):** Firms like Howe Law Firm (Denver) often have a minimum around $4,000 which covers up to 2,000 sq. ft. and includes legal preservation of evidence.

### **Legal & Litigation Costs**

Once you have the data, you need to use it in court.

  - **Initial Attorney Retainer:** $3,000 – $10,000 (Common for civil rights or high-stakes litigation).
  - **Expert Testimony:** If the engineer has to appear in court or a deposition, they typically charge $400 – $750 per hour with a half-day or full-day minimum.Strategies to Reduce Costs

<!-- end list -->

1.  **Phase the Work:** Start with a "Consultation/Basic Sweep" ($1,000). If the engineer finds the signal immediately, you then pay for the "Forensic Report" ($3,000). Don't pay for the full legal report until you know there is a signal to report.
2.  **Organize Your Logs First:** Use the Google Sheets Tab 2 (Discovery Log) we created. If you show the engineer a list of exactly when the spikes occur, they spend less time (and less of your money) "hunting" for the signal.
3.  **Use a Flat-Fee Firm:** Companies like Howe Law Firm (Denver) offer flat-fee packages for residential sweeps. This prevents "billable hour creep."

****Note on "Retainers":*** *Most forensic firms (like Envista) will require an upfront retainer (often $2,000–$5,000) before they send a technician to your house.*

### **FOIA Requests**

In Colorado, requests for public records are handled under the Colorado Open Records Act (CORA). If the records involve law enforcement or criminal investigations, they fall under the Colorado Criminal Justice Records Act (CCJRA).

​Below is a formal draft you can use. I have tailored it to address the specific intersection of neuro-technology oversight and psychological coercion (Zersetzung) under Colorado's new neural privacy laws.

#### ​CORA/CCJRA Request Form

​TO: Records Custodian

AGENCY: [Select one: Denver Police Department / Colorado Bureau of Investigation / Colorado Attorney General]

DATE: February 21, 2026

​RE: Public Records Request regarding Neuro-technology Oversight and Psychological Coercion Frameworks

​To the Records Custodian,

​Pursuant to the Colorado Open Records Act (24-72-200.1, C.R.S.) and/or the Colorado Criminal Justice Records Act (24-72-301, C.R.S.), I hereby request the following records:

1.  **​****Policy and Procedure Records:** Any internal directives, training manuals, or "standard operating procedures" (SOPs) regarding the investigation of unauthorized neuro-technology use as defined under HB24-1058 (Protect Privacy of Biological Data).
2.  **​****Surveillance Oversight:** Records or logs concerning the deployment or authorized use of neuro-technological monitoring devices by this agency or its contractors within the City and County of Denver.
3.  **​****Coercive Tactics Definitions:** Any guidance documents or legal bulletins used by this agency to identify and classify "Zersetzung" or "Psychological Decomposition" tactics in the context of Stalking ($18-3-602, C.R.S.) or Coerced Assisted Suicide ($25-48-121, C.R.S.).
4.  **​****Inter-Agency Correspondence:** Communications between this agency and the Colorado Attorney General’s Office regarding the enforcement of neural data privacy rights since the enactment of HB24-1058.

​Format of Records: I request these records be provided in digital format (PDF) via email to [Your Email Address].

​Fee Waiver/Limit: If the cost of fulfilling this request exceeds $50.00, please provide an itemized estimate before proceeding. I request a waiver of fees as this request is in the public interest to ensure government transparency regarding emerging neuro-technologies and civil liberties.

​Please provide a response within three (3) working days as required by law. If any portion of this request is denied, please cite the specific statutory exemption and provide a brief explanation for the denial.

​Sincerely,

​[Your Name]

[Your Phone Number]

[Your Address]

### ​Where to Send This Request

  - ​For Denver-specific surveillance: Send to the Denver Police Department Records Unit.
  - ​For state-level neuro-tech investigations: Send to the Colorado Bureau of Investigation (CBI).
  - ​For privacy law enforcement data: Send to the Colorado Attorney General’s Consumer Protection Division.
