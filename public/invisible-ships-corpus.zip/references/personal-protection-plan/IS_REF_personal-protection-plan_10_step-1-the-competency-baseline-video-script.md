---
id: IS-REF-PERSONAL-PROTECTION-PLAN-10
title: "IS - Personal Protection Plan — Step 1: The Competency Baseline (Video Script)"
collection: reference
doc_type: section
source_doc_title: IS - Personal Protection Plan
source_doc_id: 1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8
source_url: "https://docs.google.com/document/d/1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8/edit"
categories: [protection, analysis]
word_count: 108
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Step 1: The Competency Baseline (Video Script)

Record this immediately to prevent officials from using misdiagnosis as a weapon.

"Today is January 7, 2026. My name is [Your Name]. I am recording this to establish my sound mind and legal intent. I am currently documenting unconsented neurological battery in Denver, CO. I am not suicidal, I am not delusional, and I explicitly reject all 'wellness interventions' or forced medication. This video serves as evidence that I am a competent witness to a crime in progress."

  

**See video of the author Sean C. Harris making this statement, Tuesday, January 20th 2026.* [*Sean-Harris-Statement-v01.mp4*](https://drive.google.com/file/d/1MWuDytOvkfZSMVKh8lnIZ2WJzKixz6dl/view?usp=sharing)
