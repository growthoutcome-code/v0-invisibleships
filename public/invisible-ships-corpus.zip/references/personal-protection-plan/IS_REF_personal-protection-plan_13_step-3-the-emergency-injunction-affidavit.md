---
id: IS-REF-PERSONAL-PROTECTION-PLAN-13
title: "IS - Personal Protection Plan — Step 3: The Emergency Injunction Affidavit"
collection: reference
doc_type: section
source_doc_title: IS - Personal Protection Plan
source_doc_id: 1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8
source_url: "https://docs.google.com/document/d/1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8/edit"
categories: [legal, analysis]
word_count: 157
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Step 3: The Emergency Injunction Affidavit

**Print this and take it to a Notary Public once your Log (Tab 2) has at least 5 entries.*

**STATE OF COLORADO, COUNTY OF DENVER** I, [Your Name], being of lawful age and duly sworn, depose and state:

1.  I have maintained a forensic log of Radio Frequency (RF) spikes that correlate 1:1 with unconsented neurological communications.
2.  I have performed Faraday Attenuation tests that prove these signals originate from external sources.
3.  I have notified the City of Denver of these assaults, and they have failed to perform a signal audit.
4.  I request an Emergency Injunction to halt all "Wellness Checks" and coerced medical protocols while this forensic discovery is pending.

**Signature:** __________________________ **Date:** _______________
