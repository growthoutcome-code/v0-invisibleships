---
id: IS-REF-PERSONAL-PROTECTION-PLAN-01
title: IS - Personal Protection Plan — What can you do to investigate and prosecute unconsented neurotech communication and life threatening harassment?
collection: reference
doc_type: section
source_doc_title: IS - Personal Protection Plan
source_doc_id: 1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8
source_url: "https://docs.google.com/document/d/1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8/edit"
categories: [legal, analysis]
word_count: 60
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## What can you do to investigate and prosecute unconsented neurotech communication and life threatening harassment?

*Author: Sean C. Harris,* [*growthoutcome@gmail.com*](mailto:growthoutcome@gmail.com)*, $invisibleships 303-901-2150 Last Update 04/24/2026*

###

### Overview

Based on the findings from the [Invisible Ships](https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit?usp=drive_link). This document outlines steps to protect an individual's property and civil rights from unconsented-to neurological communication and battery.
