---
id: IS-REF-PERSONAL-PROTECTION-PLAN-11
title: "IS - Personal Protection Plan — Step 2: Forensic Investigation"
collection: reference
doc_type: section
source_doc_title: IS - Personal Protection Plan
source_doc_id: 1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8
source_url: "https://docs.google.com/document/d/1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8/edit"
categories: [protection, analysis]
word_count: 497
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Step 2: Forensic Investigation

There are several other high-level organizations that provide forensic RF engineering, technical surveillance counter-measures (TSCM), and EMI/EMF forensic investigation services similar to ELEXANA and Envista Forensics.

To ensure they are viable for your case, you should look for firms that specifically mention "Litigation Support" or "Expert Witness Testimony," as this means their technical reports are designed to hold up in court.

### 

### **Top-Tier Forensic Engineering Firms (National/Global)**

These firms are multidisciplinary. You should specifically ask for their Electrical Engineering or Forensic Technology departments.

  

|  |  |  |
| :-: | :-: | :-: |
| **Organization** | **Specialized Service** | **Email / Contact** |
| S-E-A (SEA Limited) | Advanced forensic engineering and 5G/RF failure analysis. | info@sealimited.com |
| J.S. Held | Forensic electrical engineering and signal failure analysis. | cwilkens@jsheld.com (Christopher Wilkens) |
| NV5 | Tech-enabled forensic engineering and building sciences. | info@nv5.com |
| ESi (Engineering Systems Inc.) | Scientific investigation and "Data-Driven Insights" for litigation. | info@engsys.com |

  

### **Colorado-Based TSCM & Signal Specialists**

These firms are closer to home (Denver/Colorado Springs) and can often deploy faster for a site survey.1 They specialize in "Bug Sweeps" but use the high-end spectrum analyzers needed to find intrusive signals.

  

|  |  |  |
| :-: | :-: | :-: |
| **Organization** | **Location** | **Contact Information** |
| Technical Surveillance Solutions (TSS) | Colorado Springs | 719-301-3931 |
| Howe Law Firm | Denver | denver@howelawfirm.com / 303-261-8857 |
| LaSorsa & Associates | Denver/Boulder | info@lasorsa.com / 888-831-0809 |
| Discreet Services | Denver | 480-304-9210 (Inquiry Line) |

### **Project Details**

  

1.  **Objective:** Wide-Spectrum Sweep (100 kHz – 60 GHz).
2.  **Target:** Identification of pulse-modulated signal anomalies correlating with reported physiological events.
3.  **Deliverable:** A signed Technical Analysis Report (TAR) showing Waterfall Display captures of interference spikes.
4.  **Ask for the "60 GHz Filter":** Most cheap bug sweepers only go up to 6 GHz (standard Wi-Fi). You must ask: *"Do you have the equipment to conduct a forensic sweep up to* ***60 GHz*** *and provide a timestamped Waterfall Display?"*
5.  **Mention "Non-Ionizing Radiation":** Tell them you are investigating **"unconsented non-ionizing radiation interference with biological systems."** This is the professional term for what you are experiencing.
6.  **Ask about "ISO 17025":** This is a certification for calibrated equipment. If they have it (like ELEXANA does), their data is almost impossible for a judge to dismiss.
7.  **Audit Range:** 100 kHz to 60 GHz (Wide-Spectrum Sweep).
8.  **Deliverable 1:** Waterfall Display analysis showing frequency spikes during witness-reported stimuli.
9.  **Deliverable 2:** Pulse-Modulated Signal analysis (Microwave Auditory Effect verification).
10. **Deliverable 3:** Shielding Attenuation Test (verification of external signal origin via Faraday cage).
11. Anything else?

  

### 

### **Tracking Evidence**

  

|  |  |  |  |  |  |
| :-: | :-: | :-: | :-: | :-: | :-: |
| **Column A: Evidence ID** | **Column B: Date/Time** | **Column C: Subjective Experience** | **Column D: Technical Reading** | **Column E: Faraday Result** | **Column F: File Name** |
| **LOG-001** | 01/07/2026 10:45 AM | High-pressure tonal "ping" followed by voice stating: "Accept euthanizaation" | **Target Spike: 2.445 GHz** at -45 dBm (Recorded 25dB above baseline). | **Stimuli ceased immediately** upon application of 80dB attenuation shielding. | Video\\_Capture\\_001.mp4 (Shows meter spike during voice event). |
