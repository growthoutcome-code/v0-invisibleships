---
id: IS-REF-IMPACT-ZERSETZUNG-04
title: IS - Impact of Neuro-tech Zersetzung Tactics v01 — Sources
collection: reference
doc_type: section
source_doc_title: IS - Impact of Neuro-tech Zersetzung Tactics v01
source_doc_id: 1EfA-X5c0JyPaf3iwgYOTMeo3ZmCFa-zAZEnXdxgAoQc
source_url: "https://docs.google.com/document/d/1EfA-X5c0JyPaf3iwgYOTMeo3ZmCFa-zAZEnXdxgAoQc/edit"
categories: [analysis, analysis]
glossary_refs: [telepathic]
word_count: 110
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### Sources

- [Transparent Brain-Computer Interface Uses AI and Nanotech | Psychology Today](https://www.psychologytoday.com/us/blog/the-future-brain/202401/transparent-brain-computer-interface-uses-ai-and-nanotech)
  - [MIT AlterEgo - "Near Telepathic" Interface](https://www.media.mit.edu/projects/alterego/overview/)
  - [Zersetzung - Stasi Psychological Warfare](https://en.wikipedia.org/wiki/Zersetzung)
  - [eBay Stalking Scandal (Corporate Zersetzung)](https://www.justice.gov/usao-ma/pr/ebay-inc-pay-3-million-criminal-penalty-corporate-cyberstalking-campaign)
  - [Canada MAID Controversy - Veterans Offered Euthanasia](https://www.cbc.ca/news/politics/veterans-maid-rcmp-investigation-1.6663885)
  - [MKULTRA & Dr. Ewen Cameron (Montreal)](https://www.theguardian.com/world/2018/may/03/montreal-brainwashing-allan-memorial-institute)
