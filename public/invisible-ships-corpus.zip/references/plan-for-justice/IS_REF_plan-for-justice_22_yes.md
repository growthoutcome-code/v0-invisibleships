---
id: IS-REF-PLAN-FOR-JUSTICE-22
title: IS - Plan for Justice — Yes
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 49
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Yes

This module provides a legally structured yet accessible **Affidavit for Minors**, designed to capture the testimony of children and teenagers in a way that is admissible in court. It also includes the **"Guardian’s Verification"** to ensure the child’s account is protected and not dismissed as "active imagination."
