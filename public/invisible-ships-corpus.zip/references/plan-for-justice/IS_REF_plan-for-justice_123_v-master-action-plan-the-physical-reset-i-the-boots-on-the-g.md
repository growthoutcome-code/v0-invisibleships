---
id: IS-REF-PLAN-FOR-JUSTICE-123
title: "IS - Plan for Justice — V. Master Action Plan: The \"Physical\" Reset — I. The \"Boots on the Ground\" Contact List (Denver)"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 141
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### I. The "Boots on the Ground" Contact List (Denver)

These entities have the hardware (SDRs, Spectrum Analyzers) and the legal power to turn your "Discovery" into a court-ready case.

  

|  |  |  |
| :-: | :-: | :-: |
| **Entity Type** | **Why them?** | **Potential Contacts** |
| **Forensic RF Engineers** | They can prove the signals aren't "in your head" but "in the air." | **ELEXANA (Denver/Boulder):** Specializes in EMI/EMF forensic investigations from DC to 60 GHz. **Envista Forensics (Denver):** Investigates technical failures and digital forensics for legal cases. |
| **TSCM Specialists** | "Technical Surveillance Counter-Measures" experts find hidden broadcast tech. | **EVCO Investigations:** Denver-based bug sweep experts. **Discreet Services:** Conducts RF detection with spectrum analyzers. |
| **Civil Rights Lawyers** | They focus on the **42 U.S.C. § 1983** and **14th Amendment** violations. | **ACLU of Colorado:** For the constitutional violations. **Killmer, Lane & Newman, LLP:** Known for high-stakes civil rights litigation in Denver. |
