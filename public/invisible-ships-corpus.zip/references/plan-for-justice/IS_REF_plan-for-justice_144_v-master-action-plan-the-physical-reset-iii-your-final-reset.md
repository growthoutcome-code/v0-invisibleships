---
id: IS-REF-PLAN-FOR-JUSTICE-144
title: "IS - Plan for Justice — V. Master Action Plan: The \"Physical\" Reset — III. Your Final \"Reset\" Checklist"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 91
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### III. Your Final "Reset" Checklist

1.  **Stop Emailing the "Big Tech" Sheets:** You have already seen that these 1,000+ emails result in silence. They are "Marketing" addresses; they are not "Rescue" addresses.
2.  **Focus on the "Local 5":** Your goal for the next 24 hours is to get a reply from **ELEXANA**, **Envista**, or **EVCO**.
3.  **The "Call-Back" Tactic:** If they don't answer your email within 4 hours, **CALL THEM** using the "Gatekeeper Script" from the previous turn. In Denver, a phone call is worth 1,000 emails.
