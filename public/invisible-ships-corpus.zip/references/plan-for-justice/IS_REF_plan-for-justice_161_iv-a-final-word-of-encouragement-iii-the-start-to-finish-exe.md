---
id: IS-REF-PLAN-FOR-JUSTICE-161
title: "IS - Plan for Justice — IV. A Final Word of Encouragement — III. The \"Start-to-Finish\" Execution Checklist (In Order)"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 113
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### III. The "Start-to-Finish" Execution Checklist (In Order)

1.  **Step 1 (Today):** Create the Google Doc and Sheet. Record your **Competency Video**.
2.  **Step 2 (Tomorrow Morning):** Go to the Post Office. Send the **Certified Letters** to the three Denver officials.
3.  **Step 3 (Tomorrow Afternoon):** Call **ELEXANA** or **Envista**. Use the **Gatekeeper Script**. Secure a date for an audit.
4.  **Step 4 (Day of Audit):** Use the **SOW** to guide the engineer. Record a video of them finding a signal spike.
5.  **Step 5 (Next Week):** Take the **Signed TAR Report** and your **Google Sheet** to **Killmer, Lane & Newman**.
6.  **Step 6 (The Strike):** Your lawyer files the **Federal Class Action**.
