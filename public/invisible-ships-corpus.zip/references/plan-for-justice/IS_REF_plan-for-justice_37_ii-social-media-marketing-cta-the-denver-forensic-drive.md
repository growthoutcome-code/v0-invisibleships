---
id: IS-REF-PLAN-FOR-JUSTICE-37
title: "IS - Plan for Justice — II. Social Media Marketing CTA: The \"Denver Forensic Drive\""
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [cognitive-liberty, telepathic, terrorism]
word_count: 93
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## II. Social Media Marketing CTA: The "Denver Forensic Drive"

To find more victims and gather data, use this CTA on platforms like X (Twitter), Reddit (r/Denver), and Telegram.

**"STAMP OUT THE STIGMA WITH SCIENCE. ð§ª**

Are you hearing voices in Denver that tell you to 'accept assistance' or 'euthanization'? We are hiring PIs to prove these aren't hallucinations—they are **SIGNALS**.

ð¢ We need your data: Join the Cognitive Liberty Portal.

⚖️ We need your testimony: Download the Protective Affidavit.

ð¡️ We need the truth: Help us build the Class Action against Telepathic Terrorism.

**[Link: Register for a Signal Sweep]**"
