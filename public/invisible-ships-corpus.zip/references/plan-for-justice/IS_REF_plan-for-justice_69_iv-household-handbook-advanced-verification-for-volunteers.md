---
id: IS-REF-PLAN-FOR-JUSTICE-69
title: "IS - Plan for Justice — IV. Household Handbook: Advanced Verification for Volunteers"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [telepathic, terrorism]
word_count: 70
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## IV. Household Handbook: Advanced Verification for Volunteers

When a volunteer visits a household, they must follow the **"Signal Baseline"** protocol:

1.  **Faraday Test:** Place the victim's primary device (or the victim themselves, if possible) in a Faraday-shielded area.
2.  **Comparison:** Does the "Telepathic Terrorism" stop or change when the RF signals are blocked?
3.  **The Affidavit Update:** Record the results of the Faraday test in the user's **Discovery Log** as "Physical Proof of Interference."
