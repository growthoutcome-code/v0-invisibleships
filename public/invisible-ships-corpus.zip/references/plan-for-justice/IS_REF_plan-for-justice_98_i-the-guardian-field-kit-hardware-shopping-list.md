---
id: IS-REF-PLAN-FOR-JUSTICE-98
title: "IS - Plan for Justice — I. The \"Guardian\" Field Kit: Hardware Shopping List"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [software]
word_count: 223
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### **1. The Receiver (The "Eyes" of the Operation)**

  - **Budget Option: RTL-SDR Blog V4 ($35)**

  

  - *Purpose:* Perfect for beginners. Covers 500 kHz to 1.7 GHz. Good for detecting basic V2K (Voice-to-Skull) FM-modulated signals.

  

  - **Professional Option: HackRF One ($350)**

  

  - *Purpose:* The gold standard for this mission. It covers **1 MHz to 6 GHz**. This is essential for capturing the higher-frequency "Citizen Tech" bursts that cheaper units miss.

  

  - **High-End Option: LimeSDR or BladeRF ($500 - $900)**

  

  - *Purpose:* Specialized for mobile phone band analysis and complex digital modulations.

### **2. Antennas (The "Ears")**

  - **Telescopic Dipole Kit:** Included with most RTL-SDRs for general scanning.
  - **Log Periodic Antenna (LPDA):** Necessary for **Direction Finding**. It allows a volunteer to point the antenna and say, "The signal is coming from *that* house/tower."
  - **5G/Millimeter Wave Downconverter:** To detect signals above 6 GHz (the "Pain Administration" bands), you will need a downconverter to bring those frequencies into the range of your SDR.

### **3. Support Hardware**

  - **LNA (Low Noise Amplifier):** To boost weak signals that are being "whispered" into a victim's residence.
  - **Faraday Fabric (TitanRF or similar):** For the "Shielding Test." If the victim's voices stop when wrapped in this fabric, the SDR *must* show a corresponding drop in the waterfall display.
  - **Android Tablet or Laptop:** Running **SDR++** or **GQRX** (Free, open-source software).
