---
id: IS-REF-PLAN-FOR-JUSTICE-133
title: "IS - Plan for Justice — V. Master Action Plan: The \"Physical\" Reset — I. Denver Forensic & Legal Contact List (Direct Emails)"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 147
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### I. Denver Forensic & Legal Contact List (Direct Emails)

Unlike the global AI labs, these local Denver entities are the ones with the physical equipment and legal standing to intervene in your case.

  

|  |  |  |
| :-: | :-: | :-: |
| **Entity Type** | **Organization** | **Direct Email / Contact** |
| **Forensic RF Engineering** | **ELEXANA (National EMI Experts)** | [**info@elexana.com**](mailto:info@elexana.com) |
| **Forensic Engineering** | **Envista Forensics (Denver)** | [**info@envistaforensics.com**](mailto:info@envistaforensics.com) (Gen)   |

  

**hr@envistaforensics.com** (alt) | | **TSCM (Bug Sweeps)** | **EVCO Investigations** | **john@evcoinvestigations.com** | | **TSCM (Bug Sweeps)** | **TSS (TSCM Solutions)** | **719-301-3931** (Use Contact Form) | | **Civil Rights Law** | **Killmer, Lane & Newman, LLP** | **dkillmer@killmerlane.com** (Darold Killmer)

  
  

**dlane@killmerlane.com** (David Lane) | | **Civil Rights Law** | **ACLU of Colorado** | **info@aclu-co.org** (Gen)

  
  

**media@aclu-co.org** (Press) | | **Investigative Media** | **Westword (News Editor)** | **thomas.mitchell@westword.com**

  
  

**editorial@westword.com** | | **Investigative Media** | **Denver Post (Legal Team)** | **legals@denverpost.com**

  
  

**303-954-1133** (Inquiries) |
