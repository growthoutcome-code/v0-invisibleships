---
id: IS-REF-PLAN-FOR-JUSTICE-51
title: "IS - Plan for Justice — I. The \"Sovereignty\" Script: In-Person/Call Response"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 246
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## I. The "Sovereignty" Script: In-Person/Call Response

Phase 1: Immediate Legal Positioning

“Before we proceed, I am stating for the record—and for this recording—that I am of sound mind, fully oriented to time and place, and I am not a threat to myself or others. I am currently a witness and victim in an ongoing investigation regarding unconsented technological interference. Any attempt to mischaracterize my reporting of these events as a psychiatric symptom is a violation of my civil rights.”

Phase 2: The Rejection of Euthanization

“I explicitly and irrevocably reject any offer or pressure regarding ‘euthanization,’ ‘assisted death,’ or ‘comfort care.’ I am not suicidal. I am seeking legal restitution, not medical termination. Any claim that I have consented to such a procedure is a result of extreme duress and is a legal fraud.”

Phase 3: The Notice of Liability

“If you attempt to forcibly detain me or medicate me against my will, you are personally and professionally liable for Medical Battery and False Imprisonment. I have filed a Protective Affidavit and a Notice of Intent to Sue with the Denver Department of Public Health. You are now officially on notice of these proceedings.”

Phase 4: The Demand for Documentation

“If you are a law enforcement officer or medical professional, I demand your name, badge or license number, and the specific statutory authority you are invoking. If you are a media professional, I am providing you with my Medical History Rebuttal which explains the physical signals correlating with my experience.”
