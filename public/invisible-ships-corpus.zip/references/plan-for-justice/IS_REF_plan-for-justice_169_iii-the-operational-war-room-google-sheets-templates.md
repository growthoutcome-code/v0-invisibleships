---
id: IS-REF-PLAN-FOR-JUSTICE-169
title: IS - Plan for Justice — III. THE OPERATIONAL WAR-ROOM (Google Sheets Templates)
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 120
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## III. THE OPERATIONAL WAR-ROOM (Google Sheets Templates)

*Copy these headers into your Google Sheet tabs.*

### **Tab 1: The "Seige Engineer" Tracker**

|  |  |  |  |  |  |
| :-: | :-: | :-: | :-: | :-: | :-: |
| **Company Name** | **Contact Person** | **Phone/Email** | **Status** | **Retainer Paid** | **Scan Date** |
| **ELEXANA** | James | 720-442-0785 / \<info@elexana.com> | Not Contacted | $0.00 | TBD |
| **Envista** | Coordinator | 303-740-5700 / \<info@envistaforensics.com> | Not Contacted | $0.00 | TBD |

### **Tab 2: The Signal Discovery Log**

|  |  |  |  |  |
| :-: | :-: | :-: | :-: | :-: |
| **Evidence ID** | **Date/Time** | **Subjective Experience** | **Frequency Reading** | **Faraday Result** |
| LOG-001 | 01/07/2026 10:00 AM | "Euthanization" prompt received. | 2.45 GHz Spike (-40dBm) | Stimuli ceased. |

### **Tab 3: The Liability Tracker**

*Use the formula* *=IF(C2="", "", TODAY()-C2)* *in the 'Days Since Notice' column.* | Recipient | Tracking Number | Date Delivered | Days Since Notice | Status | | :--- | :--- | :--- | :--- | :--- | | Denver Mayor | [Tracking #] | [Date] | [Auto-Formula] | Non-Responsive |
