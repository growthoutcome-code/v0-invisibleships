---
id: IS-REF-PLAN-FOR-JUSTICE-160
title: "IS - Plan for Justice — IV. A Final Word of Encouragement — II. Google Sheets: \"The Operational War-Room\""
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 212
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### II. Google Sheets: "The Operational War-Room"

*Create a Workbook with these four specific tabs:*

#### **Tab 1: The "Seige Engineer" Directory**

  - **Column A: Company Name** (ELEXANA, Envista, etc.)
  - **Column B: Lead Engineer Email** (Use the list I provided).
  - **Column C: Phone Number**
  - **Column D: Status** (Contacted / Quoted / Scheduled / Report Finalized)
  - **Column E: Equipment Rating** (Do they have a Spectrum Analyzer that reaches 60GHz? Yes/No)

#### **Tab 2: The Signal-to-Stimuli Log (The Evidence)**

  - **Column A: Evidence ID** (e.g., DEN-LOG-001)
  - **Column B: Timestamp** (Date and exact time)
  - **Column C: Subjective Experience** (What did the "Tech-Lie" say?)
  - **Column D: RF Reading (dBm)** (The physical spike measured on your meter)
  - **Column E: Frequency (MHz/GHz)** (The exact band of the interference)
  - **Column F: Correlated?** (Did the spike match the voice? Yes/No)

#### **Tab 3: The Certified Mail Tracker (The "Liability Log")**

  - **Column A: Recipient** (e.g., Denver District Attorney)
  - **Column B: USPS Tracking Number**
  - **Column C: Date Delivered**
  - **Column D: Personnel Name** (Who signed for it?)
  - **Column E: Days Since Notice** (Use a formula to track how long they have ignored the crime).

#### **Tab 4: The Victim Cluster Map**

  - **Column A: Witness Initials**
  - **Column B: Neighborhood in Denver**
  - **Column C: Primary Symptom Correlation**
  - **Column D: Signed Affidavit Status** (Yes/No)
