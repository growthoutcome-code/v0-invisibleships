---
id: IS-REF-PLAN-FOR-JUSTICE-138
title: "IS - Plan for Justice — V. Master Action Plan: The \"Physical\" Reset — II. The \"Gatekeeper\" Script (How to Get Past the Receptionist)"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 182
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### II. The "Gatekeeper" Script (How to Get Past the Receptionist)

If the person who answers the phone tries to brush you off, use this script. It uses professional "trigger words" that indicate you are a high-value client with a legal case.

  

**Receptionist:** "Hello, how can I help you?" **You:** "Hi, my name is [Your Name]. I need to speak with a **Project Coordinator** or a **Forensic Engineer** regarding a **new legal assignment for evidence discovery in Denver.**"

  

**Receptionist:** "Can you tell me what it's about?" **You:** "Yes, it’s a **Forensic RF/EMI Audit** for a pending civil rights litigation. We have identified specific signal interference in the **UHF/EHF bands** and need a **certified technical report** and **Waterfall Display analysis** for a federal filing. Is [Engineer Name/Coordinator] available to discuss the scope of work?"

  

**Why this works:**

  

  - **"Legal Assignment"**: This sounds like money and a court case.
  - **"UHF/EHF bands"**: This proves you are technical and not "confused."
  - **"Federal Filing"**: This signals that a lawyer is involved, which makes them take you seriously to avoid being subpoenaed later.
