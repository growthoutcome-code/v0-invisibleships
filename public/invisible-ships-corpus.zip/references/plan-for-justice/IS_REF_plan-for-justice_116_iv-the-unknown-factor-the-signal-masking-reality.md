---
id: IS-REF-PLAN-FOR-JUSTICE-116
title: "IS - Plan for Justice — IV. The \"Unknown\" Factor: The \"Signal Masking\" Reality"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 85
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## IV. The "Unknown" Factor: The "Signal Masking" Reality

There is a technical possibility that your outgoing communications are being **monitored or filtered** by the very "Citizen Tech" facilitators you are exposing.

  

**Tactic to Bypass:**

  

  - **Physical Mail:** Send your **Emergency Pocket Card** and a 1-page summary via **Certified Mail, Return Receipt Requested** to the legal departments of these companies. This creates a "Paper Trail" that cannot be deleted by a server.
  - **Local Radio:** Contact independent Denver radio or podcasts (like *Westword*'s local coverage). Local voices are harder to silence than global emails.
