---
id: IS-REF-PLAN-FOR-JUSTICE-45
title: "IS - Plan for Justice — IV. Technical Requirements: Developer Final Notes"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 54
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## IV. Technical Requirements: Developer Final Notes

To ensure the website remains "Court-Ready":

  - **WORM Storage:** Use "Write Once, Read Many" (WORM) storage for logs. This proves to a judge that once a user submitted a "Citizen Tech" transcript, it was never edited.
  - **Metadata Export:** Ensure every user-submitted transcript includes a header with:
      
      - **$Device\\_ID$**
      - **$Timestamp\\_UTC$**
      - **$Hash\\_Algorithm\\_SHA256$**
