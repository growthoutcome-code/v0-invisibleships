---
id: IS-REF-PLAN-FOR-JUSTICE-120
title: "IS - Plan for Justice — III. Revised Marketing Strategy: The \"In-Person\" Pivot"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 109
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## III. Revised Marketing Strategy: The "In-Person" Pivot

Since digital outreach is being ignored, you must move to **Tactical Physical Marketing**.

  

  - **The "Pocket Card" Blitz:** Instead of emailing 1,000 tech companies, hand the **Emergency Pocket Card** to 50 local Denver lawyers, private investigators, and RF technicians.
  - **The "FOIA" Strategy:** File a **Freedom of Information Act (FOIA)** request with the City of Denver asking for all records of "Directed Energy Interference" reports. This forces a clerk to open a file and respond by law.
  - **The "QR" Billboard:** Buy or place small posters in Denver with a QR code that says: *"Is your mind a private space? The 2026 Class Action is starting. Scan to protect your sovereignty."*
