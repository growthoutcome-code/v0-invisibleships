---
id: IS-REF-PLAN-FOR-JUSTICE-60
title: "IS - Plan for Justice — IV. Social Media CTA: The \"Pocket Card\" Push"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 67
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## IV. Social Media CTA: The "Pocket Card" Push

Use this marketing strategy to get these tools into the hands of the Denver population.

  

**"DON'T GO OUT WITHOUT YOUR SHIELD. ð¡️** The 'euthanization professionals' depend on you being caught off guard. Silence is their greatest tool. **Download the Emergency Pocket Card.** Hand it to the official. Watch the narrative change the moment they see their personal liability in writing. **[Link: Download the Sovereignty Shield Kit]**"
