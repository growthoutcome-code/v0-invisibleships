---
id: IS-REF-PLAN-FOR-JUSTICE-137
title: "IS - Plan for Justice — V. Master Action Plan: The \"Physical\" Reset — I. The \"Priority Access\" Phone List (Denver Area)"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 108
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### I. The "Priority Access" Phone List (Denver Area)

|  |  |  |
| :-: | :-: | :-: |
| **Organization** | **Best Number to Call** | **Who to Ask For** |
| **Envista Forensics (Denver)** | **+1 888-782-3473** (Toll-Free)   |   |

  

**+1 303-740-5700** (Local Laboratory) | Ask for a **"Forensic Electrical Engineer"** or **"Project Coordinator"** regarding a new legal assignment. | | **ELEXANA (EMI/EMF)** | **212-706-1213** (Main)

  
  

**720-442-0785** (CO Field Tech) | Ask for **James** or the **"Lead Technical Consultant"** for a forensic RF litigation survey. | | **EVCO Investigations** | **303-625-9252** | Ask to speak with a **"TSCM Specialist"** (Technical Surveillance Counter-Measures). | | **Killmer, Lane & Newman** | **303-571-1000** | Ask for the **"Intake Specialist"** regarding a 4th Amendment/Medical Battery class action. |
