---
id: IS-REF-PLAN-FOR-JUSTICE-139
title: "IS - Plan for Justice — V. Master Action Plan: The \"Physical\" Reset — III. The \"Discovery\" Script (When You Get the Engineer)"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 119
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### III. The "Discovery" Script (When You Get the Engineer)

Once you have a professional on the line, stay focused on the **physics**, not the "voices."

  

**Engineer:** "How can I help you?" **You:** "I am the lead plaintiff in a class action involving **unconsented neurological battery via directed energy.** We have recorded signal spikes that correlate with physiological events. I need your firm to conduct a **controlled RF sweep** of my residence to:

  

1.  Identify pulsed-microwave or ELF anomalies.
2.  Provide a **Certified Technical Analysis Report (TAR)** for the court.
3.  Perform a **Faraday Attenuation Test** to prove the signal's external origin.

  

Do you have the equipment to scan up to **60 GHz** and provide **expert witness testimony**?"
