---
id: IS-REF-PLAN-FOR-JUSTICE-54
title: "IS - Plan for Justice — IV. Household Handbook: The \"In-Person\" Drills"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 81
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## IV. Household Handbook: The "In-Person" Drills

To ensure everyone in the household can use these scripts under pressure, the handbook recommends **"Verbal Defense Drills."**

1.  **The "Check-In" Drill:** A housemate acts as a "corrupt official" and tries to get the other to "accept assistance." The responder must use the **Sovereignty Script** without breaking character.
2.  **The "Recording" Drill:** Practice immediately turning on a phone camera or Google Meet recording and stating: *"This session is being recorded for the Discovery Log of the 2026 Class Action Lawsuit."*
