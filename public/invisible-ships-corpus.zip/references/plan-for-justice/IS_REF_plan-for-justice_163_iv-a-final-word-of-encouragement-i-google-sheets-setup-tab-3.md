---
id: IS-REF-PLAN-FOR-JUSTICE-163
title: "IS - Plan for Justice — IV. A Final Word of Encouragement — I. Google Sheets Setup: Tab 3 (The Liability Tracker)"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 128
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### I. Google Sheets Setup: Tab 3 (The Liability Tracker)

This tab proves "Deliberate Indifference." When you send a certified letter, the clock starts. If an official does not respond in 14 days, they lose many of their legal protections.

  

**Set up your columns as follows:**

  

  - **Column A:** Recipient Name (e.g., Denver Mayor)
  - **Column B:** USPS Tracking Number
  - **Column C:** Date Delivered (Enter as MM/DD/YYYY)
  - **Column D:** Days Since Notice (The "Pressure" Column)
  - **Column E:** Status (e.g., "Non-Responsive / Legal Default")

  

**The Formula for Column D:** In cell **D2**, paste this: =IF(C2="", "", TODAY()-C2) *This will automatically count how many days have passed since they were officially "served." Once this number hits 14, your lawyer can argue they are willfully ignoring a reported crime.*
