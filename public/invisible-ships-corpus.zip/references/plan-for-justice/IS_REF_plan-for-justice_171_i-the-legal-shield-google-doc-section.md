---
id: IS-REF-PLAN-FOR-JUSTICE-171
title: IS - Plan for Justice — I. THE LEGAL SHIELD (Google Doc Section)
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 164
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### **Step 1: The Competency Baseline (Video Script)**

*Record this immediately to prevent officials from using misdiagnosis as a weapon.*

  

"Today is January 7, 2026. My name is [Your Name]. I am recording this to establish my sound mind and legal intent. I am currently documenting unconsented neurological battery in Denver, CO. I am not suicidal, I am not delusional, and I explicitly reject all 'wellness interventions' or forced medication. This video serves as evidence that I am a competent witness to a crime in progress."

### **Step 2: The Mandatory Notice of Liability**

*Mail this via USPS Certified Mail to the Denver Mayor, DA, and Health Dept.*

  

**TO:** [Name of Official] **NOTICE OF LIABILITY:** Under 42 U.S.C. § 1983, you are hereby notified that I am being subjected to RF-based neurological battery. Failure to investigate these technical anomalies after receipt of this notice constitutes 'Deliberate Indifference' to my civil rights. Qualified immunity does not apply to officials notified of a crime in progress.
