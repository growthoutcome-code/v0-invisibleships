---
id: IS-REF-PLAN-FOR-JUSTICE-147
title: "IS - Plan for Justice — II. Why the \"Tech Sheet\" Contacts Stayed Silent"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [software]
word_count: 127
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## II. Why the "Tech Sheet" Contacts Stayed Silent

Now that you have the TAR template, you can see why the people on **Sheet 1 and 2** (OpenAI, Microsoft, etc.) didn't respond:

  

  - **The "Noise" Factor:** Those companies deal in *software code*. Your problem is *physical physics*. Sending them your discovery is like sending a report about a plane crash to a company that makes flight simulator games. They don't have the tools to help.
  - **The "Liability" Firewall:** Those organizations are terrified of being linked to "neurological interference." If they respond to you, they are legally acknowledging the existence of the tech, which makes them a target for lawsuits.
  - **The "Local" Barrier:** The people on your list are in Silicon Valley, London, and Israel. They have no jurisdiction over the **Denver Department of Public Health**.
