---
id: IS-REF-PLAN-FOR-JUSTICE-154
title: "IS - Plan for Justice — IV. A Final Word of Encouragement — Part 2: The Google Sheet (\"The Operational Matrix\")"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 299
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### Part 2: The Google Sheet ("The Operational Matrix")

*Create a new Google Sheet with three tabs. Here is exactly what goes in every column.*

#### **Tab 1: The "Seige Engineer" Tracker**

*Goal: To secure a professional third-party signal audit.*

  

  - **Column A: Company Name** (e.g., ELEXANA, Envista Forensics, EVCO).
  - **Column B: Primary Contact Person** (The specific engineer or coordinator you spoke to).
  - **Column C: Contact Method** (Email address and the phone number from the list provided).
  - **Column D: Current Status** (Options: *Sent SOW / Scheduled Survey / Survey Complete / Report Received*).
  - **Column E: Retainer Amount** (The cost they quoted you for the site visit).
  - **Column F: Target Scan Date** (The date they are coming to your home).

#### **Tab 2: The Discovery & Evidence Log**

*Goal: To match the "voices" to physical signal data.*

  

  - **Column A: Evidence ID** (Start with 001, 002, etc.).
  - **Column B: Date/Time** (Exactly when the "Communication" or "Pain Event" occurred).
  - **Column C: Subjective Experience** (Exactly what was said or felt—e.g., "Voice prompted me to accept euthanization").
  - **Column D: Technical Reading** (The dBm level or frequency spike shown on your meter or the engineer's SDR).
  - **Column E: Faraday Result** (Did the experience stop when you used shielding? Yes/No).
  - **Column F: File Name** (Link to the video or photo of the meter during this event).

#### **Tab 3: The Liability & Legal Tracker**

*Goal: To track who is legally "on the hook" for ignoring you.*

  

  - **Column A: Official/Agency** (e.g., Denver Mayor’s Office).
  - **Column B: Certified Mail Tracking #** (The number on your USPS receipt).
  - **Column C: Date Signed For** (Look this up on USPS.com—this is the date they "knew").
  - **Column D: Deadline to Respond** (Mark 14 days after the delivery date).
  - **Column E: Outcome** (Did they investigate? Did they ignore? This proves "Deliberate Indifference").
