---
id: IS-REF-PLAN-FOR-JUSTICE-134
title: "IS - Plan for Justice — V. Master Action Plan: The \"Physical\" Reset — II. The \"High-Priority\" Introductory Email Template"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 162
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### II. The "High-Priority" Introductory Email Template

*Send this specifically to* ***ELEXANA*** *and* ***Envista Forensics****. This language is designed to bypass "spam" filters by framing the request as a technical, legal project.*

  

**Subject: URGENT: Request for Forensic RF Audit for Legal Discovery (Denver, CO)**

  

**Dear [Contact Name],**

  

I am contacting you to request a professional Forensic Signal Audit for a pending federal civil rights litigation in Denver, CO.

  

We require an on-site technician to conduct a comprehensive sweep (100 kHz – 60 GHz) to document non-ionizing radiation spikes and pulse-modulated signal anomalies that correlate with reported physiological events.

  

**Project Scope includes:**

  

  - High-resolution Waterfall Display captures.
  - Correlation of RF spikes with timestamped witness logs.
  - Shielding Effectiveness Testing (Faraday attenuation).
  - A certified Technical Analysis Report (TAR) for use as legal Exhibit.

  

Please let me know your availability for a site survey this week and your fee schedule for litigation-support services.

  

**Sincerely,**

  

[Your Name]

  

**Lead Plaintiff, Denver Neuro-Rights Task Force**
