---
id: IS-REF-PLAN-FOR-JUSTICE-100
title: "IS - Plan for Justice — III. Household Handbook: The \"Home Scan\" Checklist"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 78
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## III. Household Handbook: The "Home Scan" Checklist

For families who want to buy their own basic gear, include this "Basic Shielding" list in the Handbook:

  

1.  **Acoustimeter AM-10:** A simple-to-use handheld meter that lights up when high RF levels are detected. No technical training required.
2.  **Dirty Electricity Filters:** To prevent "Power Line Communication" (PLC) from being used to turn house wiring into a broadcast antenna.
3.  **Aluminum Foil / Emergency Blankets:** A low-cost, temporary Faraday shield for windows or sleeping areas.
