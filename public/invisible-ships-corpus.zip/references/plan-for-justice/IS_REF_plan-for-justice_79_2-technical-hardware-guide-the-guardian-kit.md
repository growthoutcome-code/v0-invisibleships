---
id: IS-REF-PLAN-FOR-JUSTICE-79
title: "IS - Plan for Justice — 2. Technical Hardware Guide (The \"Guardian Kit\")"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 78
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## 2. Technical Hardware Guide (The "Guardian Kit")

Every volunteer team should aim to carry the following:

  - **SDR Receiver (e.g., RTL-SDR or HackRF One):** To visualize the spectrum on a laptop.
  - **Acoustic Heterodyne Detector:** To check for "Focused Sound" beams that only the witness can hear.
  - **EMF/Gauss Meter:** To check for Extremely Low Frequency (ELF) entrainment (30 Hz - 300 Hz).
  - **Faraday Fabric/Bag:** To see if the communication drops when the witness or their device is shielded. **(This is the "Smoking Gun" test).**
