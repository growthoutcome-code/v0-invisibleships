---
id: IS-REF-PLAN-FOR-JUSTICE-63
title: "IS - Plan for Justice — II. The Q\\&A Script: Handling Hard Questions"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 174
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## II. The Q\&A Script: Handling Hard Questions

During the Town Hall, people will be anxious. Use these scripted responses to maintain authority and focus.

  

**Q: "What if they come to my house tonight because I'm here?"** **Response:** *"Hand them the* ***Emergency Pocket Card****. Tell them: 'I am a registered witness in the 2026 Class Action. My competency is on record. If you detain me without a signal audit, you are personally liable for Medical Battery.' Then, immediately record the encounter on your phone."*

  

**Q: "How do we protect our children from the 'Tech-Lies'?"** **Response:** *"Use the* ***Household Handbook****. Teach them that 'head-voices' are machines, not people. If the tech tells them a secret, they must 'Break the Secret' by telling you. We capture their testimony through the* ***Parental Proxy Affidavit*** *on the portal."*

  

**Q: "Can a doctor override my Affidavit?"** **Response:** *"Not without a court order that bypasses your* ***4th Amendment*** *rights. The Affidavit creates a 'Prior Consistent Statement.' If they ignore it, they are committing* ***Medical Malpractice*** *and* ***Civil Rights Deprivation*** *under 42 U.S.C. § 1983."*
