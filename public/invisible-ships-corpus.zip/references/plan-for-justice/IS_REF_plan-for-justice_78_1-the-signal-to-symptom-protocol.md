---
id: IS-REF-PLAN-FOR-JUSTICE-78
title: "IS - Plan for Justice — 1. The \"Signal-to-Symptom\" Protocol"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [software]
word_count: 110
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
disclaimer: meta/IS_META_terms.md
---

## 1. The "Signal-to-Symptom" Protocol

Our primary goal is to prove that "voices" are **data packets**, not biological hallucinations.

### **The Workflow:**

1.  **Baseline Reading:** Upon entering a residence, record the "Background RF Noise." Note the presence of Wi-Fi routers, smart meters, and cell towers.
2.  **The Trigger Event:** When the witness reports an "Attack," "V2K Communication," or "Euthanization Prompt," immediately begin a high-resolution scan.
3.  **Frequency Targeting:** Focus on the **300 MHz – 3 GHz** (UHF) and **60 GHz** (Millimeter Wave) bands.
4.  **Audio Correlation:** Use an SDR (Software Defined Radio) to see if the visual "spikes" in the waterfall display move in rhythm with the witness's description of the "voice" or "pain."

---

## Critical Disclaimer on Transcripts and Accusations

Transcripts and statements recorded in this archive are external communications and do NOT represent the author's beliefs, views, or intent. Nothing here accuses, blames, or alleges malfeasance by any named person, company, or government body, and all of this information requires independent verification.

The full Critical Disclaimer, copyright and terms are in meta/IS_META_terms.md, and at https://www.invisibleships.com/disclaimer.
