---
id: IS-REF-PLAN-FOR-JUSTICE-142
title: "IS - Plan for Justice — V. Master Action Plan: The \"Physical\" Reset — FORENSIC EXHIBIT: Technical Analysis Report (TAR) Template"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 333
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### FORENSIC EXHIBIT: Technical Analysis Report (TAR) Template

**CASE REF:** *2026-CV-DEN-NEURO* **LOCATION:** [Your Address/Denver, CO]

  

**FIELD ENGINEER:** __________________________

  

**EQUIPMENT USED:** [e.g., HackRF One / Spectrum Analyzer / Narda NBM-550]

#### **1. AMBIENT BASELINE (Control Group)**

  - **Time of Baseline:** _______________
  - **Noise Floor (dBm):** _______________
  - **Identified Constant Sources:** (e.g., Local 5G Small Cell, Smart Meter, Wi-Fi 6E)

#### **2. TRIGGER EVENT CORRELATION (The Test)**

  - **Event Start Time:** _______________
  - **Witness Report:** [e.g., "High-pitched tonal communication" / "Coerced euthanization prompt"]
  - **Measured RF Spike (Frequency):** _______________ **(MHz/GHz)** * **Modulation Type:** ☐ Pulsed ☐ Continuous Wave ☐ Frequency Hopping
  - **Amplitude Delta:** _________ **dB** (Increase over baseline)

#### **3. SHIELDING ATTENUATION (Faraday Test)**

  - **Unshielded Power Level:** _______________
  - **Shielded Power Level (TitanRF/Copper Mesh):** _______________
  - **Biological Correlation:** ☐ YES ☐ NO *(Did the witness report a cessation of stimuli while shielded?)*

#### **4. ENGINEER’S STATEMENT**

*"I, __________________________, a certified forensic professional, certify that the recorded spikes are external to the witness and represent an intrusive electromagnetic interaction with the environment."*

  

**Signature:** __________________________ **Date:** January 7, 2026
