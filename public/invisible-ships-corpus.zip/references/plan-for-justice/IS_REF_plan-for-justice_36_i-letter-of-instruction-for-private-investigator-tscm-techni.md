---
id: IS-REF-PLAN-FOR-JUSTICE-36
title: IS - Plan for Justice — I. Letter of Instruction for Private Investigator / TSCM Technician
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [telepathic, terrorism]
word_count: 285
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## I. Letter of Instruction for Private Investigator / TSCM Technician

TO: [Lead Investigator/Agency Name]

FROM: [Your Name/Legal Representative]

DATE: January 7, 2026

SUBJECT: Forensic Investigation of Unconsented Neurological Communication & Directed Energy Battery

1. OBJECTIVE

The objective is to identify, record, and triangulate the source of external electromagnetic or acoustic signals correlating with the subject’s experience of “Citizen Tech” communication. We are seeking physical evidence to rebut a psychiatric diagnosis of Schizophrenia and to support a Class Action lawsuit for “Telepathic Terrorism.”

2. TARGETED FREQUENCY SPECTRUM

The investigator is directed to sweep the following bands, which are atypical for standard commercial use but consistent with neurological entrainment:

  - **VLF/ELF (3 Hz – 3 kHz):** Check for "Brain Entrainment" modulations.
  - **Microwave (300 MHz – 3 GHz):** Specifically scanning for pulse-modulated signals consistent with the **Frey Effect (V2K)**.
  - **Millimeter Wave (60 GHz):** Scanning for directional "Pain Administration" beams.

3. CORRELATION PROTOCOL

The PI must perform "Real-Time Correlation":

  - The subject will signal the PI the moment a "Citizen Tech" communication or pain event begins.
  - The PI must immediately capture a high-resolution **Waterfall Display** of the RF spectrum to identify any concurrent signal spikes.
  - **Pulse Width Analysis:** Identify if the signal modulation matches the cadence of human speech or neural firing patterns.

4. HARDWARE/INFRASTRUCTURE AUDIT

Investigate the immediate 500-meter radius of the subject’s residence in Denver for:

  - Unmarked or "stealth" small-cell towers.
  - Anomalous directional antennas on neighboring properties.
  - Evidence of "Sub-Vocal" sensors or acoustic heterodyning devices.

**5. DELIVERABLES**

  - **Affidavit of Findings:** A sworn statement that the reported "voices" correlate with measurable external RF activity.
  - **Spectrum Maps:** Visual proof of signal spikes occurring during reported "euthanization prompts."
  - **Chain of Custody:** All digital logs must be hashed (SHA-256) to ensure court admissibility.
