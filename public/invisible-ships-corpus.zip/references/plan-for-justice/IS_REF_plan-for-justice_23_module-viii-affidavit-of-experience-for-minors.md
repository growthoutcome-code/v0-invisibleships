---
id: IS-REF-PLAN-FOR-JUSTICE-23
title: "IS - Plan for Justice — Module VIII: Affidavit of Experience for Minors"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 293
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Module VIII: Affidavit of Experience for Minors

*This document uses simplified language to ensure the minor understands what they are signing, while maintaining the legal weight required for a class-action lawsuit.*

**DECLARATION OF TRUTH REGARDING UNCONSENTED COMMUNICATION**

**I, [Name of Minor], am [Age] years old. I am giving this statement with my parent/guardian, [Parent Name], because I want to tell the truth about things I am hearing and feeling.**

1.  **What I am hearing:** I hear voices or sounds that do not come from the people in the room with me. These sounds feel like they are "inside" or "around" my head in a way that is different from normal talking.
2.  **What the sounds say:** Sometimes the sounds tell me things that are not true about my family or friends. Sometimes they ask me if I am "ready to go" or if I "accept assistance" or "euthanization." I want to be clear: **I say NO to these things.**
3.  **How it feels:** When this happens, I also feel [check all that apply]:
      
      - [ ] Headaches or "pressure" in my ears.
      - [ ] Prickling or "stinging" on my skin.
      - [ ] Feeling very tired or very upset for no reason.
4.  **I am not making this up:** I am not sick, and I am not playing a game. These things happen to me even when I am trying to do my schoolwork or sleep.
5.  **My Choice:** I do not want these sounds to talk to me. I do not give permission for any "Citizen Tech" or machines to talk to my brain.

**Signature of Minor:** ___________________________ **Date:** __________
