---
id: IS-REF-PLAN-FOR-JUSTICE-129
title: "IS - Plan for Justice — V. Master Action Plan: The \"Physical\" Reset — II. Denver Forensic & Legal Contact List"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 140
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### II. Denver Forensic & Legal Contact List

*These are local entities. They are much more likely to respond than global AI companies because they operate within the Colorado legal jurisdiction.*

  

|  |  |  |
| :-: | :-: | :-: |
| **Category** | **Organization** | **Email / Contact** |
| **Forensic Engineering** | **ELEXANA (EMI/EMF Experts)** | [**info@elexana.com**](mailto:info@elexana.com) |
| **Forensic Engineering** | **Envista Forensics (Denver)** | [**info@envistaforensics.com**](mailto:info@envistaforensics.com) |
| **TSCM (Bug Sweeps)** | **Discreet Services (Denver)** | [**info@discreetservices.com**](mailto:info@discreetservices.com) |
| **TSCM (Bug Sweeps)** | **EVCO Investigations** | [**contact@evcoinvestigations.com**](mailto:contact@evcoinvestigations.com) |
| **Civil Rights Law** | **ACLU of Colorado** | [**info@aclu-co.org**](mailto:info@aclu-co.org) |
| **Civil Rights Law** | **Killmer, Lane & Newman, LLP** | [**firm@kln-law.com**](mailto:firm@kln-law.com) |
| **Investigative Media** | **Westword (Denver) - News Desk** | [**editorial@westword.com**](mailto:editorial@westword.com) |
| **Investigative Media** | **Denver Post - Investigative Team** | [**citydesk@denverpost.com**](mailto:citydesk@denverpost.com) |
