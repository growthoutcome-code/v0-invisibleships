---
id: IS-REF-PLAN-FOR-JUSTICE-39
title: "IS - Plan for Justice — IV. Household Handbook: Child Testimony Best Practices"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 103
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## IV. Household Handbook: Child Testimony Best Practices

In the primary goal of capturing legally binding documentation, children must be handled with extreme care to avoid "leading the witness."

  - **The "Sensory Check" Technique:** Ask the child, "Does the sound feel like it's coming from your ears, or from the wall?"
  - **The "Drawing the Voice" Method:** If a child draws a specific shape or "machine" that matches descriptions from other children in Denver, it establishes **Commonality**, which is the "Gold Standard" for class action discovery.
  - **Parental Role:** The parent acts as the "Recorder of Record," signing a **Contemporaneous Log** of the child’s reactions to ensure the data is "Court-Ready."
