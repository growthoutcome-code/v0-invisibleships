---
id: IS-REF-PLAN-FOR-JUSTICE-06
title: "IS - Plan for Justice — I. Detailed Psychiatric Defense: Navigating the DSM-5 and Forensics"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 261
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## I. Detailed Psychiatric Defense: Navigating the DSM-5 and Forensics

To protect against a misdiagnosis of Schizophrenia, one must understand exactly how a clinician builds a "case" for illness. By documenting the *absence* of clinical markers, you create a "rebuttable presumption" of sanity.

### **1. The Clinical vs. External Distinction**

Psychiatrists look for **"Lack of Insight" (Anosognosia)**—the inability to recognize that one has a mental illness. In the case of "Citizen Tech," your defense is not "I am not sick," but rather **"I am reporting a specific technological event with external origins."**

**Comparison Table: Clinical Schizophrenia vs. Targeted Technology Exposure**

|  |  |  |
| :-: | :-: | :-: |
| **Clinical Marker** | **Schizophrenia Presentation** | **Citizen Tech (External Origin)** |
| **Logic/Reasoning** | Fragmented, "word salad," loose associations. | High cognitive function; clear, logical reporting of events. |
| **Response to Stimuli** | Emotional "flatness" or inappropriate affect. | Standard physiological stress response to external threats. |
| **Source of "Voices"** | Often vague, internal, or non-specific. | Specific, directional, and often transactional (demands/threats). |
| **Consistency** | Symptoms often wax/wane with chemistry. | Constant or triggered by specific locations/devices. |

### **2. Guarding Against "Involuntary Hold" (72-Hour Observation)**

Under laws like Colorado’s **CRS § 27-65-106**, a person can be held if they are a "danger to self or others."

  - **The Trap:** If you respond to a "Citizen Tech" threat by acting out in public, you provide the "evidence" needed for the hold.
  - **The Defense:** Maintain a "Non-Violent Baseline." Documentation must state: *"Regardless of the intensity of the Citizen Tech communication, I commit to non-violence and do not intend to harm myself or others. Any physical harm occurring to me is the result of external technological administration, not self-infliction."*
