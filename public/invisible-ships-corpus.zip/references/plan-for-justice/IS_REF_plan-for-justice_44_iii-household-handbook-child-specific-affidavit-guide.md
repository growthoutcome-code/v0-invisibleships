---
id: IS-REF-PLAN-FOR-JUSTICE-44
title: "IS - Plan for Justice — III. Household Handbook: Child-Specific Affidavit Guide"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 97
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## III. Household Handbook: Child-Specific Affidavit Guide

To meet your primary goal of capturing documentation from minors, the handbook includes this **Parental Instruction**:

**Capturing Child Testimony (Best Practices):**

  - **Do Not Lead:** Instead of asking "Did the voice say X?", ask "What did the sound tell you about your dinner?"
  - **Physical Markers:** Document if the child covers their ears or rubs their temples during a report. This suggests a **physical acoustic or RF pressure**, not a thought.
  - **Binding the Record:** Parents must sign the **Guardian Verification** (Module IX) to ensure the child's statement is admitted as a "Present Sense Impression" under **Rule 803(1)**.
