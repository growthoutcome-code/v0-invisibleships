---
id: IS-REF-PLAN-FOR-JUSTICE-173
title: IS - Plan for Justice — III. THE OPERATIONAL MATRIX (Google Sheets Section)
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 96
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### **Tab 1: The "Seige Engineer" Tracker**

|  |  |  |  |  |
| :-: | :-: | :-: | :-: | :-: |
| **Company Name** | **Phone** | **Email** | **Status** | **Scan Date** |
| ELEXANA | 720-442-0785 | \<info@elexana.com> | Call Tomorrow |   |
| Envista Forensics | 303-740-5700 | \<info@envistaforensics.com> | Call Tomorrow |   |

### **Tab 2: The Signal Discovery Log (The Evidence)**

|  |  |  |  |  |
| :-: | :-: | :-: | :-: | :-: |
| **Evidence ID** | **Date/Time** | **Subjective Experience** | **Frequency/dBm Reading** | **Faraday Result** |
| LOG-001 | \\[Date/Time\\] | \\[What was heard/felt\\] | \\[Meter Reading\\] | \\[Did it stop in shield?\\] |

### **Tab 3: The Liability Tracker**

*In Column D, use formula: =IF(C2="", "", TODAY()-C2)* | Recipient | Tracking # | Date Delivered | Days Since Notice | Status | | :--- | :--- | :--- | :--- | :--- | | Denver Mayor | [Tracking #] | [Date] | [Formula Result] | Non-Responsive |
