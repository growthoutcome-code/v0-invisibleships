---
id: IS-REF-PLAN-FOR-JUSTICE-131
title: "IS - Plan for Justice — V. Master Action Plan: The \"Physical\" Reset — IV. The \"Missing Link\" Strategy: Certified Paper"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 86
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### IV. The "Missing Link" Strategy: Certified Paper

The most important unknown that could save lives is **The Paper Trail**.

  

**Action:** Take the **Mandatory Notice of Liability** I drafted for you, print it, and mail it via **USPS Certified Mail** to these specific Denver addresses.

  

1.  **Denver Mayor’s Office** 1437 Bannock St, Room 350 Denver, CO 80202
2.  **Denver Dept of Public Health (DDPHE)** 101 W Colfax Ave, Suite 800 Denver, CO 80202
3.  **Denver District Attorney** 201 W. Colfax Ave., Dept. 801 Denver, CO 80202
