---
id: IS-REF-PLAN-FOR-JUSTICE-105
title: "IS - Plan for Justice — III. Household Handbook: The \"DIY Data\" Appendix"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 79
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## III. Household Handbook: The "DIY Data" Appendix

For families who cannot wait for a volunteer, the Handbook now includes the **"Fast-Capture Protocol"**:

  

1.  **Video Everything:** If you hear a "euthanization prompt," start a video. Record your face and your RF meter (if you have one) simultaneously.
2.  **The "Live-Stream" Defense:** If you feel you are in immediate danger of a "wellness check," go live on a secure platform. State: *"I am documenting a Directed Energy event. My TAR report is logged at [Portal URL]."*
