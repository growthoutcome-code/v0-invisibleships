---
id: IS-REF-PLAN-FOR-JUSTICE-56
title: IS - Plan for Justice — Yes.
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 48
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Yes.

The **Emergency Pocket Card** is designed to be your physical line of defense. It is intended to be handed to a police officer, doctor, or official immediately, before any verbal debate begins. This forces them to acknowledge your legal status and the liability they incur by ignoring it.

  

---
