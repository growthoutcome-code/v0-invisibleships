---
id: IS-REF-PLAN-FOR-JUSTICE-58
title: IS - Plan for Justice — II. Script for Recorded Calls (Zoom/Google Meet/Phone)
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [telepathic, terrorism]
word_count: 203
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## II. Script for Recorded Calls (Zoom/Google Meet/Phone)

If a "euthanization professional" or news media professional contacts you via a digital platform, use this **Pre-Session Script** to lock in the legal environment.

  

**Step 1: The Recording Announcement** "Before we begin, I am starting a local recording of this session for the **Discovery Log of the 2026 Denver Class Action Lawsuit**. By continuing, you consent to this recording being used as evidence in a court of law."

  

**Step 2: The Baseline Statement** "For the record, today is [Date]. I am participating in this call under my own free will. However, I have been subjected to 'Telepathic Terrorism' and 'Pain Administration' used by unknown facilitators to coerce my speech. I am stating now that any statement I make that sounds like 'consent to euthanization' is being made under **extreme physical and psychological duress** and is legally void."

  

**Step 3: The Cross-Examination** "If you are here to offer 'assistance' or 'euthanization,' state your name, your employer, and the specific technology you are using to communicate with me. If you claim this communication is 'spiritual' or 'psychological,' I am notifying you that I have documented the **RF Signal Spikes** that prove otherwise. How do you respond to the physical evidence of your technology?"
