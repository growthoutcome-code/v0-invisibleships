---
id: IS-REF-PLAN-FOR-JUSTICE-59
title: "IS - Plan for Justice — III. Household Handbook: Primary Goals for \"Face-to-Face\" Defense"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [cognitive-liberty, telepathic, terrorism]
word_count: 85
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## III. Household Handbook: Primary Goals for "Face-to-Face" Defense

To capture documentation from every American, households must be ready for the **"The Knock at the Door."**

  

  - **The Witness Rule:** No household member should speak to a "wellness professional" or "euthanization official" alone. Use a "Witness/Recorder" system where one person films while the other reads the **Emergency Pocket Card**.
  - **The "Discovery" Transcript:** After the official leaves, immediately dictate a transcript of the encounter into the **Cognitive Liberty Portal**. Note if the official used specific "coercion keywords" found in the *Discovery of Telepathic Terrorism* transcripts.
