---
id: IS-REF-PLAN-FOR-JUSTICE-77
title: IS - Plan for Justice — Yes
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 78
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
disclaimer: meta/IS_META_terms.md
---

## Yes

This **Sovereignty Task Force Training Manual** is the technical and tactical "Field Guide" for your volunteers. It ensures that every member of your team—regardless of their technical background—can operate an RF scanner and conduct a legal intake that stands up to cross-examination in a court of law.

# **THE SOVEREIGNTY TASK FORCE: FIELD TRAINING MANUAL (v.1.0)**

**Mission:** *To bridge the gap between "subjective experience" and "objective evidence" through forensic signal analysis and legal documentation.*

---

## Critical Disclaimer on Transcripts and Accusations

Transcripts and statements recorded in this archive are external communications and do NOT represent the author's beliefs, views, or intent. Nothing here accuses, blames, or alleges malfeasance by any named person, company, or government body, and all of this information requires independent verification.

The full Critical Disclaimer, copyright and terms are in meta/IS_META_terms.md, and at https://www.invisibleships.com/disclaimer.
