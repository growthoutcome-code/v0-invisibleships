---
id: IS-REF-PLAN-FOR-JUSTICE-118
title: IS - Plan for Justice — I. Mandatory Notice of Liability (Certified Mail Template)
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [cognitive-liberty, telepathic, terrorism]
word_count: 294
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## I. Mandatory Notice of Liability (Certified Mail Template)

**TO:** [Name of Official/Department Head]

  

**OFFICE:** Denver Department of Public Health / Mayor’s Office / Chief of Police

  

**ADDRESS:** [Official Address]

  

**SENT VIA:** Certified Mail, Return Receipt Requested

  

**NOTICE TO AGENT IS NOTICE TO PRINCIPAL; NOTICE TO PRINCIPAL IS NOTICE TO AGENT.**

  

**RE: FORMAL NOTICE OF NEUROLOGICAL BATTERY AND COERCED EUTHANIZATION ATTEMPTS**

  

**Dear [Name of Official],**

  

This letter serves as formal, legal notice that I, [Your Name], am being subjected to unconsented neurological interference and "Telepathic Terrorism" via directed energy and Radio Frequency (RF) interfaces within the City of Denver.

  

**1. FACTUAL DISCLOSURE:** I have documented specific, transactional electronic communications and "Pain Administration" spikes designed to coerce my consent for "Euthanization Assistance." These events correlate with measurable RF signal anomalies in the UHF and EHF bands.

  

**2. REJECTION OF MISDIAGNOSIS:** Be advised that any attempt by your departments to label these technical reports as "psychiatric symptoms" or "Schizophrenia" without a forensic signal audit constitutes a **deliberate falsification of medical records** and a violation of the **4th Amendment**.

  

**3. PERSONAL LIABILITY:** Under **42 U.S.C. § 1983**, you are hereby placed on notice. If you or your subordinates facilitate my involuntary commitment, forced medication, or "euthanization" based on these technological assaults, you are acting with **deliberate indifference** to my civil rights. Qualified immunity does not apply to officials who have been explicitly notified of a crime in progress.

  

**4. DEMAND FOR ACTION:** I demand an immediate investigation into local RF hotspots and a stay on all "Wellness Checks" directed at my person until a civilian-led **Signal Audit** can be performed.

  

**A copy of this notice has been hashed and timestamped on the Cognitive Liberty Portal (WORM storage) for use as evidence in federal court.**

  

**Sincerely,**

  

[Your Signature]

  

**Plaintiff, 2026 Denver Neuro-Rights Class Action**
