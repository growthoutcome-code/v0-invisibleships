---
id: IS-REF-PLAN-FOR-JUSTICE-81
title: "IS - Plan for Justice — 4. Interaction with \"Hostile Professionals\""
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 83
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## 4. Interaction with "Hostile Professionals"

If a "euthanization professional" or law enforcement arrives during your scan:

1.  **Do Not Obstruct:** Stand back, keep the camera rolling, and remain silent.
2.  **Invoke the "Notice":** If they attempt to detain the witness, hand them the **Emergency Pocket Card**.
3.  **The Competency Statement:** If asked, state: *"I am a forensic volunteer. I am currently recording external signal interference that correlates with this individual's reports. This individual is of sound mind and is a witness in a pending class-action lawsuit."*
