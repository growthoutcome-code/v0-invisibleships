---
id: IS-REF-PLAN-FOR-JUSTICE-02
title: IS - Plan for Justice — Introduction In-progress — Overview
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [telepathic, torment]
word_count: 199
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### Overview

My name is Sean C. Harris. I'm a 49 yr old agnostic father and research professional in technology who’s been enlisted unexpectedly into a harrowing and relentless telepathic journey of self development.

I’ve written this document in hopes of supporting others in determining what myself and the community are being exposed to. For example, is the telepathic tormenting I am experiencing unethical technology experimentation and or an unacknowledged terrorist attack? Am I speaking directly in 1:1 conversations with law enforcement, military and others?

Please keep in mind, regardless of being 1000+ pages this document only represents a fraction of the overall conversation. Telepathic communication has been so saturated that I can not actually capture the entire conversation receiving information from 3-10+ communicators and at times multiple groups 24hrs a day and all while I am being tormented and offered euthanization.

If you are understandably skeptical about these sensational claims and or initially concerned for my emotional well being please consider reviewing some of my personal background available in the resources section of this document. [**See Sean Harris Background*](https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit?tab=t.0#heading=h.btv4e4sjdb3s)
