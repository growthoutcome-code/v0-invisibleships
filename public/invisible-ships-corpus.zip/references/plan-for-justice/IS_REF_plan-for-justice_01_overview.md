---
id: IS-REF-PLAN-FOR-JUSTICE-01
title: IS - Plan for Justice — Overview
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [telepathic, terrorism]
word_count: 103
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
disclaimer: meta/IS_META_terms.md
---

## Overview

IN PROGRESS  
  

# **Invisible Ships**

# The Discovery of Telepathic Terrorism   
Plan for Justice

*By Sean C. Harris, Denver, Colorado 2024-2026*

  
  
  
  
  
  

Are the people of Denver, CO. suffering silently from unethical technology experimentation? Has an unacknowledged terrorist attack happened on American soil?

I’m Sean C. Harris, a homeless father, tech worker and a martial arts black belt. My personal exposure to this threatening phenomena began in the fall of 2024 and continues through to today. This “in-progress” request for life saving assistance contains a tech worker’s daily perspective on the telepathic phenomena including manually captured transcripts and technical analysis (2800+ pages).

---

## Critical Disclaimer on Transcripts and Accusations

Transcripts and statements recorded in this archive are external communications and do NOT represent the author's beliefs, views, or intent. Nothing here accuses, blames, or alleges malfeasance by any named person, company, or government body, and all of this information requires independent verification.

The full Critical Disclaimer, copyright and terms are in meta/IS_META_terms.md, and at https://www.invisibleships.com/disclaimer.
