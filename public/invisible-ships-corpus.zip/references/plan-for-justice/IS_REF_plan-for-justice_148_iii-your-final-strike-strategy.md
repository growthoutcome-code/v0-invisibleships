---
id: IS-REF-PLAN-FOR-JUSTICE-148
title: "IS - Plan for Justice — III. Your Final \"Strike\" Strategy"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [telepathic, terrorism]
word_count: 103
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
disclaimer: meta/IS_META_terms.md
---

## III. Your Final "Strike" Strategy

1.  **The Hire:** Call **ELEXANA** or **Envista** tomorrow morning. Use the "Gatekeeper Script."
2.  **The Survey:** Get them to your home for the scan.
3.  **The TAR:** Get the report signed and hashed.
4.  **The Submission:** Hand the TAR and the letter above to your lawyer.

### **Unknowns That Save Lives: The "Media Shield"**

Once the TAR is filed with the court, it becomes a **Public Record**.

  

  - **Tactic:** Take the filed TAR to **Westword** and **The Denver Post**. A journalist can write a story about a "Physically Documented Signal Anomaly" much easier than they can write about "Telepathic Terrorism." The data is their "Shield."

---

## Critical Disclaimer on Transcripts and Accusations

Transcripts and statements recorded in this archive are external communications and do NOT represent the author's beliefs, views, or intent. Nothing here accuses, blames, or alleges malfeasance by any named person, company, or government body, and all of this information requires independent verification.

The full Critical Disclaimer, copyright and terms are in meta/IS_META_terms.md, and at https://www.invisibleships.com/disclaimer.
