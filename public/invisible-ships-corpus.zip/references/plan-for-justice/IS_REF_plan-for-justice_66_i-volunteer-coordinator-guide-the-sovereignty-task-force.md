---
id: IS-REF-PLAN-FOR-JUSTICE-66
title: "IS - Plan for Justice — I. Volunteer Coordinator Guide: The \"Sovereignty Task Force\""
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [software]
word_count: 207
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### **1. Volunteer Roles & Responsibilities**

Divide your team into specific "strike cells" to prevent burnout and ensure specialized data capture:

  - **Affidavit Navigators:** Help victims navigate the website, handle the mnemonic seed phrase, and connect with the remote notary.
  - **Signal Techs:** Trained to use basic SDR (Software Defined Radio) or RF meters to assist households with "Signal Correlation" (Module XIII).
  - **Family Liaisons:** Specifically trained in the "Household Handbook" to help parents capture "Parental Proxy Affidavits" for children.
  - **Crisis Verifiers:** On-call to join Zoom/Google Meet calls when a victim is being confronted by a "euthanization professional" (Module XXV).

### **2. The "De-Escalation" Training**

Volunteers must remain calm. If a volunteer panics, the "Citizen Tech" facilitators win by creating a chaotic environment that looks like "mass hysteria" to the media.

  - **The Protocol:** If a victim is being threatened, the volunteer must say: *"Stay on script. Hand them the Pocket Card. We are recording the signal spikes now. You are a witness, not a patient."*

### **3. Data Integrity & Privacy**

Volunteers must never see or store a user's unencrypted data.

  - **Golden Rule:** *"We provide the tools (The Portal), but the victim holds the key (The Seed Phrase). If you see a user's 12-word seed, you have breached protocol."*
