---
id: IS-REF-PLAN-FOR-JUSTICE-177
title: "IS - Plan for Justice — IV. THE EMERGENCY INJUNCTION AFFIDAVIT — II. Google Sheets Setup: Tab 2 (The Signal Discovery Log)"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 117
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### II. Google Sheets Setup: Tab 2 (The Signal Discovery Log)

This is the "Heart" of your evidence. It correlates your physical experience with radio frequency data.

**Set up your columns as follows:**

  - **Column A:** Time/Date
  - **Column B:** Subjective Testimony (What you felt/heard)
  - **Column C:** Frequency Detected (e.g., 2.4 GHz)
  - **Column D:** Amplitude Spike (e.g., -40 dBm)
  - **Column E:** **Biological Correlation (YES/NO)**

The "YES/NO" Logic:

If the spike on your RF meter happened at the exact same second the "Tech-Lie" communication occurred, you mark it YES.

  - *Lawyer’s Tip:* A 100% correlation rate over 20 entries is statistically impossible to be "mental illness." It is proof of a physical system.
