---
id: IS-REF-PLAN-FOR-JUSTICE-75
title: "IS - Plan for Justice — IV. Household Handbook: The \"Guardian\" Visit Protocol"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [cognitive-liberty]
word_count: 97
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## IV. Household Handbook: The "Guardian" Visit Protocol

When a volunteer (Guardian) visits a household to assist in evidence capture:

1.  **The Entry Statement:** "I am here as a volunteer for the Cognitive Liberty Portal. I am not a doctor. I am here to help you secure your **Sovereous Affidavit** and scan your home for signal interference."
2.  **The Signal Sweep:** Use the **Module XIII Table** to scan the 300MHz to 60GHz range while the victim reports "active communication."
3.  **The Affidavit Finish:** Ensure the parent/adult signs the **Medical Rebuttal** and the **Emergency Pocket Card** is placed in their wallet before the Guardian leaves.
