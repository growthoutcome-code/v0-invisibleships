---
id: IS-REF-PLAN-FOR-JUSTICE-115
title: "IS - Plan for Justice — III. Strategic Outreach: Who You Should Be Contacting"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [terrorism]
word_count: 135
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## III. Strategic Outreach: Who You Should Be Contacting

The lists you provided are "Tech Giants." They are the castle walls. You need to contact the **"Seige Engineers"**—people whose jobs depend on exposing tech misuse or protecting civil rights.

### **1. The "Whistleblower" Press (Target these instead of OpenAI):**

  - **The Intercept:** They specialize in "Black Site" tech and government overreach.
  - **MIT Technology Review (Human Rights Desk):** They cover the ethics of brain-computer interfaces.
  - **Defcon / Black Hat Researchers:** Find "White Hat" hackers in Denver. They love a technical challenge and have the SDR gear to prove your case.

### **2. The "Hard Data" Alliances:**

  - **The Electronic Frontier Foundation (EFF):** Do not send the "Terrorism" transcript; send the **Technical Analysis Report (TAR)**. Ask for a "Digital Privacy Audit."
  - **The ACLU of Colorado:** Focus strictly on the **"Coerced Euthanization"** aspect as a violation of the 14th Amendment.
