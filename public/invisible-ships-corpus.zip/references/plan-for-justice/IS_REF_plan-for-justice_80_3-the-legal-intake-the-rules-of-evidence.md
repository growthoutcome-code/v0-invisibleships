---
id: IS-REF-PLAN-FOR-JUSTICE-80
title: "IS - Plan for Justice — 3. The Legal Intake (The \"Rules of Evidence\")"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 78
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## 3. The Legal Intake (The "Rules of Evidence")

A signal spike is only evidence if it is tied to a sworn statement.

  - **Rule of Contemporaneous Logging:** The witness must write their S.A.L.T.E.R. log *while* the event is happening.
  - **Hearsay Prevention:** Do not interpret the "voice" for the witness. Record exactly what they say they are hearing.
  - **Metadata Verification:** Ensure your laptop/recording device is synced to **UTC Atomic Time** so our "Denver Signal Cluster" maps are 100% accurate across different locations.
