---
id: IS-REF-PLAN-FOR-JUSTICE-168
title: IS - Plan for Justice — II. THE TECHNICAL OFFENSIVE (Google Doc Section)
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 65
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### **A. Scope of Work (SOW) for Forensic Engineers**

*Hand this to your engineer from ELEXANA or Envista Forensics upon arrival.*

  

  - **Audit Range:** 100 kHz to 60 GHz (Wide-Spectrum Sweep).
  - **Deliverable 1:** Waterfall Display analysis showing frequency spikes during witness-reported stimuli.
  - **Deliverable 2:** Pulse-Modulated Signal analysis (Microwave Auditory Effect verification).
  - **Deliverable 3:** Shielding Attenuation Test (verification of external signal origin via Faraday cage).
