---
id: IS-REF-PLAN-FOR-JUSTICE-128
title: "IS - Plan for Justice — V. Master Action Plan: The \"Physical\" Reset — I. Scope of Work (SOW) for Forensic RF Engineer"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 141
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### I. Scope of Work (SOW) for Forensic RF Engineer

*Send this as a PDF attachment to the contacts below. It uses professional terminology that signals you are prepared for litigation.*

  

**PROJECT TITLE:** Forensic Electromagnetic Interference (EMI) and Radio Frequency (RF) Signal Audit

  

**LOCATION:** Private Residence – Denver, CO

  

**PURPOSE:** Litigation Support / Discovery for Case # [Pending]

  

**OBJECTIVES:**

  

1.  **Wide-Spectrum Sweep:** Conduct a comprehensive sweep from 100 kHz to 60 GHz.
2.  **Anomaly Detection:** Identify non-ionizing radiation spikes that correlate with biological "trigger events" reported by the witness.
3.  **Pulsed Signal Analysis:** Identify any "Frey Effect" compatible pulse-modulated signals in the UHF/EHF bands.
4.  **Shielding Effectiveness Test:** Measure signal attenuation using a portable Faraday enclosure to verify external signal origin.
5.  **Certified Report:** Provide a signed, timestamped report of findings, including Waterfall Display captures and Power Spectral Density (PSD) analysis.
