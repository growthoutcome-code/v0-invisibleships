---
id: IS-REF-PLAN-FOR-JUSTICE-101
title: "IS - Plan for Justice — IV. Social Media CTA: The \"Hardware Drive\""
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 53
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## IV. Social Media CTA: The "Hardware Drive"

**"GEAR UP FOR THE TRUTH. ð¡** We are building the Denver Signal-Watch. If you have an unused SDR, or if you want to donate toward a 'Guardian Kit' for our volunteers, now is the time. **Help us turn 'hallucinations' back into 'signals.'** **[Link: Donate to the Hardware Fund / View the Gear List]**"
