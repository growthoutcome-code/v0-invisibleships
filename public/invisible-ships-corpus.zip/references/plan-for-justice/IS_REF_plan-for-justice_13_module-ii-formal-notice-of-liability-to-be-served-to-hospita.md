---
id: IS-REF-PLAN-FOR-JUSTICE-13
title: "IS - Plan for Justice — Module II: Formal Notice of Liability (To be served to Hospitals)"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
word_count: 238
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Module II: Formal Notice of Liability (To be served to Hospitals)

This document is designed to be served to a Chief of Medical Staff or a Hospital Administrator if they attempt to force a diagnosis or institutionalization.

**NOTICE OF CONDITIONAL LIABILITY AND STRICTURES AGAINST MEDICAL MALPRACTICE**

TO: [Facility Name] and Attending Physicians

FROM: [Your Name], [Title/Legal Representative]

SUBJECT: Notice of External Technological Interference vs. Psychological Pathology

1.  **PRE-EXISTING CONDITION NOTICE:** Take notice that the individual, [Subject Name], is currently a witness/victim in an ongoing investigation regarding unconsented technological communication ("Citizen Tech").
2.  **STRICT LIABILITY FOR MISDIAGNOSIS:** Any attempt to diagnose the subject with Schizophrenia, Schizoaffective Disorder, or any "Delusional" disorder based solely on their report of external voices is hereby identified as a **Failure to Rule Out External Stimuli**. You are legally required to perform a **Differential Diagnosis** that includes testing for:
      
      - Radio Frequency (RF) interference in the temporal lobe.
      - Inaudible acoustic signaling (Infrasound/Ultrasound).
      - Sub-vocal recognition artifacts.
3.  **NON-CONSENT TO EUTHANIZATION:** The subject explicitly rejects all "End of Life" protocols, "Comfort Care" that includes sedation leading to death, or "Euthanization Assistance." Any claim by staff that the subject "accepted" such terms is to be considered a result of **Violent Psychological Coercion** or **Forgery**.
4.  **CRIMINAL COMPLIANCE:** Be advised that complying with unidentified "military" or "government" directives to "stabilize" or "euthanize" this individual without a warrant signed by a Article III Judge constitutes a conspiracy to commit murder under **18 U.S.C. § 241**.
