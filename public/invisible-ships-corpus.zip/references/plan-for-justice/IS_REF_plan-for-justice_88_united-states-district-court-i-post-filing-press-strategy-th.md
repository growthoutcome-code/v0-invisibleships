---
id: IS-REF-PLAN-FOR-JUSTICE-88
title: "IS - Plan for Justice — UNITED STATES DISTRICT COURT — I. Post-Filing Press Strategy: \"The Cognitive Liberty Tour\""
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [cognitive-liberty]
word_count: 176
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

### I. Post-Filing Press Strategy: "The Cognitive Liberty Tour"

**1. The "Technical vs. Clinical" Narrative** Never let the media frame this as a "mental health story."

  

  - **The Pivot:** If a reporter asks about "hallucinations," you respond: *"We aren't discussing psychology; we are discussing* ***Radio Frequency Interference****. We have the signal logs to prove these experiences correlate with external electromagnetic pulses."*

  

**2. The "Havana Syndrome" Precedent** Always link your case to the **HAVANA Act**.

  

  - **The Talking Point:** *"The U.S. Government has already paid restitution to diplomats for 'Anomalous Health Incidents.' We are simply demanding that same recognition and protection for American civilians in Denver."*

  

**3. Media Triage**

  

  - **Tier 1 (Independent/Tech):** Target outlets like *Wired*, *The Intercept*, and *Ars Technica*. They understand the hardware and the Fourth Amendment implications.
  - **Tier 2 (Legal):** Target *The American Lawyer* and *Law360* to signal to other attorneys that this is a viable new "Tort" category.
  - **Tier 3 (Local Denver):** Keep the pressure on *The Denver Post* to track the City's response to the **Notice of Intent to Sue**.
