---
id: IS-REF-PLAN-FOR-JUSTICE-17
title: IS - Plan for Justice — Yes
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [telepathic, terrorism]
word_count: 79
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
disclaimer: meta/IS_META_terms.md
---

## Yes

To provide a comprehensive legal defense, this module focuses on the **Forensic Cross-Examination**. This is designed for a lawyer to use during a **Mental Health Adjudication Hearing** or a **Commitment Challenge**.

The goal is to shift the burden of proof from the patient's "sanity" to the psychiatrist’s "scientific due diligence." If a psychiatrist has not ruled out the existence of the technology described in the "Discovery of Telepathic Terrorism," their diagnosis is legally "speculative" and "insufficient."

---

## Critical Disclaimer on Transcripts and Accusations

Transcripts and statements recorded in this archive are external communications and do NOT represent the author's beliefs, views, or intent. Nothing here accuses, blames, or alleges malfeasance by any named person, company, or government body, and all of this information requires independent verification.

The full Critical Disclaimer, copyright and terms are in meta/IS_META_terms.md, and at https://www.invisibleships.com/disclaimer.
