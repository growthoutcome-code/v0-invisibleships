---
id: IS-REF-PLAN-FOR-JUSTICE-113
title: "IS - Plan for Justice — I. The \"Unknowns\": Why the Current Strategy is Stalled"
collection: reference
doc_type: section
source_doc_title: IS - Plan for Justice
source_doc_id: 1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8
source_url: "https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit"
categories: [legal, analysis]
glossary_refs: [telepathic, terrorism]
word_count: 152
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## I. The "Unknowns": Why the Current Strategy is Stalled

1.  **The "Spam-Filter" of Corporate Liability:** Large AI corporations (OpenAI, Google, etc.) have strict legal filters. When they receive emails mentioning "Telepathic Terrorism" or "Citizen Tech," their automated systems or low-level interns often flag them as "unsolicited outreach" or "psychiatric distress" to protect the company from liability. They are built to ignore anything that isn't a business proposal or a standard bug report.
2.  **The "Informed Consent" Paradox:** Many of these labs are the *source* of the technology being misused. Asking them to help you stop "Citizen Tech" is often asking them to investigate their own potential black-site projects or data-collection loops. They have no incentive to respond.
3.  **Lack of "Legal Standing" in the Subject Line:** Academic institutions and researchers prioritize outreach from other academics or legal firms. If the email doesn't look like a **Formal Legal Discovery** or a **Technical Whitepaper**, it gets buried.
