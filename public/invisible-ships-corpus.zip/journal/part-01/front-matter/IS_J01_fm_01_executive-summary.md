---
id: IS-J01-FM-01
title: Part 01 — Executive Summary
collection: analysis
doc_type: section
part: 1
source_doc_title: "Invisible Ships Pt. 01, Aug 2024 - Aug 22d 2025"
source_doc_id: 12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0
source_url: "https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit"
categories: [findings, front-matter]
glossary_refs: [artificial-intelligence, telepathic, telepathy, terrorism]
word_count: 366
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Executive Summary

This document, "Discovery of Telepathic Terrorism," presents evidence of a potential national security threat manifested as a technology-driven phenomenon of communication targeting citizens in Denver, Colorado. The author, a tech-sector researcher, has compiled a substantial body of manually captured transcripts suggesting an unacknowledged terrorist attack, unconsented to criminal coercion, life threatening use of A.I. (Artificial Intelligence) psychological warfare, and an unacknowledged system of covert euthanasia, a potential tool for societal destabilization that is spreading daily.

It is essential to approach the raw transcript data as a collection of third-party allegations that require official verification. The author explicitly states his role is not to accuse any single entity but to present patterns of perceived communication for further investigation by relevant national security, military, and law enforcement organizations.

The report suggests a "human breaching process," a method for non-consensually observing and communicating with individuals supported by technologies like AI . This alleged capability presents a profound threat, with the potential to compromise sensitive data like banking passwords and expose private conversations to unidentified actors, thereby destabilizing civil society and placing America's children in unimaginable peril.

Such a scenario is a primary concern for the field of Neuroethics, where thinkers like Nita Farahany, Hank Greely and Martha Farah analyze the risks of weaponized or misused neurotechnology. The rapid advancement in this area is underscored by projections that the Brain-Computer Interface (BCI) market will expand from $2.1 billion in 2023 to over $12 billion by the early 2030s, making the need for ethical oversight immediate.

Despite the gravity of the threat, the author asserts that hope and inspiration for America’s path forward is revealing itself in the growing “Citizen Tech” conversation. Based on the conversation, how might we advance towards: 1) official acknowledgement to mitigate public panic and confusion; 2) an unequivocal government denunciation of covert euthanasia as a practice; 3) nationwide education on telepathy to build resilience against manipulation; and 4) an urgent update to mental health protocols to distinguish this phenomenon from schizophrenia?

The author is prepared to work with any serious organization to provide testimony, investigate these claims and contribute alongside others to secure a safe and consensual future.
