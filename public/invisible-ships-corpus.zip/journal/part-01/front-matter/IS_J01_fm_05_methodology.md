---
id: IS-J01-FM-05
title: Part 01 — Methodology
collection: analysis
doc_type: section
part: 1
source_doc_title: "Invisible Ships Pt. 01, Aug 2024 - Aug 22d 2025"
source_doc_id: 12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0
source_url: "https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit"
categories: [methodology, front-matter]
glossary_refs: [artificial-intelligence, telepathic]
word_count: 288
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Methodology

### **Process** ***In-Progress**

Regardless of the telepathic phenomena, my daily process includes a few foundational practices including setting intention, affirming gratitude, monitoring goals, personal inventory updates and enjoying exercise. Since I began experiencing this unacknowledged phenomena I have added a few practices to help document the journey including capturing transcripts of the telepathic conversation manually using a variety of methods, monitoring the news, conducting online technology research using A.I. (Artificial Intelligence) tools like Chat G.B.T or Gemini. I also spend time personally recalling the phenomena and conversations that I did not capture transcripts for, in an effort to commit information to memory. 

  

### **Transcriptions**

#### **Audio Recording**

Audio transcripts are an attempt to capture 100% of every telepathic suggestion myself and the people around me are being exposed to, where applicable. These are recordings of me repeating, out loud, every telepathic suggestion I receive. There is no departure from only repeating what is suggested telepathically by others with the exception of surprise in person interactions with others, administrative comments I speak to myself to provide context and or occasionally address questions. As of July 16th 2025, I am using the native Android voice recorder and Google AI Studio for the audio file transcriptions. Regarding automatic transcriptions, important words like “euthanization” may come through misspelled in the transcript like “zation”. Also, the telepathic conversation and the relationship between myself and the “speakerphone” observers may be taken out of context implying a false personal association to terrorist activity or a false in-person relationship with a technology organization.

#### **Manual recording**

Previous to July 10th 2025 all transcripts were captured manually with the assistance of a mobile phone or laptop while listening to the “speakerphone” and or other telepathic conversations.
