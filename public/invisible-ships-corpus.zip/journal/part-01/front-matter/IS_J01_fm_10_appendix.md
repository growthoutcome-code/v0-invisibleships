---
id: IS-J01-FM-10
title: Part 01 — Appendix
collection: analysis
doc_type: section
part: 1
source_doc_title: "Invisible Ships Pt. 01, Aug 2024 - Aug 22d 2025"
source_doc_id: 12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0
source_url: "https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit"
categories: [reference, front-matter]
glossary_refs: [telepathy]
word_count: 485
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Appendix

### **Sean Harris Resources**

**Here’s a list of a few personal accomplishments and links to some resources focused on my infection:** 

Professional:

  - UX / Product Designer (Lead or Sr 12+ yrs)  
    Linkedin: <http://www.linkedin.com/in/growthoutcome>
  - Professional Portfolio <https://seanharr.is>
  - “Design Leaders” meetup founder Denver, CO (advancing the practice of design leadership through sponsored industry events and workshops 1+yrs)

Self-development:

  - Rick Johnson Private Investigator Academy of the Rockies Graduate (The training was extremely valuable. I’ve never worked as a PI.)
  - Past PPIAC Member (Professional Private Investigators Association of Colorado) **Confirm organization*
  - Korean Martial arts competitor and Black Belt (Choi Brothers Academy)
  - Muay Thai martial arts training (Train Fight Win & Easton Academy Denver CO. and Portland, OR 5-6+ yrs) <http://tfwmma.com> 
  - Spartan Sprint Open 5k Breckenridge, CO (61st/1080 participants) <https://race.spartan.com/en/race/profile/3002554>
  - Healthy active lifestyle (road biking, cross-fit, salsa dancing classes, photography, writing, volunteering and gardening) *LaRumba classes in Denver, CO. are a great time. <https://larumbadenver.com/dance-lessons/>
  - Negative Drug Test Results <https://photos.app.goo.gl/sQZBMNvN5jre9KU98>  

Volunteering:

  - Althea Center for Engaged Spirituality volunteering <https://www.altheacenter.org/>
  - Highlands Church of Denver volunteering on the prayer team for 2 years <https://hchurchdenver.com/> ***

Post Covid-19 Vaccination Infection Related:

**Warning: These Google Albums contain extremely graphic content that is not suitable for children or the faint of heart. None of the content in the albums is HIPPA protected. Feel free to share and download local copies of the photos and videos at the links below.*

  - <http://bonfire.com/store/skindisorderzzz> **Bonfire.com Information site & tshirt sale donations*
  - <https://www.youtube.com/@skindisorderzzz> **Youtube video journal*
  - <https://photos.app.goo.gl/qnnmgu9JFpG3i6sS8> **Complete infection video and photo album*
  - *\<https://photos.app.goo.gl/qnnmgu9JFpG3i6sS8> *\\*Un-diagnosed Infection - Video Samples**
  - *\<https://docs.google.com/document/d/16pJVSzYmFacskl4eeX2f8dQDvgJw2FWdRp7NgOP5tcU/edit?usp=sharing> *\\*Prospective Primary Care Doctor Letter & Symptoms Background**

  

### **Telepathy & Remote Viewing**

Telepathy Tapes Ky Dickens <https://en.wikipedia.org/wiki/The_Telepathy_Tapes>

Telepathy Tapes Spotify Podcast <https://open.spotify.com/show/1zigaPaUWO4G9SiFV0Kf1c?si=NOTsAPU2SqWhnBEe_p-RdA>

Telepathy Tests <https://thetelepathytapes.com/telepathy-tests-library>

Remote Viewing Training, Dr. Steven Greer <https://youtu.be/x8RxA0EWcEo?si=_9xuR60yqrMV-Woy>

Telepathy vs Schizophrenia <https://youtu.be/qdXrv5dfn-M?si=rMBVClXtnd-pTP0x> **information was helpful and important to anyone seeking medical assistance* 

### **Neuralink**

Neuralink Seeks ‘Telepathy’ And ‘Telekinesis’—Is Mind Control Next? Forbes <https://www.forbes.com/sites/luisromero/2025/03/08/neuralink-seeks-telepathy-and-telekinesis-is-mind-control-next/>

Neuralinks first human patient shares his experience KVUE ABC <https://youtu.be/IbM4-rcujxY?si=SKCvV1bbHdUNVs1B>

How mind reading technology conquers your brain TEDX 4yrs Ago <https://youtu.be/csjFifU2Pxc?si=jSAoQBYT97DscIr9>

“The science behind Elon Musks Neuralink” WIRED Magazine 3yrs ago <https://youtu.be/Gv_XB6Hf6gM?si=vM3yBQV-G9ZPa3aw>

“Neuralink, mind control and the law” (AUSCL), Interview 4yrs Ago <https://youtu.be/M7TlAe2qfeA?si=D8NtTGCgOgnLMtx2>

### **Faraday Cages**
