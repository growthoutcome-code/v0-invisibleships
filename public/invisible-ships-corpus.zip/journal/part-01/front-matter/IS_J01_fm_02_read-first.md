---
id: IS-J01-FM-02
title: Part 01 — Read first
collection: analysis
doc_type: section
part: 1
source_doc_title: "Invisible Ships Pt. 01, Aug 2024 - Aug 22d 2025"
source_doc_id: 12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0
source_url: "https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit"
categories: [front-matter, front-matter]
glossary_refs: [telepathic, telepathy, torment]
word_count: 640
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Read first

Please review the information below before continuing reading or attempting to communicate with me telepathically. I’ve provided these considerations to help promote the safety of the individual reading and or contributing to any telepathic experiences that may arise after accessing this document.

This information is inspired by the daily telepathic abuse of human rights that myself and others may be experiencing including unsolicited conversation, unconsented breaching of the human body,  inappropriate requests, inappropriate attempts to appeal to one’s situation, sharing petty grievances with the people around you, claims of violence, threats, acts, character defamation, unethical and uncompensated technology experimentation.

**Before reading and or communicating please consider the following:**

1.  **Telepathic conversation:** I am a member of an malicious ongoing telepathic conversation I have never given consent to that suggests the inclusion of multiple individuals, communities, governments, countries and organizations supporting a variety of industries and institutions including city planning, local government, law enforcement, biotech, technology and military.
2.  **Tormenting & euthanization:** I am a victim of telepathic “tormenting”, the psychological smothering and  destruction of one’s reputation and support systems in an effort to force me into accepting almost hourly requests to “accept my euthanization”. The suggested reason for this is due to communicating in the unacknowledged telepathic phenomena I’m experiencing.
3.  **Dangerous consequences:** According to a historical pattern of suggestion, communicating telepathically with anyone, myself especially, possibly accessing and or reading this document may invite unexpected telepathic phenomena including any threat cited above from telepathic tormenting and the threat of being offered euthanization. 
4.  **Absence of trust:** Unfortunately, due to the historical threat of euthanization, the absence of consent, socialization of false information and the lack of accountability, no telepathic suggestion or individual making the telepathic suggestion should not be trusted. That said, please avoid suggesting any form of telepathic extraction to myself or others. Doing so invites the threat of euthanization to show up in person.    
5.  **Communication:** If you choose to communicate regardless of the information cited above, please consider that these life threatening telepathic conversations appear to be completely transparent to all contributors. Please avoid sharing your or someone else’s P.I.I (Personally Identifiable Information). Please do not come to my residence or share this document with my friends or family. All of that said, please consider not communicating telepathically and consider using traditional and accountable forms of communication i.e. phone or email, for improved discretion and safety. 
6.  **About the author:** This challenging experience is not wishful thinking. I am a physically strong, emotionally stable, heterosexual, 49yr old, agnostic, martial arts black belt, 10+ year technology worker, adult and father, who enjoys exercise. I do not possess any fixed belief structures, I am a proud supporter of consent culture and the LGBTQ community.
7.  **Providing support:** I am not currently employed. I am in need of life saving financial sponsorship, permanent shelter safe and adequate for withstanding ongoing tormenting, completing this manuscript and restoring my career path. Considering the torment cited above affecting the people around me, ideally I have shelter away from others and the people I do spend time with are educated in telepathy and or authentically supportive of my situation.
8.  **Telepathic value:** Regardless of this life threatening situation, I believe that consensual telepathy can provide extraordinary value to any individual, organization,  industry, institution or government. This belief is inspired by my personal research of Neuroethics, innovations in E.E.G.s (), B.C.I.s (Brain to Computer Interfaces) advances in technology supported telepathic communication i.e. Elon Musk’s Neuralink.
9.  **Thank you for your service:** Based on historical telepathic suggestions, I am hopeful that the United States of America and other supporting organizations are working diligently to bring justice to the telepathic suggestion of unethical experimentation and abuse myself and others may be experiencing.

###
