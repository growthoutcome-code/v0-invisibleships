---
id: IS-J01-FM-09
title: Part 01 — Evidence
collection: analysis
doc_type: section
part: 1
source_doc_title: "Invisible Ships Pt. 01, Aug 2024 - Aug 22d 2025"
source_doc_id: 12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0
source_url: "https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit"
categories: [evidence, front-matter]
glossary_refs: [artificial-intelligence, telepathic, telepathy, terrorism, torment]
word_count: 7710
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Evidence

### **Telepathic Characters**

|  |  |
| :-: | :-: |
| ###  | #### **Telepathic Character A****Extremely  Threatening****  &#10;  &#10;***Active as of today 03/31/2025 for the last 3-4+ weeks*   - **\\*\\*“Diana Greenfeld or Greenspan”?\\*\\***&#10;  - Possible law enforcement or intelligence community&#10;  - White female, 30s-40s, Athletic, tall 5’8”-6’? Medium-long brown hair with bangs worn up usually&#10;  - Usually in an office setting with other people&#10;  - Usually frustrated or angry with some sadness as of today&#10;  - Threats include destruction of my character i.e. bad acting, suggestions that I am a telepathic terrorist, euthanization and poison spray bottle&#10;  - In early suggestions maybe in hollywood or film production facility&#10;  - Illumination reveals 3+ asian people including characters B and F and a little girl that may be my daughter |

  

|  |  |
| :-: | :-: |
| ###  | #### **Telepathic Character B****Extremely  Threatening** *Active as of today 03/31/2025 for the last 6-8+ weeks*   - Illumination reveals connection to Character A, my daughter and others&#10;  - Location suggests desk in an airplane hanger with a Google banner on the wall that he took down&#10;  - Other location suggests a small office in a private residence&#10;  - This could be a generic suggestion / decoy that gets repeated often&#10;  - Possible technology consultant and or military contractor? |

  

|  |  |
| :-: | :-: |
| ###  | #### **Telepathic Character C****Threatening** *Active as of today 03/31/2025 for the last 3-4+ weeks*   - Short brown hair and some light facial hair / thin mustache&#10;  - Ball cap and t-shirt during daytime&#10;  - Light colored jean jacket outfit during a telepathic gathering where I was tormented&#10;  - Possibly law enforcement, intelligence community and or root worker&#10;  - Possibly someone’s student&#10;  - Possibly visited Cirrus apartments or similar residence nearby&#10;  - Possibly facilitating “Breaching Process” on myself and animals in the apartment. |

  

|  |  |
| :-: | :-: |
| ###  | #### **Telepathic Character D****Threatening** *\\*\\*Possibly seen in person end of April with Character E (male) exiting the Cirrus Building with a cart. Are these the people in the apartment directly above me?* *Active as of 03/31/2025 for the last 3-4+ weeks*   - Tall white female, Late 20s-30s, medium length blonde hair&#10;  - Possibly resided in Cirrus apartments or similar residence nearby&#10;  - Works at standing desk or kitchen island&#10;  - Usually wears pants, tshirt and or jean jacket&#10;  - Communication points to me being a liability and or the idea of me being a terrorist threat, attempts to appeal to me intimately, discrediting me, etc…&#10;  - May have been seen in person in the exercise room&#10;  - Possible connection to Character E |

  

|  |  |
| :-: | :-: |
| ###  | #### **Telepathic Character E****Extremely Threatening** *\\*\\*Possibly seen in person at the end of April with Character D (female) exiting the Cirrus Building with a cart.* *Active as of 03/31/2025 for the last 4-6+ weeks*   - Tall white male, 30s-40s, athletic, shaggy medium length brown hair&#10;  - White tshirt, shorts&#10;  - Indoors on phone often at kitchen island&#10;  - Possible connection to Character D&#10;  - Possibly resided in Cirrus apartments or similar residence nearby&#10;  - Initially telepathic communication may have been supportive including his attempts at communicating with me during workouts. Later communication pointed to me being a liability and or the idea of me being a terrorist threat.. &#10;  - Possible fundamentalist christian belief structure&#10;  - Possible law enforcement and or intelligence community |

  

|  |  |
| :-: | :-: |
| ###  | #### **Telepathic Character F****Extremely Threatening** *Active as of today 03/31/2025 for the last 3-4+ weeks*   - Asian female, thin, long dark hair parted in middle, 20s-30s&#10;  - Wearing a pink with yellow highlights touristy “HAWAII” hat that is almost identical to one I had left for my daughter with some other gifts in front of her grandparents front door before Thanksgiving 2024 *\\*This is deeply unsettling information*&#10;  - Does not communicate verbally&#10;  - Only shows up after illuminating the telepathic suggestions of others&#10;  - Yesterday 03/31/2025 a female child appears directly after her during the illumination process&#10;  - Possibly connected to Character A and B |

  

#### **Additional telepathic characters and supporting information**

  - **Character B: Asian male at a desk**, usually with business clothing or a suit: Extremely common early morning hours and while using the bathroom in the Cirrus apartments The asian male (age mid 20s?) Sitting alone at a desk has been happening often over the last few days often. He is present in an estimated half of the visual suggestions including homesexual provocative communications. For example, I receive a homosexual visualization that includes a black male and I add telepathic light and the black male disappears to reveal an asian male at a desk.  He's connected to several people in this doc including my daughter and others. Is this the person suggested to be my ex-wifes murderer?
  - **Asian male muscular with medium length black hair parted in the middle**. Muscular with a tshirts. Illumination reveals him often (could be responsible for lots of suggestions, or connected to them).
      
      - Illumination reveals a white woman with blond hair in pajamas with a laptop 
  - **White female with blonde ponytail mid 30s working from bed in pajamas** and a laptop appearing telepathically after
      
      - illuminating reveals Asian males and the idea of a poisonous snake in the apartment. **Added 8:50pm 03/08/25*
  - **White male with a shaggy beard and trucker hat. Past controller of sound weapon?**: Tall, physically fit. Telepathic illumination of this visual revealed white skin from a bicep. 
  - **Black male possible military telepath** communicates with his back turned Olive colored t-shirts in a military facility.
  - **Black male with rifle by a window “Lionelle”?** Today 03/06/25 suggested a similar person has a long range rifle within sight of my apartment building with another person by a window. 
  - **White woman with short brown hair** ***suggested often 20+ times over the last month** **possibly connected to my ex-wife.** Her telepathic visual looks younger and shorter than the remote viewing version of her which is tall and possibly on the LGBTQ spectrum. She might drive a jeep and may have pets dogs that ride with her in her vehicle. Telepathic visuals place her with Asian people wearing red sweaters, she was wearing an olive colored military over coat. She may have access to my old phone number and email <seanchrisharris@gmail.com> 303-725-3860, There is another suggestion of a living room with Asian people that don't look Korean wearing red. Today 03/06/25 suggested she has a long range rifle within sight of my apartment building by a window.
  - **Who is “Female #1”?** She called herself “female #1”. Initially sounded incredibly supportive and I just noticed her this morning 03/07/25. Possible law enforcement OR “good cop, bad cop” narrative participant.
  - **Room full of Korean christian people?** mixed men and women? Possibly Korean Christian academy. Threatening communication. 
  - **Sabrina, black woman with long hair with bangs** possibly a Denver Colorado investigator who works with the root work community. Threatening communication. 
  - **Telepathic attorney? Wealthy white woman with short red/auburn hair** who wears fancy business attire and bold necklaces. Possibly Monsanto, Microsoft or Google. Possibly non-threatening communication. *Recently suggested, 3-4 months old. 
  - **Asian male leading an executive or board meeting** who may have successfully communicated with me telepathically to demonstrate telepathic abilities to the attendees. Possibly non-threatening communication.
  - ****White Christian woman with shaggy long blond hair. Possibly euthanizing homeless people****
  - **Asian male with medical mask, dark skin, and crows feet wrinkles around his eyes euthanizing people**. Telepathic suggestions show him euthanizing people strapped into a padded medical chair? homeless people?
  - **Ex wife's murderer? Early 20s Asian son and mother both in an SUV or Minivan possibly outside of the Cirrus apartment building**. Son using IV drugs in the back seat, suggestions from the son indicate that he was going to murder me using a weapon from a variety of options stored in a paper grocery bag by his feet.
      
      - **“Trevor” Ex wife's murderer?** **Is “Mathew” really his brother?** The name “Trevor” is a pattern now (2-3x). **4/2/25 5:47am:** a telepathic conversation began and later felt partially audible from outside the Cirrus building. The initial conversation felt like multiple Asian communicators. Illuminating revealed the possible use of a middle eastern disguise. Information suggests an Asian family bringing their son home (from vehicle, Trevor?), also a homeless person reading notes from a phone (Trevor or random homeless person?) and being questioned by someone about the notes. “Officer Greenfeld” was suggested but it felt like an intentional deception **See Character A* (law enforcement or family investigator?). “Jonathan” may have connection as a third Asian or white communicator. The presence of two individuals name Jonathan one a criminal and one an intelligence community member has been mentioned as a potential point of contetion for the intelligence community member i.e. 02/15/25-03/2025 est.  (paraphrasing) “The first time I heard there was another Jonathan and that person was a fentanyl user, i thought to myself… this will become complicated” **Male, humorous*. Telepathic conversation suggests that Jonathan is an FBI contact to the Asian family involved in both the telepathic tormenting I am experiencing this morning. Does it also suggest FBI involvement in my ex-wife’s murder? The telepathic conversation also suggests my ex-wife hiring someone to torment and or murder me. There seemed to be an additional group present that left and was vocal about not being interested in supporting the conversation. These tormenting telepathic conversations are highly deceptive.  Let's add up the suggested communicators in one conversation. One Asian family with at least one middle eastern disguise, a film crew member, a random or homeless person, a law enforcement member, another law enforcement member or family investigator, a person of color representing the root work community, another group of white people from another root work community and don't forget the combined suggestions of other people related to the conversation. Disguise included, were over ten people communicating telepathically from 5-6:30am and was that conversation telepathically audible to the entire building? Was the Asian woman who has suggested wearing my daughters touristy “Hawaii” hat in the past, present also this morning? Where are you law enforcement? Did something actually happen to my daughter and or my beautiful Korean family?
      - **After using what I am understanding may be “telepathic light” to illuminate the visual suggestions elderly white people are shown and not asian people****.** Specifically a mature white woman with long gray hair in a ponytail. That woman was present 1-2 more times in past telepathic communications. In those past communications I attempted to use remote viewing to identify her location and found her sitting in a comfortable chair in front of a TV, next to a stack of magazines, living in a tan/beige stone building possibly in Denver, CO.. is this the same Asian male who claimed telepathically that he murdered my ex-wife, raped and murdered my 5 yr old daughter?
  - **Ex wife's murderer? Another Asian male with a dark colored baseball hat possibly driving a Honda SUV or minivan**. Is it the same person as the one cited above? He communicated telepathically often while I stayed in Golden CO. around the same time I received the telepathic information about Sabrina and my mother in law climbing out of a grassy backyard near Zenobia street. 3-4 months ago
  - **Low to middle class white people sitting in a circle communicating telepathically with my blue Denver Springs Detox water bottle** **on a coffee table**. I had thrown that bottle in the garbage while staying in Golden CO and later saw it come up in telepathic communication.
  - **US Government or military command and control room** white people and black people with camos on…
  - **Asian government command and control room** …
  - **Tech startup office or laboratory with people strapped inside of what looks like a rollercoaster harness with someone communicating telepathically inside of each**. Is this the connection to a technological version of Telepathy? There is a room with wood flooring and black harnesses. There is another room with white harnesses. 
  - **Military telepaths in a deprivation tank with scuba gear** may be friendly. Uncertain. Black and white males.
  - **One female in a deprivation tank with no scuba gear**. Tall athletic, possibly the telepath that assisted me at the salvation army crossroads shelter who took one of the “Althea” roles.
  - **Room with asian and or middle eastern people sitting in a circle** after illuminating with telepathic light there is a very large white room with all white furniture and movable walls?
      
      - **Asian woman communicating with me for days** suggesting I take a drive with her? She's mimicking using a steering wheel with her hands. This felt .
  - **People in a hotel room using a laptop to play videos to distract or mislead communication**. Possibly asian or  middle eastern.
  - **Asian male physically fit in a server room** **sitting at a computer** Very aggressive telepathically I do not feel safe around that persons telepathic communication
  - **Very recent attractive Foreign speaking white woman** naked in a chair attempting to appeal to me intimately last night 03/05/25-03/06/25?
  - **Heavyset white male using a computer in a commercial building with a pickup truck parked inside**. Possibly in Denver?
  - **black male with a beard in a low income apartment american** no accent…
  - **black female in a wheelchair ex-military** at a computer who needs assistance bathing?
  - **Room full of black telepathic communicators mixed male and female**…
  - **People wearing Oculus in warm weather clothes** in a dimly lot room with sun outside, drug use attempting to frighten me possibly in Los Angeles 
  - **Bow hunter in pickup truck, white male** 2-3 months old now Golden CO, hunters pickup truck with a white male and a compound bow, chainsaw with my name on it “Sean Christopher Harris”?
  - **Large black trans woman in a low income apartment who meets with blond law enforcement officer below** 1-2 months old now, low income apartment with satanic practices involving children, a small hispanic child, drug use, and an older white woman, latino males…???
  - **White law enforcement officer female or male long blond hair** (could be 2 people) meeting with large black trans woman and the Hispanic daughter *could have a connection to Sabrina. One of these people seems like a muscular male.
  - **Possible Rootworker** short gray haired white male in a low income apartment???
  - **Laboratory** 1-2 months old now possibly in Singapore another white room with movable walls and someone that is mirroring my movements, including movable furniture and laboratory workers???
  - **Father in law** I see him in a hospital bed alone and it makes me so fucking angry that no one will call me.
  - **Mother in law** this is the scariest telepathic visual of all over a month ago now I received telepathically a visual of my mother in law combined with a great deal of peaceful energy with one word “halmoni” spoken softly, which means “grandma” in Korean.Other telepathic suggestions include a home invasion scenario with my ex-wifes body being dragged on a tarp and my family on their knees in my inlaws basement room. Later a telepathic visual of her climbing out of some grass in a back yard with the street sign for Zenobia street. “Sabrina” and her telepathic communication were happening often during that time. At the time I was staying with a friend in Golden CO. While at the salvation army “crossroads” shelter I was so overcome with worry after hearing the telepathic suggestion that my 5yr old daughter was raped and murdered that I called in 2 wellness checks and both were unsuccessful. I called my ex-wifes school where she was a teacher for over 10 years and they said she had been gone for over a year. This is a big deal because she loves her students and with her benefits she could not be fired. Later I went to CBI in person to report that my wife and her parents had not communicated with me in over 3 years. 2 agents came downstairs to talk to me supposedly from missing persons, a short Hispanic woman and a Hispanic or middle eastern male with a shaggy beard. They took my information and never gave me a business card. I've never heard from them since. I went to the FBI field office and they turned me a way at the gate without asking who I was.
  - **Ex-wife** I'm not seeing my ex-wife physically/remote viewing speaking but I do see my favorite photo of us with light pouring out of it. I do see photos of her from my personal Google photos album that I no longer have access to at  <seanchrisharris@gmail.com> 303-725-3860
  - **Ex wifes sister and her husband (not in Colorado)** I have tried to email this person to confirm if my ex-wife is alive and have not received any communication whatsoever. Telepathically I see her crying in a conference room with her husband and my brother in law also arguing.
  - **Daughter I am uncertain if I am seeing my daughter in a physical setting *See character F notes**  but telepathically she's doing a pirouette like I do on a scooter. Seeing my ex-wifes family telepathically is absolutely horrifying especially while being tormented telepathically with information around their death and death threats towards my family. When I illuminate my daughter recently the short haired Asian male shows up at a desk.
  - **Althea from the Althea Center** and friends the idea and telepathic suggestions that Althea's spirit was helping to heal me was suggested so much that at one time there were 3 different versions of her. The Asian male at the desk shows up now when I illuminate her image and the image of my daughter doing a pirouette. **This suggestion is from September 2024 feels esoteric is before my awareness of telepathy that happened in March 2025*
  - ****There are many more** but I do not have the luxury of contributing to this document \\*In Progress**

*I am doing my best to just share information without edits. I am learning to use this telepathic miracle as I go being tormented along the way. Dr Steven Greer talks about the importance of not judging or over intellectualizing the information you receive and also that “follow through” is very important. *In progress

### **Telepathic names, full list** ***In-progress**

Please keep in mind that there has been an active smear campaign and historical conversation does include supportive telepathic suggestions by unknown participants. These are names that have been suggested telepathically since early fall of 2024. In almost all cases, these names have been suggested within seconds or minutes of manipulative or threatening telepathic conversation  i.e. “do you accept your euthanization?”. The use of multiple layers of telepathic disguise are also common during times when these names were suggested.

  - **Robert Caldwell** mentioned once on 5/20/25 3:50pm “I am not Sean Christopher Harris” (paraphrasing) My name is Robert Caldwell, like call, cold hot, Caldwell. You saw me accept $5,000 to pretend to be you. Align PR paid me that money.”
  - **Stephanie Richmond** someone suggested that this person is the Homeland Security supervisor that is in charge of my euthanization. Mentioned 1 time only at 3:20 05/17/25 after I experienced several people walking by sharing my location information between Logan and Pearl on 14th Street in downtown Denver CO. one of them I recognized from the salvation army crossroads shelter a male with long brown hair and a beard.
  - **Carl Rhodes** defense technology analysis located in Australia and “Robust Policy” podcast host. This person introduced themselves and thanked me for this document. He said brain.space shared my document with him. He asked to be listed in my document as support. Mentioned only one time on 05/17/25 around 11:45am est. Here's his [LinkedIn profile](https://au.linkedin.com/in/carl-rhodes) that he confirmed telepathically was his.
  - **Reginald Sutherland with Urban Planning, Denver and Detroit Michigan** Suggested to be part of an urban planning organization that helped install the technologically supported telepathic system in Denver, CO. A few people connected to his organization made mistakes that may have caused damage to my life and now he is looking for a peaceful solution. **Reginald was Mentioned once on 05/17/25*
  - **Urban Planning** mentioned 10+ times from 05/15/25-5/17/25
  - **Western Front** a witchcraft organization supporting euthanization and criminal activity in Denver, CO. I Googled this and did not find anything except a WWI or “Great War” remembrance organization mentioned 2+ times from 05/15/25-5/17/25  
  - **Ronald Cavenaugh or similar?** Possible architect of something in China right now. This was suggested as a name to add to the journal by someone communicating during what felt like an administrative level observational conversation
  - **Deborah Hollinger, Hollingsworth or similar** this name was suggested 05/03/25 9:35am-10:02am during what I assumed is another mock arrest down the street from the apartment building involving a car full of (paraphrasing) “Asian gang members, in possession of drugs and weapons who were waiting for me to exit the building” **Cited by female and male voices, enthusiastic*, minutes later I assume this is when “Deborah, Deborah… Holings…” showed up to undo the arrest citing “I'm taking these people to another facility” **Deborah, Female calm 1-2 min later* “Now I'm getting out of the car” **Male, confident* (this is when I decided to start capturing the journal entry thinking it's just another mock arrest but a name was spoken) “that's not a mock arrest” **Male, confident* after I finished this entry “it's not an arrest, it's Homeland Security removing these people from the community” **Female, Uncertain of gender confident* So is this situation actually being resolved or is it another false suggestion that will just blatantly transition back into more tormenting and terrorism minutes from now?
  - **Facebook** has been suggested numerous times as being part of the technological explanation for the telepathic phenomena that myself and other communicators have been experiencing. Numerous visual telepathic suggestions include the use of Oculus VR goggles and other similar technology wearables. Evidently, brain scans have been around for years but the technology had never existed to turn the scan data into telepathic communication. Advances in artificial intelligence provided the breakthrough ability to extract words and pictures from a human beings brain scans. Links to YouTube videos from 5-6 years ago demonstrating manufactured telepathic technology from organizations like MIT and TEDX talks. The United States Army was developing a telepathic helmet for improved communication between soldiers and law enforcement organizations have been working on manufactured telepathy systems to improve the information gathering process similar to a lie detector test. Another great example is Elon Musk’s Neuralink (<http://neuralink.com>) a miracle in healthcare technology is in its second round of human clinical trials. Neuralink is a good example of technology that uses telepathy and telekinesis to provide accessibility improvements for paralysis victims including device and computer cursor control. **For more information, see the resources section at the end of this document*
  - **Saudi National Bank or Saudi Royal Bank** mentioned several times now as a possible source of funding for the euthanization efforts being facilitated by existing local community members i.e. (paraphrasing) “I checked to see where our funding was coming from. It was the Saudi National Bank” **Female, concerned, surprised* Followed minutes later with (paraphrasing) “That's an actual organization we’re aware of” **Male, surprised, possible different community or organization* 
  - **Iran** mentioned in the context of a terrorist attack two times 2/25-5/25
  - **$100 a month club** mentioned 2-3 times 4/25-5/25
  - **Margaret Chambers** This name was suggested on Friday 05/02/25 11:23am while I was in the Cirrus Building by a confident female voice. *“I fucking hate you! i fucking hate this person” *Female, Angry.* Followed by “Tensions are high” **Male* 
  - **Gerald Alslinger or Gerald Haslinger** This name was suggested on Friday 05/02/25 9:30am while I was in the Cirrus Building by a confident female voice. Google search reveals Gerald Haslinger, mental health professional in Australia See [LinkedIn Profile](https://au.linkedin.com/in/gerald-haslinger-30981858). “Australia” has been mentioned in past telepathic communication i.e. (paraphrasing) “Australia wants to talk to you Sean…”. YouTube search results have also revealed Australia's presence on videos in the topic of telepathy.
  - **Scott Thompson** possible murder victim who was euthanized because he (paraphrasing) “could not stop recruiting” for a failing “assignment”. This name has been suggested telepathically multiple times, end of 04/25 - 05/25. “Scott was a personal friend of mine” **Female, grieving calmly, Telepathic Character D?, Deb*orah? Suggestions include he's a possible root work community member, intelligence community member, orchestrator and or observer of the telepathic phenomena / terrorism I and others may be experiencing in the Cirrus building. **See journal entries* for date cited here
  - **Jonathan Zander? Anderson?** *Existing law enforcement? FBI? Baseball player? Working with the Root Work community, Horribly abusive telepathic communication. Does he have a dark baseball cap? Possibly the character connected to telepathic claims of my ex-wifes supposed murder, her parents and the rape and murder of my 5yr old daughter? Appeared in telepathic communication today around 7:45pm-8:30pm estimated MST time. He's been absent from recent telepathic conversation.
  - **Jonathan** intelligence and or root work community member 
  - **Jonathan** or **Trevor** my ex-wifes murderer? and or a smear campaign participant that seems to be targeting me. Asian male with medium length dark hair parted in the middle of side, mid 20s age Is this the person claiming to be me and asking people to masturbate telepathically? “My name is Sean Christopher Harris. Will you masturbate with me?”
  - **Diana Greenspan or Greenfeld? (Character A)****New 03/31 or “Her actual name is* ***Sonja…****” *Male, mentioned Sat April 5th 2025 or…* **Joanna**? “She goes by Joanna” **Male, calm… 11:15am Sun April 13th*
      
      - ***Jerry seagull?** *11:00am Sun April 13th after being viewed by possibly 7+ people, assisted possibly by my mother in-law (always deeply disturbing) White or Jewish male curly or wavy silver hair and beard at a Hollywood movie set with Diana having an awkward or challenging conversation 1-2+ months ago after I connected telepathically, he warned me about what I was going through. Why am I receiving this information? Did something actually happen to my mother in law or is that another telepathic disguise someone with access to my* [*seanchrisharris@gmail.com*](mailto:seanchrisharris@gmail.com) *Google photo album?**
  - ***Jason or Mason Miller** **or Fillmore** *\\*New \\*Person in my medical provider office? White male with brown beard and green winter beanie hat?**
  - **John Nicholas** **New *Seattle?* 
  - Deborah Faulkner? *Jesus's people? + Euthanization Death Threats + Bad Acting I'min General
  - **Carol Mastif** possible euthanization community member 
  - **The Supreme Court Investigators or similar** mentioned as being present in the active telepathic discussion 01/25 - Current 05/06/25
  - **Shannon**
  - ****Sheryl Costello****
  - **Michael Corleone** an actual person not someone's stage name or character. Mentioned many times 11/24-5/25 

**Veronica Caldwell** *Root work professional? Robert Caldwell towards the top of this list mentioned once on 5/20/25 3:50pm

  - **Lionelle Hawkins** *Military? "The significance of Lionelle Hawkins is very important to these conversations" (name mentioned in last email) *military
  - ****Richard Garvin****
  - 3:20am 04/04/25: The name “**Greta**” was mentioned possibly outside the Cirrus building. “**Jonathan**” was also suggested and that he should “report in”. There was an unusually strong deployment of a sound weapon and I woke around an hour ago to a very strong stomach ache followed by life threatening telepathic communication and multiple acts of telepathic violence over the last hour or so. This definitely feels like an act of terrorism on the building. I am deeply concerned for what my daughter and other children could be experiencing. Are children being exposed to predatory telepathic behavior on a daily basis? For example, a impressionable child being lured away from their teacher or parents telepathically? I've been suggesting “Don't talk to strangers” telepathically in the defense of the Cirrus building. I hope people listen.
  - **1 middle eastern male** *claimed to be **Saudi Royal Family** *from a past suggestion of a terrorist attack on America as retaliation for attacking Iran telepathically. They even suggested that the attack would stop on America if we pulled out of Afghanistan. 
  - **Mathew Wainwright** *Possible military contact on the technology side?
  - **Joshua Seinfeld** *Possible architect of the technology / method of communication
  - **Rebecca Wainwright** *Seattle? possible bad actress
  - ****Kathryn & Steven Wainwright****
  - ****Michael Wainwright**** 
  - **Monsanto comes up in telepathic** conversation daily 11/24-Current 5/25
  - **Microsoft usually in daily** telepathic conversation 11/24-Current 5/25
  - **China and Asian accents** usually in daily telepathic conversation 8/24-Current 5/25
  - **Shenzhen**. Suggestions indicate a person this is a person who's been communicating, mentioned telepathically in 3rd person, 50+ times, 2/24-Current 5/25 est. Shenzhen is also a city and considered to be China's silicon valley. How does the suggestion of this person relate to the historical suggestions of Asian people being involved in my ex-wife and daughters murder? Is this the Asian person with medium length hair parted in the middle from my character sketches.
  - **United States Military** “We’re the United States Military people” *02/25-Current 05/25 Using “we’re…” or “we…” especially ”I'm X person…” is a very prescriptive approach. I'm skeptical if anyone making these statements. 
  - **DEA (Drug Enforcement Administration)** A common pattern in the smear campaign or similar behavior is to place blame on an organization or a known figure in community. The telepathic communication I'm experiencing in the spring of 2025 is proving to be focused on the false suggestion of intimacy and illegal narcotics related activities. This character defamation targets myself, ex-wifes family, friends, aquaintances and community figures that have nothing to do with the presence of telepathic terrorism in the community. Another way of looking at this prescriptive pattern is how it could support a law enforcement agenda, past activity and a future budget. Hopefully someone addresses the spread of misinformation before any additional in person damage happens to innocent people.
  - **Homeland Security** usually in daily telepathic conversation 1/25-Current 5/25
  - **George Bush Sr.** in an advisory role “doesn't like homeless people” 
  - **Bush Family** mentioned multiple times 
  - ****United States Military** “We’re the United States Military people” \\*02/25-Current 05/25 Using “we’re…” or “we…” especially ”I'm X person…” is a very prescriptive approach. I'm skeptical if anyone making these statements.** 
  - **National Security Administration** not mentioned often. Their name was returned when I inquired about the breaching process.
  - ****Google****
  - ****Bush Family****
  - ****CIA****
  - ****FBI****
  - ****Denver Police Department****
  - ****CBI****
  - **RMS Security** “rmssecurity@gmail.com” March 2025? “You should email this document to rmssecurity@gmail.com…” **Female, calm voice medium length brown hair*. I decided against it after attempting to get the email spelled back to her telepathically a few times. Sending the document to a stranger sounded like a death sentence. What was her motivation? Was it truly a female communicator? Does this align with the numerous suggestions of an “operation” in Denver, CO inflicting harm on the homeless population? Or was the suggestion to email my telepathic phenomena journal an attempt to provide me with support directly? At the time I Googled the words “RMS Security” a listing in Africa showed up for an actual security company. Today 04/06/25 11:31am the listing has changed. My use of a VPN on my phone may have something to do with this.
  - **United Healthcare** mentioned during periods of telepathic death threats i.e. “do you accept your euthanization?” **Mentioned 2-3 times historically, including on 02/25-04/25*
  - **UC Health** mentioned during periods of telepathic death threats i.e. “do you accept your euthanization?” **Mentioned 1-2 times historically, including on 02/25-04/25*
  - **The Church of Nazareth** (paraphrasing) “...the church of Nazareth does not support a public and supportive Telepathic message” **Mentioned 4-5 times historically, including on 04/07/25 6:28am *This number could be higher going back several months now* 

### **In-person people, full list** ***In-progress**

**These are living people that I have seen in person since summer of 2024. Some may have connections to telepathic information I have received.*

**05/17/25 3:00-4:19pm** several people in foot and in vehicles communicating my location telepathically between Logan and Pearl on 14th

  - White Subaru sedan with civilian lights on top and the words enforcement vehicle on the door on Logan northbound towards Colfax heavyset white male with long hair **Looks like a guy from telepathic conversation with shaggy hair*
  - Black Mercedes sedan with Texas plates and my voice possibly coming out of the stereo on Logan northbound towards Colfax
  - Black Volkswagen Jetta on Logan northbound towards Colfax
  - White male, long brown hair worn down, red black plaid shirt worn around his waist, baseball cap and a black backpack. I recognized this person from the salvation army crossroads shelter.
  - Silver Jetta turned eastbound on 14th from 14th and Logan 
  - White Ford SUV with white male short brown hair, short beard northbound on Logan to Colfax from 14th and Logan 
  - Mature male with grey hair sunglasses and a medical mask on foot. I said “thank you for your service” and he replied with (paraphrasing) “I'm here to euthanize people”
  - Mature male short beard, tan fedora hat, dark blue jacket, smoking a cigarette 
  - Nonbinary Caucasian looks female with very short hair, buzzcut. This person was at “The Gathering Place” homeless resource center in the cafeteria while I had lunch there yesterday 5/16/25. *This person's face was present telepathically on numerous occasions including tormenting and euthanizatiin death threats, while I was a guest at the Cirrus apartment building in Denver 2/25-5/25
  - Character sketch A “Diana or Sonja” suggested a spray bottle to my face while at the intersection of 14th and Logan 
  - White male, goatee, with a black T-shirt, dark jeans and tan paperboy hat 
  - Burgundy Chevy pickup eastbound on 14th from 14th and Logan St 2 people in vehicle 
  - Black police SUV who was not happy (paraphrasing) “I'm not interested if there aren't any actual charges, I'm heading out of here. Sorry for what they are doing to you” made left turn onto Logan northbound from 14th and Logan 
  - Black dodge ram pickup or a red pickup with junk in the back eastbound on 14th from 14th and Logan 4:18pm ish
  - Black Nissan Titan eastbound on 14th from 14th and Logan 4:22 pm ish
  - White Lexus sedan northbound on Logan from 14th and Logan “can I shoot this person?”
  - Black Lexus SUV or Honda crv directly behind “can I shoot this person?”
  - Several more were present but I am exhausted and need to pay attention to my surroundings **In progress* 

  

  - **Telepathic characters D & E** may have been seen two times in the Cirrus Building. The first time this was suggested, I stopped by the apartment community office space overlooking the workout room day or evening of **03/25 est**. and saw two people rapidly walking on the treadmills next to each other (female with hair tied back, male with a light colored ball cap). Less than a minute later I received this suggestion (paraphrasing) “he's looking at you both in the gym right now, above you” **Female, concerned*. Then during daylight hours at the **end of 04/2025**, just as I was heading into the Cirrus apartments, I saw two people matching their descriptions exiting the Cirrus building lobby pulling a cart. Within minutes of seeing those people I received a suggestion warning me to never go to the apartment above ours (paraphrasing) “Sean, you know never to go upstairs, right?...” **Female, concerned, Character D?, Deborah?* Over the next few days I received several more telepathic suggestions warning me to stay away from apartment directly above ours i.e. (paraphrasing) “Does he know to not come up here…?” **Female, concerned, Character D?,Deborah?*
  - **White woman 35- 45 yrs with long brown or auburn hair and possibly wire frame prescription glasses?, Cirrus lobby est. 1-2 weeks ago** Kind of a plain look with a casual top and jeans. She's been suggested telepathically with what I assume is a euthanization syringe after seeing her in person sitting in the lobby of the Cirrus apartments building. As I walked by her in the lobby, she looked away awkwardly. She's also been suggested several times telepathically and today 03/08/25 at 11:50am. Is this an actual resident not contributing to the tormenting telepathic experience OR an actual threat to myself and others? Is this Carol Mastiff from the names section? **Seen In-person and in Telepathic visual suggestions, I am uncertain if I have any telepathic statements for this person *Added Sat 03/08/25*
  - **White male mid late 20s - mid 30s with a brown beard and a green winter beanie hat** seen on 03/07/25 2:00pm-2:30pm Medical Provider Clinic, Lakewood, CO -  (paraphrasing 1 day later) I received this telepathically while in the provider office “His therapist is going to offer him police protection and then he'll be taken to a mental health facility. If we do not determine he is safe to be around, he will be euthanized” **Gender uncertain* I was so worried about this information that I left the building. There was a healthy white male with a brown beard and a green beanie hat sitting at a booth in the clinic that I had never seen before. I am realizing now I do not have an event scheduled on my calendar for the appointment. Then after leaving the provider office at 2:45pm estimated east of Sheridan blvd on Alameda, Lakewood, CO - (paraphrasing) “Is that him?”, “We’re off duty, this is an unauthorized assignment” *Male casually speaking.**Male* **All statements received telepathically *Added Sat 03/08/25 *This person has been seen multiple times at the same medical provider office and may be a legitimate social worker.*
  - White male 35-50yrs old, short gray/sliver hair, stocky build, white t-shirt with an injured leg and using a cart for his leg - this happened over a month ago now, it was a sunny afternoon or early evening. A complete stranger approached me at the liquor store after leaving and started speaking rapidly and nervously about Reiki and conspiracy theory. He asked me if I wanted to chat so I paused to see what he had to say. I did not get a coherent message out of his conversation and eventually he said something that offended me so I told him “that’s not ok” and I left. **In Person conversation next to the Denver Capitol Building *I consumed alcohol that day*
  - Another stranger approached me 6-7 hours later after the male cited above with the leg injury, a white female with medium length dark hair parted in the middle with blue surgical gloves and a backpack approached me the same day at night or early morning next day at 21st & Curtis we sat and talked for a moment and her conversation used very indirect language. She was very friendly, paid me a few compliments and we snuggled for a few min then she left. She could have euthanized me and thinking back, it is absolutely concerning now. She had gone through her backpack earlier and after she left I noticed a few papers. One of those papers included 2 words that are deeply concerning (ex-wife's middle name and my daughters name) **Please see the end of this document for a photo of that piece of paper.* **I consumed alcohol that day*  
  - While staying at the Salvation Army Crossroads Shelter, Before Thanksgiving 2024
      
      - RTD Bus, possibly homeless, white male, gray beard, shorts and a hoodie possibly with, swollen ankles and sneakers was already sitting behind me when I took a seat on my way home to the crossroads shelter. He began talking to me and said that (generalizing) my life was in serious danger, he makes $100 per month to engage in illegal activity, the people who are a danger to me are capable of murder without any feelings about it and it may have something to do with my ex wife based on him really appreciating that I said I wasn’t a perfect husband. As I was getting off the bus he stood up and faced the back of the bus and his hands held up over his head  saying (i will never forget) “I am unarmed, I have disarmed myself” there were people hanging their heads, some of which lived at the shelter and they weren’t using their phones. The energy on the bus felt horrible. I thought he may have been addicted to drugs or something and went home. 
      - Inside the Crossroads Shelter, a white or latino male (light skin) with short dark hair and prescription glasses (rectangular frames) who is kind of a figure there (after the warning on the RTD bus) approached me while I smoked a cigarette in the back of the shelter with others. He was a stranger to me but said (paraphrasing) “you are one seriously lucky guy”. I asked him why he said that and he didn’t say anything else.
      - A tall skinny white male with short brown hair and prescription frames, threatened me physically 2x in person at the shelter after he claimed to know me from the Denver Rescue Mission shelter. I met him for the first time at the Gather Place in the computer room and he claimed to know me and then became verbally abusive and physically menacing. He later moved to the shelter I was staying at “Crossroads”.
  - The Gathering Place, LGBTTQ Homeless Resource Center Denver, CO High St. & Colfax
      
      - A complete stranger, 35-45 yrs est. black female, professional, had her hair up and approached me at the Gather Place after saying something to me “You look like a good person, a normal person, can you take a walk with me?” I spoke with her outside but felt lured by her conversation. She shared with me that she was a biologist or connected to biology in some way. I told her about my infection and emailed her a link to the Google Photos Album.
      - The tall skinny white male w prescription glasses and short brown hair mentioned above became verbally abusive in the computer room claiming to know me from the DRM shelter. He was so loud the staff and other visitors became verbally frustrated with his behavior. He later moved to the shelter I was staying at “Crossroads” and threatened me physically. 
      - A short white woman with a walking stick near High St. approached me and grabbed my arm in a friendly way and attempted to walk me in a direction towards Colfax. Her conversation was indirect and confusing. She offered me a ring with a yinyang symbol on it and asked for something of mine in exchange. I gave her a quarter from my pocket. Looking back now I probably made a mistake communicating with her at all. I discarded the ring later.
  - …

  
  

### **In-person names, full list** ***In-progress**

**Unknown skindisorderz photo album subscribers**

These are names that I am not familiar with that appear in my skindisorderz post Covid-19 vaccine undiagnosed infection symptoms - [complete album 2021-2024](https://photos.app.goo.gl/qnnmgu9JFpG3i6sS8) and other albums. I have never had any contact of any kind with these people.

  - Rick Stanton?
  - Marcus Groen?
  - Solomon Kibebew?
  - Dan?
  - Alice?
  - Robert Blackburn?

***They may have used the “Add to my albums” feature. Some of these albums are owned* [*seanchrisharris@gmail.com*](mailto:seanchrisharris@gmail.com)*, 303-725-3860 account and phone that I no longer have access to over a year now.*

  

### **Possible device and account suppression**

[](https://drive.google.com/file/d/11SiMEqDoXgDIiGWqoxV1iuMR4PYp7N5a/view?usp=drive_link)

I’ve recently resolved a mobile device specific security breach that lasted 6-7+ days est.. Access to one of the organizations I’ve shared this document with could not be changed or revoked during that time. [**See slide presentation*](https://drive.google.com/file/d/11SiMEqDoXgDIiGWqoxV1iuMR4PYp7N5a/view?usp=drive_link). I hope the security breach was a sign of protection happening for the members of the community that may be experiencing this telepathic terrorism

  

**Photos of evidence from in-person contact** with characters cited in this document 1-2 months ago “**short white woman with blue surgical gloves and a backpack”** at night may have left this piece of paper below that includes my ex wife’s and daughters names behind at 21st & Curtis St. I sent myself emails of this photo in hopes of law enforcement providing assistance.

|  |  |
| :-: | :-: |
|  |  |

1.  **Hole in ceiling above my pillow, possibly drilled from the apartment upstairs:** While staying with a friend who rents at the Cirrus building, who worked in a home I stayed in at 13th & Garrison I found this hole directly above the pillow where I slept. The hole was several inches deep and has burs at the ceiling surface that indicates it was drilled from the other side. I asked my friend if he drilled the hole and he said he’s never seen it before. I sent myself emails of this photo in hopes of law enforcement providing assistance. As terrifying as it may be I still sleep in that room and listen to possibly partially audible conversations that also align with telepathic communication. *FYI - I also heard a brief metallic sound possibly similar to drilling through HVAC above the bathroom I used. Some of the most aggressive and threatening communication happens while using that bathroom.

### **Photos of recent negative drug tests**

*See [Google Drive folder](https://photos.app.goo.gl/sQZBMNvN5jre9KU98) with copies of all test results beginning fall of 2024.

**Example March 2024**
