---
id: IS-J01-FM-03
title: Part 01 — Introduction In-progress
collection: analysis
doc_type: section
part: 1
source_doc_title: "Invisible Ships Pt. 01, Aug 2024 - Aug 22d 2025"
source_doc_id: 12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0
source_url: "https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit"
categories: [front-matter, front-matter]
glossary_refs: [artificial-intelligence, perceptual-set, telepathic, telepathy, terrorism, torment]
word_count: 2418
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Introduction In-progress

### **Overview**

My name is Sean C. Harris. I'm a 49 yr old agnostic father and research professional in technology who’s been enlisted unexpectedly into a harrowing and relentless telepathic journey of self development.

I’ve written this document in hopes of supporting others in determining what myself and the community are being exposed to. For example, is the telepathic tormenting I am experiencing unethical technology experimentation and or an unacknowledged terrorist attack? Am I speaking directly in 1:1 conversations with law enforcement, military and others?

Please keep in mind, regardless of being 1000+ pages this document only represents a fraction of the overall conversation. Telepathic communication has been so saturated that I can not actually capture the entire conversation receiving information from 3-10+ communicators and at times multiple groups 24hrs a day and all while I am being tormented and offered euthanization.

If you are understandably skeptical about these sensational claims and or initially concerned for my emotional well being please consider reviewing some of my personal background available in the resources section of this document. [**See Sean Harris Background*](https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit#heading=h.btv4e4sjdb3s)

### **Invisible Ships** ***In-progress**

Have you experienced internal communication that is difficult to explain or too embarrassing to share with someone? If so, have you come to an explanation as to why or how you are having the experience?

I recently discovered the psychological principle of the Perceptual Set (the mental predisposition). A Perceptual Set is a tendency to perceive or notice some aspects of the available sensory data and ignore others. It is heavily influenced by expectations, past experience and context. If an object is completely outside a person's prior experience (their "set"), they may not select it for conscious attention, effectively rendering it "invisible" to their mind's eye, even if their retinas physically register it.

The most famous anecdote describing this concept is the story of Captain Cook (or Magellan) arriving at an island where the indigenous people could not see his ships because they had no concept of such massive vessels. Allegedly, the ships were so alien to the natives' reality that they simply didn't register them visually. The shaman (or chief) eventually "saw" them by observing the water displacement and deducing their existence.

  

### **Document Structure** ***In-progress**

Description goes here…

#### **Part 01, Findings & Journal Fall 2024 - Aug 22nd 2025**

Part One focuses on the initial 'discovery' research findings drawn from my personal experience with telepathic phenomena. It summarizes the complete data—all transcripts from Fall 2024 through August 22nd 2025—and outlines follow-up questions and forward-looking suggestions. This volume also contains unique supplementary materials, including physical evidence, a glossary, and the appendix, which are not included in subsequent parts of the series.   

**Discovery & Analysis:**

  - [Background](https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit#heading=h.rrg6f3o56r90) (pgs - …)
  - [Questions](https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit#heading=h.slf8bstixkv7) (pgs - …)
  - [Methodology](https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit#heading=h.si7gorc3mrbq) (pgs - …)
  - [Findings](https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit#heading=h.okvp0ds937ba) (pgs - …)
  - [Questions, continued](https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit#heading=h.mpe7vik54wpa) (pgs - …)
  - [Proposed solutions](https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit#heading=h.jrm58in5xd9k) (pgs - …)

**Supporting Data:**

  - [Journal & Transcripts, Fall 2024 - Aug 22nd 2025](https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit#heading=h.uhy8wb75qedv) (pgs - …)
  - [Physical evidence](https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit#heading=h.fpu11c8xp680) (pgs - …)
  - [Glossary](https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit#heading=h.aayfluiu7dxn) (pgs - …)
  - [Appendix](https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit#heading=h.9740yldug3c6) (pgs - …)

#### **Part 02, Journal Cont. Aug 23rd - Sept 28th 2025** 

[Part two](https://docs.google.com/document/d/1A4HYkmgZ_lQ5hYSsVtE9CNPIkWb47wNRiZVQs-Du--E/edit?usp=sharing) includes several months of daily journal entries and transcripts from August 23rd 2025 to September 28th 2025. 

#### **Part 03, Journal Sept 29th - Nov 8th 2025**

[Part three](https://docs.google.com/document/d/1J_oU1Tt-thE2s_DmnPCsckY-LDz4lMPxNV1FB4UBsgs/edit?usp=sharing) includes several months of daily journal entries and transcripts from September 29th 2025 to November 8th 2025.

#### **Part 04, Journal Nov 9th 2025 - Current**

[Part four](https://docs.google.com/document/d/1MyYwH5Q1xBqazmzgb2L5T6aRmN2-Ymnt5AruoRe7CCU/edit?usp=sharing) includes several months of daily journal entries and transcripts from November 9th 2025 to EOY 2025 (current).

#### **L.L.M. Analysis of so-called “Citizen Tech” External Statements**

[This document](https://docs.google.com/document/d/1VNEL5FEU5tZTocNbY-OM8CiO6P5IuJ2mPmtQ2tFAzUU/edit?usp=sharing) is the beginning of my journey using A.I. (Artificial Intelligence) to analyze the external so-called “Citizen Tech” statements using an L.L.M. (Large Language Model) front-end i.e. [TypingMind.com](http://typingmind.com).

#### **Plan for Justice**

[This document](https://docs.google.com/document/d/1gzmU6tTSu6-qHU-b3FQRxPS58i-BAivjdktiu7mgrB8/edit?usp=sharing) is the beginning of my journey using A.I. (Artificial Intelligence) to produce a list plan to protect people impacted by the unconsented to communication and the threat of forced so-called “Citizen Tech” euthanization. This document includes best practices households can use if asked to share information on what they are going through.

#### **Light Research**

Please reference this document “[Discovery of Telepathic Terrorism - Light Research](https://docs.google.com/document/d/1Fch0V-3Zoowg7MVKiI69MCVW2VwYMOYv7RFiC5t7Hbo/edit?usp=sharing)” for summaries based on a folder of light or directional research output from Gemini [available here](https://drive.google.com/drive/folders/1RHebIQL0vumKa43S9y8pWG8uq1z-8P45?usp=sharing).

#### **Possible Evidence**

Please see this folder “[Possible Evidence](https://drive.google.com/drive/folders/19C7t1qu5FGx0SNjXmTGIi8B6iRpeiTH1?usp=sharing)” for a collection of recordings, photos and screenshots that may provide in-person or physical evidence supporting the events cited in the Discovery of Telepathic Terrorism document series.

#### **Future Project Planning**

I’m determining how best to use the criminal activity surfacing in the transcripts. According to Gemini there are potentially three main purposes: [Legal Prosecution, Ethical/Policy Reform](https://docs.google.com/document/d/1xAxtCqmRtKQKvy3_6lT4ZfuS6tYzZImi43EX21r3P9A/edit?usp=sharing) and [Seeking Asylum](https://docs.google.com/document/d/1ekfccoVC6Ruy40NlxwT9E2xcT74V5uPMT5hfCg4M4j8/edit?usp=sharing) including [Asylum Resources](https://docs.google.com/document/d/1ekfccoVC6Ruy40NlxwT9E2xcT74V5uPMT5hfCg4M4j8/edit?usp=sharing).

#### **Neuro-tech in Law Enforcement**

Here’s the beginning of researching the use of Neuro-tech in law enforcement. See the [Google Doc](https://docs.google.com/document/d/1lEFuRTRZLYrzJV3ZRkVvn1viVSVxZoB6Yg0PidbcMYg/edit?usp=sharing). 

#### **Personal Protection Plan** 

[This Google Doc](https://docs.google.com/document/d/1kY_452-jTwhXpABLDKvv8mc0-PE56-6iPPk5BpKtbF8/edit?usp=drivesdk) contains Gemini A.I. research on neuro-rights and how someone can investigate or prosecute criminal harassment delivered through directed energy/E.M.F. (Electro-magnet Field) or L.R.A.D. (Long Range Acoustic Device).

#### **Needs Processing**

[This is a Google Drive folder](https://drive.google.com/drive/folders/1kGD0_7HohBzS6Hl8FTVUhpMmAvNeIiu-) with raw notes that have not been added to the Invisible Ships transcripts.

  
  
  

### **Background** ***In-progress**

Admin Note: In general I don't feel this conveys “what happened so far?” Review the below original overview. Consider something more linear capturing the events infection to esoteric beginnings to telepathy and then introduce the questions + findings. Ask yourself what are the findings? Evidence of criminal activity, etc.? 

#### **Esoteric Beginnings**

This journey began in 2021 in Portland, Oregon after a hopeful divorce related sabbatical took a dark transition into severe personal hardship fueled by a full body infection sustained 1-2 weeks after a Covid-19 booster shot. After losing everything, while residing at the Salvation Army “Crossroads” Shelter, while my body unexpectedly recovered from the infection, I was introduced to a violent, manipulative and suppressive first experience with telepathy. What should have been an easy return to a successful career trajectory and helping my daughter find her first black belt, has become a fight for my life and possibly the lives of others impacted by this telepathic phenomena.

What is the explanation for the presence of these telepathic observers, their initially friendly suggestions to engage, supporting visual phenomena and the suggestion of its underlying “spirituality” narrative? Why are myself and possibly others being telepathically and psychologically smothered (a.k.a. tormented) into accepting a covert form of euthanasia after communicating? The telepathic violence myself and others may be experiencing is unusual when compared to a historical understanding of spirituality that promotes tolerance and compassion.

The only physical change of significance that may provide an explanation is my previous post vaccination infection. Other explanations for the telepathic phenomena could be coming in contact with something that had been dispersed into the community i.e. a homeless shelter, restaurant, public transportation and or being exposed to an under-acknowledged technological advancement. To my surprise, recent advancements in artificial intelligence provide evidence of the possibility that what myself and others may be experiencing is technological and not spiritual.

#### **Disruptive technology**

According to news sources previous to 2020, M.I.T. University had unveiled a telepathic wearable that converts thoughts into real time communication, the United State Army has been working on a telepathic helmet and law enforcement organizations were developing technology supported telepathic alternatives to the existing lie detection equipment. As of 2025, Elon Musk’s [Neuralink](https://neuralink.com/) organization recently raised $205 billion in its series C funding round and is in its second round of successful human clinical trials in B.C.I. (Brain-computer interface) technology. Neuralink’s first product “Telepathy” is a miracle in healthcare technology and a demonstration of how artificial intelligence uses brain scan data to provide people suffering from paralysis with the ability to control devices with their minds. ***[*See Neuralink’s Summer 2025 Update*](https://youtu.be/FASMejN_5gs?si=dkPDKgRs2plskOHa) *at Youtube* S.M.B.s and consumers also have access to a variety of groundbreaking advancements in brain scanning technology through products like [Neurosity Crown](https://neurosity.co/), [brain.space](https://www.brain.space/) and [Emotiv](https://www.emotiv.com/) wearables.

#### **Neuroethics Concerns**

The global B.C.I. market is projected to rise from approximately $2.1 billion in 2023 to over $12 billion by the early 2030s. In addition to global interest and investments this disruptive technology comes with its share of concerns. In 2002, the term “Neuroethics” gained significant traction and its modern definition thanks to a landmark conference organized by the Dana Foundation called "Neuroethics: Mapping the Field." At this conference, New York Times columnist William Safire famously defined neuroethics as "the examination of what is right and wrong, good and bad about the treatment of, perfection of, or unwelcome invasion of and worrisome manipulation of the human brain." This 2002 conference is widely credited with establishing neuroethics as a distinct and recognized field of study, moving it beyond a niche term and into a formal discipline that explores the ethical, legal, and social implications of neuroscience.

Neuroethicists are worried about the use of artificial intelligence (AI) in brain-computer interfaces (BCIs) because AI's ability to process and interpret neural data creates a host of new ethical challenges.1 These concerns revolve around issues of privacy, autonomy, and personal identity. BCIs collect vast amounts of neural data, which AI algorithms then analyze to decode thoughts, intentions, and emotions. This raises significant privacy and security concerns. The data from your brain is arguably the most sensitive information there is, and if it's not properly secured, it could be vulnerable to hacking, surveillance, or misuse. Who owns the data? Is it the user, the company that developed the BCI, or a third party? What are the risks? This data could be used for targeted advertising, insurance discrimination, or even in legal contexts to "prove" intent. What if it's hacked? A breach could not only expose sensitive information but could potentially allow for the manipulation of a person's thoughts or actions.

#### **Existing laws concerning communication** ***In-progress**

Admin note: update this with the EU AI Act & the known US equivalent

Before formulating any strong opinions regarding the suggestion of technology supported telepathic conversation, here’s some information on how citizens are protected in the United States from unconsented to communication.

Un-consented communication, especially when it is repeated or involves threats, is a key component of harassment and stalking laws. These laws are designed to protect individuals from unwanted and distressing contact. There is a delicate balance between protecting individuals from unwanted communication and upholding the constitutional right to freedom of speech. Generally, courts have held that harassing, threatening, or obscene communication is not protected by the First Amendment.

Un-consented communication, especially when it is repeated or involves threats, is a key component of harassment and stalking laws. These laws are designed to protect individuals from unwanted and distressing contact. Stalking is generally defined as a course of conduct directed at a specific person that would cause a reasonable person to feel fear. Un-consented communication, such as repeated phone calls, texts, emails, or showing up at someone's home or workplace, can be a major element of a stalking charge. Harassment laws often prohibit communication that is intended to annoy, alarm, or threaten another person. This can include using obscene language, making threats of harm, or simply engaging in a pattern of unwanted contact that disturbs someone's peace. With the rise of digital communication, states and the federal government have enacted laws specifically addressing online forms of harassment and stalking i.e. “Cyberstalking or Cyberharassment”. These laws often criminalize using the internet or other electronic devices to threaten, intimidate, or harass someone.

Laws in the United States also addresses un-consented communication in a commercial context. The Controlling the Assault of Non-Solicited Pornography and Marketing (CAN-SPAM) Act is a U.S. law that sets rules for commercial emails. It requires businesses to provide a way for recipients to opt out of future emails and to include a valid physical postal address.

  

#### **Moving forward** ***In-progress**

In the next section, I will offer a few questions to frame the threatening information included in this document that has been gathered through minute to minute suffering over one year now.

If you have not already done so, make sure you’ve completed the “Read First” section of this document. Also, consider conducting a brief personal inventory to determine if you are experiencing any telepathic phenomena. I hope this document can offer inspiration for your daily process and possible explanations if you think you are in fact experiencing telepathic communication. 

I’m a huge fan of keeping personal questions and ideas on post it notes
