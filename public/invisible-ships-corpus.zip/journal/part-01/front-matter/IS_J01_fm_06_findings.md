---
id: IS-J01-FM-06
title: Part 01 — Findings
collection: analysis
doc_type: section
part: 1
source_doc_title: "Invisible Ships Pt. 01, Aug 2024 - Aug 22d 2025"
source_doc_id: 12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0
source_url: "https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit"
categories: [findings, front-matter]
glossary_refs: [artificial-intelligence, telepathic, telepathy, terrorism, torment]
word_count: 7252
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Findings

Include an opening here…

  

### **History of euthanasia (audience/Incumbents)** ***In-progress**

Include suggestions that align with the incumbents (contractors, retired intelligence community, parapsychology professionals etc.) point of view  i.e. euthanization is ethical and is forced on people through the tormenting process to ensure the use of telepathy remains exclusively for the military.

Include past suggestions “Stop communicating!”

Include pros and cons of not communicating i.e. not communicating allows the entire conversation to focus on being tormented

Find anything online that cites the requirements for illegal euthanasia PAS (Physiscians assisted suicide)

  

### **Telepathic statements**

Here are the most common telepathic suggestions since my personal experience began in the fall of 2024. The majority of what I experience is extremely threatening. However, there are daily observational suggestions that may be a sign of support. Due to the fact that no one has contacted me using traditional methods i.e. email, phone or in person contact, I do not recommend anyone trust an unaccountable telepathic communicator, regardless of how supportive their message is.. 

#### **Nationally Threatening**

  - ****“This is a terrorist attack on America. Why won’t you respond, America?”** This statement has been present alongside the suggestion of a nuclear strike or significant ground attack i.e. (paraphrasing) “ we’re considering  detonating something at the Rocky Mountain Arsenal using sound”. Middle eastern visual and verbal suggestions were present at the time of these statements. This statement surfaces usually at the intersection of 8th & Colorado during the summerr of 2025 where 30-50 vehicles per week conservatively were being added to the euthanization list, for months, as punishment for vehicles responding to the statement “Do not support this person\\!” (Sean C. Harris, myself). *\\*Originally suggested once in Feb of 2025, then again mid July 2025 and towards the end of the summer in 2025 to Jan 2026 (Current) has become an almost daily suggestion.*** 
  - ****“When will you acknowledge what is happening to your citizens, America?** Usually paired with **“We will react based on how you react, America.”** Asian visual and verbal suggestions were present at the time of these statements. *\\*Common at night in Denver, CO while residing in the 300 person household the D.R.M. (Denver Rescue Mission) 48th St. Shelter  in the summer of 2025, and from the fall of 2025 to now in Jan 2026 (Current) is suggested several times a week.*** 
  - **“These aren’t our people. We would never make these statements.”** This suggests the existing domestic “euthanization clean up crew” IS NOT AWARE of other groups facilitating euthanization. **Suggested 5-7+ times conservatively from the summer of 2025 to Jan 2026 (Current)*
  - **“These are our overseas counterparts.”**  This suggests the existing domestic “euthanization clean up crew” IS AWARE of other groups facilitating euthanization. **Suggested 3-5+ times conservatively from the summer of 2025 to Jan 2026 (Current)*

  

  - *  
    *

  

  -   

  

  -   

  

  -   

  

**Threatening - Group dynamics**

This is the most dangerous form of communication, in my personal opinion, based on historical suggestions, that could destabilize any home, homeless shelter or possibly a municipality. These suggestions take place when I am around other people. For example, in an apartment with roommates or any public setting including busy intersections downtown, homeless resource centers. In general, a threatening telepathic voice makes dangerous and adversarial suggestions to the people around me, using me as a platform for the communication at times, possibly in hopes of someone actually committing a crime and or contributing to my psychological smothering process. 

  - **“Your roommates are going to kill you Sean”** in addition **“She’s poisoning your food Sean”**
  - **“My name is Sean Christopher Harris, will you masturbate with me?”** This was very common during 3/25-5/25, while residing at the Cirrus building to current as part of what has been called a “Smear Campaign”. Illumination for this suggestion returns a mid 20s Asian male with medium length dark hair parted in the middle.
  - **“Nigger, bitch!”** or **(paraphrasing) “Sean Christopher Harris is a racist asshole.”** or any similar racist comment when I walk by a person of color. The racist comment can happen after the suggestion of a person of color says something supportive to me telepathically.
  - **“Will you stab this person for us? He’s using the restroom”** in person tactical suggestions **“Just reach over the divider and stab him for us. I’ll send you a Cash App for it.”** When walking down the street it’s common for me to overhear telepathically a person of color receive a suggestion like **“He’s a high value target. I’ll pay you $1000 to kill this person.**
  - ****“You used to much mayonnaise”** or maybe **“Sean is using too much water in the shower”** \\*Any gender Petty grievances perceived usually as an effort to cause life threatening division within the home / apartment. This type of suggestion also seems to be effective in the context of a psychological smothering effort to push me and or someone else towards euthanization.** 
  - **“Do not give this person any money!”** This one happens commonly in the intersections where I am using a sign to collect donations. You can feel the telepathic suggestion enter the cabin of the vehicle. Oddly, it affects the entire intersection whether I am there or not. I make around $3 per hour on a good day and sometimes nothing at all. I usually take the opportunity to suggest a public safety announcement from a private citizen during these times that lets the drivers know the person yelling at them is a human being and they are experiencing telepathic communication, etc.

**There is a chance that I have lost every single chance at living with roommates due to this type of suggestion since fall of 2024. Now that I am at the homeless shelter it is happening to people around me in a very challenging way this week of May 26th 2025. I am afraid that this may actually end my life, cause a riot and or entrap an innocent person of color, sending them to prison. FYI - I conduct personal inventories often, exercise and meditate when possible. Maintaining a success oriented attitude has been challenging in the face of this abusive suggestion. With certainty, none of this is wishful thinking nor do I dwell on self loathing topics or ideas.*

  
  

#### **Operational**

These unconsented-to external statements represent the holistic so-called “ugly workflows” that began approximately in 2025 and continue to current January 2026, with the exception of there being significantly less spirituality related statements that the spring of 2025.

  - **“It’s spirituality!”** or **“We’re the spirit world.”** or **“I’m a spirit world person.”** This was extremely common summer of 2024 - Spring of 2025.\\
  - **“Respect the old ways, people**”, or **“Should we respect the old ways?”** mentioned almost daily spring to summer of 2025 while I wash my face in the morning. Does this suggest the esoteric idea of disconnecting from the breached individual when they apply water to themselves, similar to a baptism or method of clearing oneself of negative energy? Does the suggestion of “old ways” imply there is a new way that uses technology?
  - **“Do you accept Jesus?**” **Very old 2024 but important*
  - **“Bless your heart**” **Usually female*, ****Possibly a woman with shaggy blonde hair* mentioned in the characters section of this document. Also connected to conversations mentioning euthanization
  - **“Breaching process”** Both telepathic phenomena and physical sensations suggest that I am a victim of being breached multiple times daily since August 2024 in almost every location I have attempted to restore my career path. **See more on this suggestion in the technology section below.*
  - ***“Sean Harris, please use the bathroom.”** or **“I feel like I need to use the bathroom”**, **“Does anyone need to use the bathroom? Please use the bathroom.”** This is a very common suggestion with almost daily instances that happen when I feel like I need to use the bathroom, especially when I hold my urine for an extraordinary amount of time. Tragically, I have found that the breaching process can be avoided by holding my urine providing me with an uncomfortable moment of privacy.*
  - **“Sit down on the toilet!”** This is suggested after abdominal discomfort or while standing to use the restroom. If I sit down I experience the suggestion of the human breaching process. **Daily spring 2025 - Jan 2026 (Current)*
  - **“Obedience”** or **“disobedience”** i.e. **“This person is too disobedient!”** **Male or female, angry, frustrated*  This is a common suggestion as of June 2025, 3-5+ times per week historically. Is this evidence of experimentation? If so, what are the research objectives and for both the facilitators and the participants? What kind of individual psychology would perform best as a facilitator of the breaching process? Or weapons development? For example, the work of Stanley Milgram and his experimentation on obedience  is required reading for most psychology degrees around the world. In 2010 a reality show in France “[Le Jeu de la Mort](https://en.wikipedia.org/wiki/Le_Jeu_de_la_Mort)” duplicated this experiment. **See Stanley Milgram at* [*Wikipedia*](https://en.wikipedia.org/wiki/Stanley_Milgram) *and* [*Experimenter*](https://youtu.be/NtoDZ5C3FeU?si=j-5Yxo-j19L2HC49) *Film *In progress*
  - **“Mind control”** is a very common suggestion 15+ times 4/25-5/25 For example “This mind control needs to be over in the city of Denver.” *Female, confident, concerned suggested on 5/28/25. *Not all suggestions of mind control will be present in this **“Pain administration”** I've experienced the suggestion of telepathic pain administration 10+ times 2/25-5/25 while also experiencing physical pain, in tandem. Examples of pain administration could be instantaneous sharp pain or soreness in my face, chest, groin, legs, face, ankles and other symptoms like heart palpitations. The release of stomach acid into my intestines has also been suggested while later experiencing an unexpected and uncomfortable bowel movement. On 2-3 occasions from 2/25-5/25, uneventful suggestions from unidentified telepathic communicators, for me to masturbate, have been punished with pain administration. Monsanto has been mentioned in the past times 5+ 1/25-5/25 during suggestions of pain administration..
  - **“Telepathic outbreak”** The suggestion that telepathy is a disease and the "euthanization clean up crew” is here in Denver, CO..
  - **“Stop communicating!”** This was extremely common spring of 2025.
  - **“1,2,3, stop communicating!”**, “**1,2,3 don’t masturbate, we’re connected to you!”** This is by far one of the most abusive and terrorizing statements. A group of people counting down to a statement they all recite in unison
  - **“Everyone has their own euthanization group”** In so-called “Citizen Tech” discussion this suggestion is explained to be part of the organizational culture for all groups communicating. Some have suggested it’s required out of a need to protect their organization. **2-3+ times approximately, similar statements could present a larger pattern, summer 2025 - Jan 2026 (Current)* 1/15/2026 12:31pm as I type this entry "That is accurate information”
  - **“Euthanization clean up crew”** **Female, confident* 05/12/25 10:47pm mentioned 2-3 times from 2/25-5/25. This was also suggested possibly by the same person on 5/12/25 within minutes of the **“clean up crew”** and  **(paraphrasing) “I would euthanize a child who was telepathic if I knew they were struggling”**. I asked why and she responded with **(paraphrasing) “If I knew we could not stop the source of the telepathic trouble”**. Several people suggested being deeply disturbed by the statement and the severity of the situation in Denver Colorado.
  - **“Ugly workflows”** or **“the are military, ugly workflows”** almost daily for approximately 1 year,  Jan 2026.
  - ****“It's an operation”** or any variation of **“I fucking hate you for destroying my operation\\!”****
  - ****“Great fucking job you’ve destroyed our operation\\!”** Suggested 20+ times between 2/25-5/25. Depending on how demoralized I am I usually suggest the value of changing direction to the people suggesting this.**
  - **“Assignment”, “I hate this fucking assignment”** or any variation of **“you're an asshole Sean for ruining this assignment!”** **Male and female spoken often every da*y.
  - **“There is no help for any one person”** This statement surfaces historically after support for myself (Sean C. Harris, the author) is suggested by another person or when I ask for someone to receive support. 8-10+ times since summer of 2025 - Jan 2026 (Current)
  - **“We support the person, in accepting euthanization”** another example of diminishing the violence inflicted on the community from the “euthanization clean up crew” or  “ugly workflows”. Is this evidence of intentionally hiding the severity of the violence and human rights violations from the individuals and organizations who would be held accountable? From a legally binding language perspective, abandoning someone’s 4th amendment rights, inflicting violence physically (Breaching, EMF, Sound Weapons, etc.), psychological violence, character defamation and or luring someone outside their home with false suggestions of providing financial support, narcotics and or intimacy does not align in any way with the word “support”. **7-10 times approximately Spring 2025 -  Jan 2026 (Current)* 
  - **“Can you hear me? Can you hear me, Sean?”** Attempts to get me to communicate when there is an publicly unexplained death penalty and without consent.
  - **“Can you tell us what you are experiencing right now, Sean?”** **Male or Female, observational* This suggestion usually happens 1-2+ times daily, usually after a telepathic event of significance i.e. after I provide feedback on how I feel about the tormenting I am experiencing.
  - **“You need to engage with us.”** Continuous attempts to draw me into conversation when there is a death penalty present for communicating **Almost daily for months currently Jan 2026*
  - ***“Why won’t you communicate with us?”** *\\*Possible architects / orchestrators?**
  - **“We need you to accept your euthanization”,** **“Let us help you end your suffering”****,** **“Please accept the euthanization”****Both male and female*
  - **“Come outside Sean”**, **“Let us help end your suffering”**, **“Exit the building and go 2 blocks west”** Suggested 5+ times while staying at the Cirrus Apartments in Denver, CO
  - **“Put yourself in our shoes and you'll see right where we are”** , possibly an attempt to warn me of evil's presence nearby and or an attempt of convincing me to come find the people who would euthanize me. Considering the direct connection to another human being I am experiencing (breaching process), would seeing someone else’s shoes telepathically be the facilitator's temporary presence in someone else's body?
  - ***“Let’s move on to the next person”** This suggests rotating groups of people who are observing me for a specific period of time and or ideal circumstances.*
  - **“This person is being attacked right now.”**  or similar variations sometimes including **“EMF”** or **“radiation”** EMF is also becoming a pattern while experiencing nausea, ringing in my ears and or other mysterious symptoms ** 3-4+ times Winter 2025 - Jan 2026*
  - **“I wasn’t aware of this happening!”** This statement is suggested during heated conversations about the severity of violence  inflicted on the general population from the so-called euthanization “ugly workflows”. It’s usually followed with a statement that suggests the ugly workflows are hidden from the conversation intentionally from specific individuals or groups i.e. infirmary workers or local government. The conversation usually surfaces “I can’t be associated with this” **7-10 times approximately, summer 2025-Jan 2026* (Current)
  - **“This is a heavy handed approach!”** More suggestions on the severity of the violence inflicted on the community by the so-called "euthanization clean up crew” **15+ times conservatively from summer 2025 - Jan 2026 (Current)*
  - **“Get your dogs off of him!”** this has been suggested several times in a protective context while I'm being observed and or tormented.
  - **“Do not say that to us!”** a dead-end statement that surfaces immediately after someone stands up to the life threatening communication. **Multiple times daily 1-2 years current Jan 2026*
  - **“Don't take this person away from us!”** Another dead-end statement suggested almost daily 10/24-1/26 (Current), points to the possibility of organizational and or individual asking for what I assume is more time to murder me i.e. euthanization. To date these suggestions have been given at least 4 months to complete their “assignment”.
  - **“FBI, hands up!”** or **“It’s over people!”** very common and never results in in-person support showing up. Is this evidence of the false impersonation of law enforcement and or the intelligence community?
  - **“I'm tired of covering this up”** This pattern of telepathic communication has happened 2-3 times in the morning after the nightly and early morning tormenting (01/25- current 05/25, 3am-7am) at the Cirrus apartments and now (1-2 times per week as of 7/25) as a resident at the 48th st. shelter. The suggestion has historically followed psychological smothering and requests to accept euthanization. While at the Cirrus apartments, these suggestions felt like they came from outside the building, possibly from a vehicle. Considering the law enforcement and intelligence community organizations mentioned during the period of time suggested, how concerned should the Cirrus building be about this pattern?
  - ****“why won't you euthanize people with us?”** Possibly smear campaign behavior. The idea that euthanizing me won't happen should I choose to accept it. These unaccountable communicators are breaking the law. There is no logical calculation where I am not murdered for educating the general public on their telepathic terrorism.**
  - **“Why won’t you accept your euthanization?”** I’ve been asked this question at times calmly and what would seem to be authentically. I’ve asked why they would ask this question and the response has been, multiple times (paraphrasing) “We were told that euthanization was a valuable service to the community.” Other statements present alongside this statement include **“Euthanization is expensive. Do you know how much it costs us to provide euthanization?"** **3-4+ times historically*
  - ****“Exclamation point\\!”** (add an exclamation point) Every time I type a manual journal entry people attempt to contribute to the document. Is this evidence of blatant disrespectful attempts to discredit the document and myself?** 

#### **Operational - Technological Explanation**

These statements were common in the summer of 2025 as I made my way out of 2024’s “esoteric beginning” and into my education on telepathy, Neuro-technology and A.I. late spring of 2025. 

  - **“It’s not spirituality, it’s technology, people!”** (and vice versa) suggested 20+ times 2/25-5/25. This is still an almost daily suggestion as of 6/25. This comment suggests that people don't believe in the possibility of a technology supported version of telepathy, what we're experiencing is traditional telepathy or we're all communicating with the voice of Jesus Christ only. From 2/25-4/25 this comment was present in most telepathic conversations. These conversations suggest the lack of acknowledgement may have negatively impacted a variety of people and or their supporting organizations.
  - **“Everyone has an implant.  Literally everybody.”** **“Bio-tech”** or **“Implants”** or **“BCI”** **Suggested almost most daily, Fall 2025 - Jan 2026 (Current)*
  - **“We’re listening to you on a hardware device”** or **(paraphrasing) “We're not using telepathy. We're talking to you on a speaker.”** suggested 3+ times 2/25-5/25. This suggests the use of a technology supported version of telepathy where someone in an office or a command and control room is using a microphone and a speaker to communicate with another person who can use telepathic and or physical communication. That said, will the person using a microphone also have access to send and receive telepathic visuals? If so, how easily could those visuals be manipulated in real time, during the conversation? How might that manipulation impact the decision making of anyone communicating?
  - **“He removed my voice filter!”,**  **“I lost the fucking voice filter again!”** Suggested 10+ times 3/25-5/25. This refers to a telepathic communicator using some form of technology to disguise their voice. For example a female using a male voice, etc.
  - **“Citizen tech, is the name of a document”**, **“Citizen tech is what we call it at Homeland Security**” **Excited male?* 9pm 05/10/25 - No pattern yet on this statement. It surfaced while researching search terms “BCI law enforcement”, “Best EEG 2025”, “neurotech”, etc.
  - **“This is Neuro-technology!” ***Winter 2025 - Jan 26 (Current) almost daily now
  - **“They are forcing demonstrations on this person.”** The suggestion of prompting me with violence to force a demonstration of Neuro-tech internal gestures i.e. conversational overrides using the mental exertion of the attacker to share life saving educational information “Google the battle for your brain.” *8-10+ times, summer 2025 - Jan 2026 (Current)
  - ****Sharing PII (Personally Identifiable Information)** *\\*Use daily alongside discrediting and life threatening statements 1-2 years, Jan 2026 (Current)***
  - **“EMF”** or **"radiation"** in the context of a physical attack while experiencing severe physical discomfort, psychological discomfort and verbal suggestions to “accept euthanization” *
  - **“Particle accelerator”** mentioned 2x 7/25-8/25 (paraphrasing) “this is a very important part of this situation” **Male, confident* Telepathic visuals suggested a device that looks similar to a rifle but more mechanical *find photos of this
  - **“Ionic sound”** suggested summer of 2025 (paraphrasing) “You should look into “ionic sound”. Research using Gemini AI reveals “phonon lasers” that can also be used to generate images. Are phonon lasers part of the underlying technology being used to connect and communicate with Denver’s citizens?
  - **“Breaching process”** Both telepathic phenomena and physical sensations suggest that I am a victim of being breached multiple times daily since August 2024 in almost every location I have attempted to restore my career path from including, The Salvation Army Crossroads Shelter, Monarch Sober Living Homes, The Cirrus Apartments, The DRM (Denver Rescue Mission) Holly St. Shelter, The DRM (Denver Rescue Mission) 48th St. Shelter, The Gathering Place and any intersection where I collect donations or any random locations. Since spring of 2025 to today Jun 2025, tapping firmly on my chest results in a strong telepathic reaction from an unknown observer i.e. “Don’t do that!” or “The thought of you touching me makes me sick!”. Do these tragically ironic comments indicate a mental disorder present in the facilitators and or a severely violent tactical response to psychologically smother me into accepting euthanization? The breaching process can also be used as a possible explanation for my body being used to make telepathic comments, mostly racist or vulgar, perhaps to destroy my reputation and or suppress support. I often wake to someone making unsavory and or false claims from my body telepathically to an unknown group of communicators. Another example is when standing at an intersection with a cardboard sign in an attempt to collect donations, for each vehicle I look at the facilitator of the breach yells at the driver “Do not support this person!” or “Do not give money to this person!”.  Technologically speaking, is the breaching process facilitated through the use of a wearable? According to technological advancements in EEG’s, brain scan data can be converted by AI (Artificial Intelligence) into “mind reading” including words and pictures. Does looking at a vehicle in the intersection establish a target for telepathic communication to the driver inside? Emotionally and or physically speaking, I have never experienced a loss of control or any change in my extraordinarily healthy behavior from the possibility of this phenomena happening to me directly, all things considered. However, this group of abusive people suggest they have the power of life and death over anyone they choose. How does their behavior, specifically the breaching process destabilize the City of Denver or worse America? Will their voices attempt to sway elections, consumer purchases, and or other larger economic or political ecosystems?
  - **“Let us out!”, “Disconnect from us!**” this statement has become a very large pattern over the summer of 2025 and suggests that I have successfully breached one of the predatory communicators inviting them to the system that I have been experiencing.
  -   

#### **Tormenting - Extremely Personal** 

These are the extremely personal statements made within the so-called euthanization “ugly workflows” that pressure someone psychologically to accept euthanization or potentially kill themselves. 

  - Any **unconsented-to observation** or **unconsented-to conversation** Do not underestimate the cumulative impact of psychological and emotional suffering that comes from the awareness of silent observation and or what would seem to be casual or friendly conversation from a stranger, without compensation and without public explanation. This is especially painful when you are being attacked and forced to accept euthanization. Nothing is more inappropriate, disrespectful or demoralizing. There is a death penalty in Denver, Colorado for communicating. There is a 30% increase in suicide in the United States, right now, compared  to previous years. If you are going through this do not accept euthanization and demand nothing less than publicly accountable communication. Refusals on behalf of the communicator to follow through with this are a sign your life is in serious danger. Who has a report on the impact of this behavior?
  - **Any suggestion that help is coming** and or **temporary silence** when there has been no news media or law enforcement explanation. This has become a sign of danger for me, historically speaking. For example, if you are no longer being observed, what are your chances of being executed or betrayed in person? In addition, if the terrorism goes away and no news media explanation is provided to the general population, how vulnerable will we be to additional terrorism? The news media explanation will prevent the misdiagnosis of schizophrenia and create the crime “preventative layer of transparency” educating everyone that the new observation Neuro-technology reveals most criminal activity in advance and or as it happens.
  - **“I fucking hate you Sean Christopher Harris!”**
  - **“I raped and murdered your 5 yr old daughter.”****,** **“I murdered your ex-wife and daughter”** **Severity of abuse contributing to the ranking of this telepathic statement*
  - ****“How do you feel about that?”** or **“How does that make you feel?”** \\**Possible architects / orchestrators?* This usually happens after severe verbal abuse and or physical pain administration.**
  - ****“He’s not un-circumcized\\!” or “Hey, he’s circumcized.”** This statement is made while I’m using the restroom or taking a shower and is usually followed with the suggestion that “fake profiles” are being socialized by “Monsanto” to the facilitators of the so-called. *\\*20-25+ times since spring 2025 - Jan 2026 (Current)***
  - ****“He’s not a good fit for euthanization.” “There’s nothing wrong with this person” or “He’s a normal person.”** *\\*10-15+ times since spring 2025 - Jan 2026 (Current)***
  - ****“Your suicide will never be remembered”** Suggested telepathically for months during the time I stayed at the Salvation Army “Crossroads” Shelter**
  - ****“What are you thinking about?”** or **“What are you doing to yourself?”** After someone connects themselves to the euthanization prospect or target, there  is a pattern of discrediting behavior being facilitated including the sharing of “Citizen Tech” visuals including pornography or narcotics. A static frontal image of genitalia followed by the statement “what are you thinking about?”. This seems to happen publicly and usually after a supportive statement is made to the euthanization prospect. This is a good example of the presence of an “ugly workflow”  *\\*Happens daily and sometimes multiple times daily for 1 year approximately.***
  - ****“Your roommates are going to kill you Sean”****
  - ****“We’re going to kill you family Sean, for communicating”****
  - **“Don't take this person away from us**” Tormenting murderers?
  - ****“This guy is a dead man walking”****
  - **“I have a shot.”** *Male #1*, **“Take the shot”** *Male #2*
  - ***“skindisorderz”** has been suggested telepathically 20+ times 11/24 - 5/25 i.e. **(paraphrasing) “skindisorderz doesn't look bad for a parasite victim.”** or **(paraphrasing) “skindisorderz looks healthy. Why are we euthanizing this person?”** The brand name or handle for the [YouTube](http://youtube.com/@skindisorderzzz), [Twitter](http://x.com/@skindisorderz) and [Bonfire donation T-shirt](http://bonfire.com/store/skindisorderzzz) sites I put together to document the severity of my post COVID vaccine booster shot infection, to share with doctors from 2021-2024. There is also a [Google photo album(s)](https://photos.app.goo.gl/qnnmgu9JFpG3i6sS8) that was shared with many people via email directly in institutions like MIT, CU and Berkeley bioengineering departments with no reply whatsoever. During that time I went to a PCP, specialist doctor or ER visit 1-3 times per month, never succeeding at receiving treatment from a infectious disease team. According to the one MRI, I succeeded in getting, the infection left me with tendon damage, soft tissue damage and unidentified growths in 2023-2024. I never received a firm diagnosis and do not know whether or not the COVID19 Phizer booster shot was the actual source of the infection. My symptoms disappeared completely in 2024.*
  - ***“Don’t exercise”**, **“****Don't eat that”** etc… **“You used to much mayonnaise”** or maybe **“Sean is using too much water in the shower”** \\*Any gender Petty grievances perceived usually as an effort to cause life threatening division within the home / apartment. This type of suggestion also seems to be effective in the context of a psychological smothering effort to push me and or someone else towards euthanization.*
  - ***“This home will be your final resting place.”** *\\*Suggested 5+ times 2023-2024 while suffering from a full body infection post Covid booster shot aand staying as a guest in someones home**

#### **Tormenting - Intimacy**

These are the unconsented-to highly inappropriate and intimate statements made within the so-called euthanization “ugly workflows” that embarrass someone publicly and pressure someone psychologically to accept euthanization.

  - **“Why aren’t you masturbating?”**, **“He’s going to masturbate”** **“Will you masturbate with us Sean?”, Why won’t you masturbate with us?”**, etc. suggested for months while staying at the Cirrus Apartments in Denver, CO.
  - **“Sweetheart, sweetheart”...** **Usually Male, threatening and also protective, there is also a *Childlike slightly raspy feminine voice that repeats*
  - **“Which way do you swing Sean?”** **Male or female* 

  

#### **Tormenting - Narcotics** 

These are the unconsented-to highly inappropriate narcotics related statements made within the so-called euthanization “ugly workflows” that embarrass someone publicly and pressure someone psychologically to accept euthanization.

  - **“Why won’t you smoke some fentanyl with us, Sean?**”, **“I just want to enjoy some fentanyl with this person.”**
  - **“He’s a meth addict!”**, “He’s a homeless person!”
  - ****“Fentanyl is not the issue\\!”****
  - ****“Where is the humanitarian perspective?”** this is usually suggested after someone attempts to destroy my reputation citing my use of narcotics**
  - ****“What do you mean he’s not a meth addict?”****
  - ****“It’s the narcotics unit doing this to people.”****

##### **Questions & Comments:**

There is a very large theme on the topic of fentanyl and meth amphetamine within the “Citizen Tech” conversation. Narcotics surface in a variety of ways including luring me out of my location at night with promises of relief from suffering and or an opportunity to earn money by dealing fentanyl. Other suggestions include POV (Point of View) visual information (information from an individuals eyes) that indicate people using drugs. I haven’t had a pattern of narcotic use in over one year due to a variety of reasons. I only enjoy alcohol daily as a sedative before bedtime.

Where is the humanitarian perspective? Is the city of Denver, CO. is experiencing a systemic breakdown resulting in a public safety crisis where too much focus is being given to the existing “War on Drugs” and not on the life threatening unconsented-to conversation?

#### **Tormenting - False Suggestions of Support**

Unconsented-to suggestions of support that never arrive. This is extremely painful for anyone in a lower income demographic. Personally speaking, these are the most painful over time and possibly contribute the most to heartbreak and betrayal that would convince someone to accept euthanization or commit suicide.

  - **“Let me see what I can do for this person”** with many variations daily, for example that include the words “...actually do for this person” usually after the morning suggestions of law enforcement intervention “FBI hands up!” that never result in the end of the terrorism or tormenting.
  - **“We’re coming Sean”** Again the illusion of in person support and compensation is excruciating. 
  - **“Can you receive a Cash App?”**,  **“Give me your Cash App”** Suggestions of someone who wants to support me where the support never happens. This also reveals my PII (Personally Identifiable Information)
  - **“I release you from your suffering”** usually followed by **(paraphrasing) “I am still here. I will never release you from your suffering.”** This suggestion is a good example of psychological smothering to support someone accepting euthanization.

#### **Expletives & Suffering**

These external statements represent others reactions to the unacknowledged so called “Citizen Tech” communication, suggestion of myself and others experiencing a life threatening situation and the suffering the facilitators of the so-called “ugly workflows” experience.

External statements, possibly from the direction of the “ugly workflow” facilitators:

  - ****“Great fucking job you’ve destroyed our operation\\!”** Suggested 20+ times between 2/25-5/25. Depending on how demoralized I am I usually suggest the value of changing direction to the people suggesting this.**
  - **“I hate this fucking assignment!”** or any variation of **“you're an asshole Sean for ruining this assignment!”** **Male and female spoken often every da*y.
  - **“Sit down on the toilet!”** This is suggested after abdominal discomfort or while standing to use the restroom. If I sit down I experience the suggestion of the human breaching process. **Daily spring 2025 - Jan 2026 (Current)*
  - ***“This person is too disobedient\\!”** *\\*Male or female, angry, frustrated**
  - **“Unbelievable!”** **Astonishment could be voice automation*
  - ***“Impossible\\!”*** 
  - **“Stop communicating with this person!”** This is telling people to not communicate with the euthanization prospect (myself). *almost daily from spring 2025 to Jan 2026 (Current)
  - **“Stay away from this person! He’s our euthanization person!”** Is this evidence of multiple so-called “euthanization clean up crews” targeting the author (Sean C. Harris, myself) for euthanization?
  - ****“This is horrible treatment of this person\\!”**, **“I feel horrible for what we’re doing to this person.”** *\\*Daily for approximately 1 year***
  - **“I can’t be associated with this  situation”** and other similar variations 7-10 times Fall 2025 - Jan  2026
  - **“You have my resignation.”** 3-4 times conservatively, Fall 2025 - Current (Jan 2026)

External statements, possibly from the direction of the community:

  - ****“There’s mental illness present” (in the ugly workflows)** Usually suggested when the unchanging aspects of the life-threatening communication and or inability to acknowledge daily events surface in the conversation. Followed sometimes by, **“we’re not allowed to acknowledge that information”** Is this evidence of organizational culture or counter productive priorities causing challenges in the “euthanization clean up crew” operation? *\\*10-15+ times conservatively Fall 2025 - Jan 2026 (Current)***
  - **“these could be religious people having a terrible misunderstanding”** **Male, disturbed* the Saudi National Bank was cited as a source of revenue for the people doing the euthanization during 3/25-5/25 est.
  - **“Where is the news media?”** or **“News Media”** mentions in the context of their absence being painful and deeply concerning to the people suffering. **Daily from the summer of 2025 to Jan 2026* There was one suggestion in the early summer of 2025 after I shared the transcripts with Ari Melber that sounded similar to Ari Melber **“We need an official statement”** i.e. on what is happening before we can talk about this. **Was this Ari Melber? Unlikely*
  - **“Who declared open season on the city of Denver?”** (hunting season) **10-15 times conservatively Fall 2025 - Current Jan 2026*
  - **“There’s  a death penalty for communicating!”** and **“so why are you communicating with this household?” (or person)** **20+ times conservatively December 2025 - Current Jan 2026*
  - **“Please stop communicating with this household”** **15+ times conservatively December 2025 - Current Jan 2026*
  - **“Call off your dogs!”**, 8:00 pm Dec 31st 2025 (paraphrasing) “You should add that to the document. It will sound like Washington” Suggested 15-20 times Feb-EOY 2025. A protective statement referring to the psychological violence being experienced by myself (Sean C. Harris). Who has suggested this historically? Wouldn't an email with an explanation be more helpful long term to a member of the general population. Observations will happen.
  - **“Stop communicating!”** **Anger and torment*
  - ***“This is an existential threat\\!”** Feb-April 2025*
  - ***“It’s not spirituality, it’s technology, people\\!” or vice versa** *Person \\#2* (and vice versa)*
  - **“What is happening to us?”**

  

### **Names suggested**

**I am extremely reluctant to add any additional names due to the “political mud-slinging” present in the so-called “Citizen Tech” conversation and the life threatening impact that has surfaced to date, in January 2026.*

This section, like most of this document, is representative of the opinions and behavior of others and should not be considered proof. Many people and organizations have been suggested telepathically since early fall of 2024. Names or organizations mentioned would need to be overheard in telepathic conversation multiple times before being added to this list. In almost all cases, these names have been suggested within seconds or minutes of accusatory, manipulative or threatening telepathic conversation i.e. “Do you accept your euthanization?” and or in the defense of the general public i.e. (paraphrasing) “Mike Johnson does not support euthanization!”. 

Here are a few of the most mentioned names that surface in telepathic conversation and or the broadcasted “speakerphone” phenomena. Please see the evidence section of this document for the complete list:

  - Countries and foreign governments including **The Chinese Government, Canada, Saudi Arabia, France**
  - Private organizations including **Monsanto, Microsoft** and **Facebook**
  - U.S.A military and intelligence community organizations including **Homeland Security**, **DEA**, **FBI** and **CIA**
  - Law enforcement and local government including the **Denver Police Department** and **The Mayor’s Office**

**See the*[ *evidence, Telepathic names - full list*](https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit#heading=h.5at2ilg2nhfr) *section for the full list of organizations and individuals that have been suggested since summer of 2024.*

### **Telepathic characters & visuals** ***In-progress**

After learning about telepathy in the spring of 2025 I became more comfortable taking the visual information that was included in every telepathic conversation seriously. During my stay as a guest in the Cirrus apartment building I produced a handful of character sketches hoping to capture the likeness of the faces that surfaced during periods of severe tormenting. For example, “Character Sketch A” shown right, was a woman who surfaced on a daily basis in an office setting with others and usually in a state of conflict. My hope is that these sketches may provide some additional value to my testimony should the opportunity present itself. Unfortunately, I do not have the time to capture sketches for what has become conservatively 20+ additional communicators.

*See all telepathic characters in the [evidence section](https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit#heading=h.4in5bcefdmok).

  

### **In-person people** ***In-progress**

In person people teaser goes here… 

**See the*[ *evidence, in-person people*](https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit#heading=h.3qjt795u14b) *section of this document for the full list of people I have had physical contact with that may be connected to this telepathic experience.*

  

### **Terrorist acts** ***In-progress**

Add euthanization and beheading scenes from past telepathic observations

**Add Past Suggestions**: Multiple euthanizations (2-3) by an asian person in a labcoat of people who participated connecting to me telepathically who were euthanized, possible homeless females strapped to a padded medical chair similar to what you sit in for labs at any doctors office.

**Add Past Suggestion**: Asian in ski mask beheads a person sitting in a chair while connected to me using an electric knife. Felt like YouTube terrorist videos. This felt like I was attached to the person being beheaded i.e. feeling the separation of the head from the body.

  
  

### **Sense of self** ***In Progress**

Include some information on sense of self…

  - Paraphrase quote when someone suggested adding this
  - The neuroethics concern
  - The past suggestions from the facilitators of the “ugly workflows” forcing people to accept euthanization
  - Any impact to my sense of self from the Citizen Tech phenomena
  - Perceived impact to others

  

### **Telepathic Education** ***In Progress**

I have never received any formal training in traditional telepathy and I have never tried an E.E.G. wearable. From the time the so-called “Citizen Tech” phenomena began during my stay in Portland in 2023 through the spring of 2025 in Denver, Colorado, I had no understanding of telepathy or neuro-technology. The phenomena began with an unnerving awareness of being observed by someone and telepathic visual information that wasn’t easily explained

In the summer of 2024 the neuro-tech communication began. During that time no one ever mentioned the word “telepathy” or “neuro-tech”. After finding “[The Telepathy Tapes](https://thetelepathytapes.com/)” podcast and Elon Musk’s “[Summer 2025 Neuralink Product Update](https://youtu.be/FASMejN_5gs?si=bjQpUv3Q6JJx7pFp), an empowering new world of explanation and opportunity opened to me. It was as if, the absence of an explanation for what I was experiencing prevented me from defending myself from the onslaught of unconsented-to Neuro-technology that had breached my body and my ability to return to my career path. This is an example of  experiencing “Invisible Ships” myself….

  

#### **Telepathic Concepts & Gestures**

It’s been over 3 years since my life threatening so-called “Citizen Tech” experience began and over 1 year of experiencing the so-called euthanization “ugly workflows”. Here are some of the mental gestures and concepts I’ve experienced and possibly have learned to use during this time. Please forgive me if these are already established ideas. Remember, I have never received any formal training.

Concepts & Gestures:

  - Telepathic enunciation
  - Opening antenna/improving signal
  - Letting information surface vs. projecting concerns into the Neuro-tech conversation
  - Awareness envelope or container
  - So-called “Consciousness fluid” or “tendrils”
  - Verbal overrides
  - Displacement 
  - Locating connections
  - Inspecting yourself and others, Removing disguises
  - identifying connections to yourself and others
  - Discarding the suggestions of others, using the window metaphor
  - Navigation, rotating P.O.V. (Point of View) to discard the synthetic media and reveal the communicator (person with wearable or headset
  - Connecting & disconnecting using a tendril or “phone line” metaphor No “butt dialing” please! Isn’t that sexual assault?
  - Amplifying the communication of others
  - ?

  
  

### **Ugly Workflows** ***In Progress**

Include the past suggestions of these “ugly workflows” that show up in the tormenting process i.e. petty grievances, character defamation, psychological smothering, the destruction of relationships, destruction of employment,  Intimate betrayal leading to euthanasia and promises of support or friendship leading to euthanasia, etc.

  

### **Offsite Location** ***In Progress**

White people in a warehouse attempting to get my attention using a small pen sized flashlight. Later using a person connected directly to me they attempt to threaten me over multiple sessions using elaborate scenes i.e. putting a gun to the hosts head to make it seem like they are putting the gun to my head (what do we call the person where they are who is connected to me?)

### **“Speakerphone” phenomena** ***In-progress** 

Include quotes from transcripts including the word “speakerphone”

Question idea: “Is Denver, CO listening to something that has not yet been explained?”

Include the phenomena of when holding my index fingers over my ears reveals the physical sensation of telepathic suggestions from the center of my head and releasing them increases the volume of the telepathic conversation.

Include assumptions around the phenomena of sound where radio signals and or satellites are intersecting with noise from the street system and other sources creating the similar effect of a speaker or amplifier

Include the use of Piezo sensors in urban planning

Include the sound amplification properties of Piezo technology
