---
id: IS-J01-FM-04
title: Part 01 — Questions In-Progress
collection: analysis
doc_type: section
part: 1
source_doc_title: "Invisible Ships Pt. 01, Aug 2024 - Aug 22d 2025"
source_doc_id: 12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0
source_url: "https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit"
categories: [analysis, front-matter]
glossary_refs: [telepathic]
word_count: 53
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Questions In-Progress

Is this happening to you, right now? *The reader

What is the explanation for the presence of these telepathic conversations? Spiritually? Technologically?

Who’s accountable in this situation?

How concerned should myself and the city of Denver be about the threatening nature of these claims?

Where can someone find assistance for this situation?
