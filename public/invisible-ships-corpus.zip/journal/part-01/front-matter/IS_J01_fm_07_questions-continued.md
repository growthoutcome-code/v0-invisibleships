---
id: IS-J01-FM-07
title: "Part 01 — Questions, continued"
collection: analysis
doc_type: section
part: 1
source_doc_title: "Invisible Ships Pt. 01, Aug 2024 - Aug 22d 2025"
source_doc_id: 12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0
source_url: "https://docs.google.com/document/d/12EN-urHWVOZyhfubcJSsSEyVipI80OVWDTlhCVC9gc0/edit"
categories: [analysis, front-matter]
word_count: 18
author: Sean C. Harris
copyright: © 2026 Sean C. Harris. All Rights Reserved.
---

## Questions, continued

Post experience questions go here…

This is the majority of questions that the discovery doc can inspire answering
